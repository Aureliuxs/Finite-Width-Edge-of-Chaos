"""
simulate.py
===========

Finite-width simulations of signal propagation and avalanche extraction.

Three interchangeable *engines* generate the per-neuron mean-square pre-activation

        qhat_l = (1/N) sum_i (z_i^l)^2          (the paper's q_l; sqrt(qhat_l) = signal strength)

layer by layer for a batch of inputs:

``full``    Explicit random weight matrices, any initializer.  The honest simulation.
            Following the paper, each network is re-used for ``perturbations_per_network``
            inputs before being re-initialised.  Weights are generated on the fly layer by layer
            (never stored), from a seed that depends only on (seed, network, layer) -- so an
            entire (sigma_w^2, sigma_b^2) sweep sees the *same* random numbers (common random
            numbers), and optionally cached in memory.

``markov``  EXACT reduction for i.i.d. Gaussian weights with Gaussian (or zero) bias.
            Because W^{l+1} is independent of y^l, conditionally on y^l the z_i^{l+1} are
            i.i.d. N(0, Q_{l+1}) with Q_{l+1} = sigma_w^2 (1/N) sum_j phi(z_j^l)^2 + sigma_b^2.
            So (Q_l) is a Markov chain that costs O(N) per layer instead of O(N^2)
            (derivations/21_finite_width_theory.md, Theorem 1).  It reproduces the full engine
            averaged over networks ("annealed" average) -- verified in tests/.

``linear``  O(1) per layer.  Exact for positively homogeneous phi (ReLU, leaky ReLU, linear) and
            the exact small-signal limit (qhat << 1) of every other phi with phi(0) = 0:
            qhat_{l+1} = qhat_l * sigma_w^2 * A_l  with A_l a scaled chi-square variable
            -> the log-signal performs a random walk (the origin of the avalanche universality class).

Avalanches (paper Methods, 'Avalanche characterization')
---------------------------------------------------------
threshold theta = sqrt(qhat_0) (the input strength).  With l_f the first layer where
sqrt(qhat_l) < theta, the avalanche has

        duration  T = l_f - 1                          (paper's D; here T to free D for the avalanche dimension)
        size      s = N^a * sum_{l=1}^{T} (sqrt(qhat_l) - theta)

a = 1/2 (default) makes s = sum_l (||z^l|| - ||z^0||), the total signal above threshold; the paper's
Fig. 2 uses a = 1/2 before the extra alignment S -> sqrt(N) S, i.e. a = 1 (as in its Fig. 3).
T = 0 events are not avalanches.  Avalanches still alive at layer L are *censored* (T = L).
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

import numpy as np

from .activations import Activation, get_activation
from .initializers import Initializer, standardized_bias_torch, standardized_weights_torch


# ----------------------------------------------------------------------
# Configuration and results
# ----------------------------------------------------------------------
@dataclass
class SimConfig:
    N: int = 300                               # width (neurons per layer)
    L: int = 400                               # depth (number of layers)
    activation: str = "tanh"
    activation_params: Dict = field(default_factory=dict)
    init: Initializer = field(default_factory=Initializer)   # weights + bias scheme
    q0: float = 0.01                           # input norm^2: ||z^0||^2 = q0  (paper: 0.01)
    engine: str = "markov"                     # 'markov' | 'full' | 'linear'
    perturbations_per_network: int = 5000      # full engine: inputs per network before re-initialising
    batch_size: int = 20000                    # markov / linear engines
    size_exponent: float = 0.5                 # a in s = N^a sum (sqrt(qhat) - theta)
    profile_range: Optional[Tuple[int, int]] = None   # store mean shapes for T in [T_lo, T_hi]
    seed: int = 0
    device: str = "auto"                       # 'auto' | 'cpu' | 'mps' | 'cuda'
    dtype: str = "auto"                        # 'auto' -> float64 on CPU, float32 on GPU/MPS
    cache_weights_gb: float = 1.0              # full engine: global cache of standardized weights (GB)

    # derived helpers ---------------------------------------------------
    @property
    def act(self) -> Activation:
        return get_activation(self.activation, **self.activation_params)

    @property
    def sigma_w2(self) -> float:
        return self.init.sigma_w2(self.N, self.N)

    @property
    def sigma_b2(self) -> float:
        return self.init.sigma_b2(self.N)


@dataclass
class Avalanches:
    S: np.ndarray                 # sizes of valid avalanches (T >= 1)
    T: np.ndarray                 # durations
    censored: np.ndarray          # True if still active at layer L
    n_perturbations: int          # inputs injected (incl. T = 0 events)
    sum_S_all: float              # sum of sizes over all perturbations (for the paper's mean size S_bar)
    profile_sums: Dict[int, np.ndarray] = field(default_factory=dict)
    profile_counts: Dict[int, int] = field(default_factory=dict)
    meta: Dict = field(default_factory=dict)

    @property
    def mean_size_all(self) -> float:
        """Paper's S_bar: sum of recorded sizes / number of recorded events (all perturbations)."""
        return self.sum_S_all / max(self.n_perturbations, 1)

    def uncensored(self):
        m = ~self.censored
        return self.S[m], self.T[m]

    def merge(self, other: "Avalanches") -> "Avalanches":
        ps = dict(self.profile_sums)
        pc = dict(self.profile_counts)
        for k, v in other.profile_sums.items():
            ps[k] = ps.get(k, 0) + v
            pc[k] = pc.get(k, 0) + other.profile_counts[k]
        return Avalanches(np.concatenate([self.S, other.S]), np.concatenate([self.T, other.T]),
                          np.concatenate([self.censored, other.censored]),
                          self.n_perturbations + other.n_perturbations, self.sum_S_all + other.sum_S_all,
                          ps, pc, self.meta)


# ----------------------------------------------------------------------
# Device helpers
# ----------------------------------------------------------------------
def resolve_device(device: str = "auto", dtype: str = "auto"):
    import torch
    if device == "auto":
        if torch.backends.mps.is_available():
            device = "mps"
        elif torch.cuda.is_available():
            device = "cuda"
        else:
            device = "cpu"
    if dtype == "auto":
        dt = torch.float64 if device == "cpu" else torch.float32
    else:
        dt = getattr(torch, dtype)
    if device == "mps" and dt == torch.float64:
        dt = torch.float32                       # MPS has no float64
    if device != "cpu" and not _device_works(device, dt):
        print(f"[qcdl] device '{device}' does not support seeded sampling here -> falling back to CPU")
        device, dt = "cpu", (torch.float64 if dtype == "auto" else dt)
    return device, dt


_DEVICE_OK: Dict = {}


def _device_works(device, dt) -> bool:
    """Check once that seeded random sampling works on this accelerator (needed for reproducibility)."""
    key = (device, str(dt))
    if key not in _DEVICE_OK:
        import torch
        try:
            g = torch.Generator(device=device)
            g.manual_seed(0)
            x = torch.randn(4, 4, generator=g, device=device, dtype=dt)
            torch.linalg.norm(x, dim=1)
            _DEVICE_OK[key] = True
        except Exception:
            _DEVICE_OK[key] = False
    return _DEVICE_OK[key]


def _gen(device, seed_tuple):
    """A torch Generator seeded deterministically from a tuple of ints."""
    import torch
    seed = int(np.random.SeedSequence(list(seed_tuple)).generate_state(1, dtype=np.uint64)[0] % (2 ** 63 - 1))
    g = torch.Generator(device=device)
    g.manual_seed(seed)
    return g


def _normalized_inputs(B, N, q0, gen, device, dtype):
    """Paper: z^0 = sqrt(q0) g / ||g||, g ~ N(0, I)  ->  ||z^0||^2 = q0, qhat_0 = q0 / N."""
    import torch
    g = torch.randn(B, N, generator=gen, device=device, dtype=dtype)
    return np.sqrt(q0) * g / torch.linalg.norm(g, dim=1, keepdim=True)


# ----------------------------------------------------------------------
# Engines
# ----------------------------------------------------------------------
class MarkovEngine:
    """Exact annealed dynamics for i.i.d. Gaussian weights (state = conditional variance Q)."""
    name = "markov"

    def __init__(self, cfg: SimConfig):
        import torch
        self.cfg = cfg
        self.device, self.dtype = resolve_device(cfg.device, cfg.dtype)
        self.phi = cfg.act.torch_phi()
        self.sw2, self.sb2 = cfg.sigma_w2, cfg.sigma_b2
        self.torch = torch
        if not cfg.init.is_paper_gaussian:
            print(f"[markov] WARNING: initializer {cfg.init.weight}/{cfg.init.bias} is not i.i.d. "
                  f"Gaussian -- the Markov reduction is then only the Gaussian (CLT) approximation.")

    def new_batch(self, batch_id: int, B: int):
        self.gen = _gen(self.device, (self.cfg.seed, 1, batch_id))
        z0 = _normalized_inputs(B, self.cfg.N, self.cfg.q0, self.gen, self.device, self.dtype)
        Q = self.sw2 * (self.phi(z0) ** 2).mean(1) + self.sb2
        qhat0 = (z0 ** 2).mean(1)
        return Q, qhat0.double().cpu().numpy()

    def step(self, Q, layer: int):
        t = self.torch
        z = t.sqrt(Q)[:, None] * t.randn(Q.shape[0], self.cfg.N, generator=self.gen,
                                         device=self.device, dtype=self.dtype)
        qhat = (z ** 2).mean(1)
        Qn = self.sw2 * (self.phi(z) ** 2).mean(1) + self.sb2
        return qhat.double().cpu().numpy(), Qn

    def select(self, Q, keep: np.ndarray):
        return Q[self.torch.as_tensor(np.where(keep)[0], device=self.device)]


# Global cache of *standardized* weights (shape only, unit variance).  Because every scheme is
# W = sqrt(sigma_w^2/N) * W_hat, the same W_hat serves an entire (sigma_w^2, sigma_b^2) sweep.
_WEIGHT_CACHE: Dict = {}
_CACHE_BYTES = [0]


def clear_weight_cache():
    _WEIGHT_CACHE.clear()
    _CACHE_BYTES[0] = 0


class FullEngine:
    """Explicit weight matrices (any initializer); one network per batch of inputs."""
    name = "full"

    def __init__(self, cfg: SimConfig):
        import torch
        self.cfg = cfg
        self.torch = torch
        self.device, self.dtype = resolve_device(cfg.device, cfg.dtype)
        self.phi = cfg.act.torch_phi()
        self.w_scale = np.sqrt(cfg.sigma_w2 / cfg.N)
        self.b_scale = np.sqrt(cfg.sigma_b2)
        init = cfg.init
        shape_params = tuple(sorted((k, v) for k, v in init.weight_params.items()
                                    if k not in ("sigma_w", "a", "gain")))
        self.key0 = (cfg.seed, cfg.N, init.weight, shape_params, init.bias, str(self.device), str(self.dtype))
        self.limit = cfg.cache_weights_gb * 1e9

    def _layer(self, net: int, layer: int):
        key = self.key0 + (net, layer)
        if key in _WEIGHT_CACHE:
            return _WEIGHT_CACHE[key]
        g = _gen(self.device, (self.cfg.seed, 2, net, layer))
        W = standardized_weights_torch(self.cfg.init, self.cfg.N, self.cfg.N, g, self.device, self.dtype)
        b = standardized_bias_torch(self.cfg.init, self.cfg.N, g, self.device, self.dtype)
        nbytes = W.element_size() * W.nelement()
        if _CACHE_BYTES[0] + nbytes <= self.limit:
            _WEIGHT_CACHE[key] = (W, b)
            _CACHE_BYTES[0] += nbytes
        return W, b

    def new_batch(self, batch_id: int, B: int):
        self.net = batch_id
        gen = _gen(self.device, (self.cfg.seed, 3, batch_id))
        z0 = _normalized_inputs(B, self.cfg.N, self.cfg.q0, gen, self.device, self.dtype)
        return z0, (z0 ** 2).mean(1).double().cpu().numpy()

    def step(self, z, layer: int):
        W, b = self._layer(self.net, layer)
        z = self.w_scale * (self.phi(z) @ W.T) + self.b_scale * b
        return (z ** 2).mean(1).double().cpu().numpy(), z

    def select(self, z, keep: np.ndarray):
        return z[self.torch.as_tensor(np.where(keep)[0], device=self.device)]


class LinearEngine:
    """
    Small-signal (linearised) dynamics, O(1) per layer, NumPy.

    With slopes a_+ = phi'(0+), a_- = phi'(0-), K ~ Bin(N, 1/2) neurons have z > 0 and
    X_+ ~ chi^2_K, X_- ~ chi^2_{N-K}:
        qhat_l      = Q_l (X_+ + X_-) / N
        Q_{l+1}     = sigma_w^2 Q_l (a_+^2 X_+ + a_-^2 X_-) / N + sigma_b^2
    (smooth phi: a_+ = a_-, and K is irrelevant).  Exact for ReLU / leaky ReLU at every q.
    """
    name = "linear"

    def __init__(self, cfg: SimConfig):
        self.cfg = cfg
        self.ap, self.am = cfg.act.slopes
        self.sw2, self.sb2 = cfg.sigma_w2, cfg.sigma_b2
        self.kinked = abs(self.ap - self.am) > 0
        if cfg.act.germ is not None and cfg.act.germ.V0 != 0:
            raise ValueError("linear engine requires phi(0) = 0")

    def _split(self, B):
        N = self.cfg.N
        r = self.rng
        if self.kinked:
            K = r.binomial(N, 0.5, size=B)
            Xp = 2.0 * r.gamma(np.maximum(K, 1e-300) / 2.0, size=B) * (K > 0)
            Xm = 2.0 * r.gamma(np.maximum(N - K, 1e-300) / 2.0, size=B) * (K < N)
            return Xp, Xm
        X = 2.0 * r.gamma(N / 2.0, size=B)
        return X, np.zeros(B)

    def new_batch(self, batch_id: int, B: int):
        self.rng = np.random.default_rng([self.cfg.seed, 4, batch_id])
        N, q0 = self.cfg.N, self.cfg.q0
        Xp, Xm = self._split(B)
        frac_p = Xp / (Xp + Xm)                  # share of ||z^0||^2 on positive neurons
        Q = self.sw2 * (q0 / N) * (self.ap ** 2 * frac_p + self.am ** 2 * (1 - frac_p)) + self.sb2
        return Q, np.full(B, q0 / N)

    def step(self, Q, layer: int):
        N = self.cfg.N
        Xp, Xm = self._split(Q.size)
        qhat = Q * (Xp + Xm) / N
        Qn = self.sw2 * Q * (self.ap ** 2 * Xp + self.am ** 2 * Xm) / N + self.sb2
        return qhat, Qn

    def select(self, Q, keep):
        return Q[keep]


ENGINES = {"markov": MarkovEngine, "full": FullEngine, "linear": LinearEngine}


def make_engine(cfg: SimConfig):
    return ENGINES[cfg.engine](cfg)


# ----------------------------------------------------------------------
# Avalanche runner
# ----------------------------------------------------------------------
def _run_batch(engine, cfg: SimConfig, batch_id: int, B: int, threshold=None):
    state, qhat0 = engine.new_batch(batch_id, B)
    theta = np.sqrt(qhat0) if threshold is None else np.full(B, float(threshold))
    alive = np.arange(B)
    T = np.zeros(B, dtype=np.int64)
    S = np.zeros(B)
    ended = np.zeros(B, dtype=bool)
    Tp = cfg.profile_range[1] if cfg.profile_range else 0
    prof = np.zeros((B, Tp)) if Tp else None
    for l in range(1, cfg.L + 1):
        qhat, state = engine.step(state, l)
        m = np.sqrt(qhat)
        th = theta[alive]
        above = m >= th
        a_idx = alive[above]
        excess = m[above] - th[above]
        T[a_idx] += 1
        S[a_idx] += excess
        if prof is not None and l <= Tp:
            prof[a_idx, l - 1] = excess
        if not above.all():
            ended[alive[~above]] = True
            state = engine.select(state, above)
            alive = a_idx
        if alive.size == 0:
            break
    S *= cfg.N ** cfg.size_exponent
    censored = ~ended
    valid = T >= 1
    ps, pc = {}, {}
    if prof is not None:
        lo, hi = cfg.profile_range
        prof *= cfg.N ** cfg.size_exponent
        for Tv in np.unique(T[valid & ~censored & (T >= lo) & (T <= hi)]):
            sel = (T == Tv) & ~censored
            ps[int(Tv)] = prof[sel, :Tv].sum(0)
            pc[int(Tv)] = int(sel.sum())
    return Avalanches(S[valid], T[valid], censored[valid], B, float(S.sum()), ps, pc)


def run_avalanches(cfg: SimConfig, n_avalanches: Optional[int] = None,
                   n_perturbations: Optional[int] = None, threshold=None,
                   verbose: bool = False, max_seconds: Optional[float] = None) -> Avalanches:
    """
    Collect avalanches until ``n_avalanches`` valid ones (T >= 1) have been recorded, or until
    ``n_perturbations`` inputs have been injected (exactly one of the two must be given).
    """
    assert (n_avalanches is None) != (n_perturbations is None), "give n_avalanches OR n_perturbations"
    engine = make_engine(cfg)
    B0 = cfg.perturbations_per_network if cfg.engine == "full" else cfg.batch_size
    out, batch_id, t0 = None, 0, time.time()
    while True:
        if n_perturbations is not None:
            done = 0 if out is None else out.n_perturbations
            if done >= n_perturbations:
                break
            B = min(B0, n_perturbations - done)
        else:
            if out is not None and out.S.size >= n_avalanches:
                break
            B = B0
        res = _run_batch(engine, cfg, batch_id, B, threshold)
        out = res if out is None else out.merge(res)
        batch_id += 1
        if verbose:
            print(f"  batch {batch_id}: {out.S.size} avalanches, {time.time() - t0:.1f}s")
        if max_seconds is not None and time.time() - t0 > max_seconds:
            break
    if n_avalanches is not None and out.S.size > n_avalanches:     # trim to exactly n
        k = n_avalanches
        out = Avalanches(out.S[:k], out.T[:k], out.censored[:k], out.n_perturbations, out.sum_S_all,
                         out.profile_sums, out.profile_counts)
    out.meta = dict(N=cfg.N, L=cfg.L, activation=cfg.activation, engine=cfg.engine,
                    sigma_w2=cfg.sigma_w2, sigma_b2=cfg.sigma_b2, init=cfg.init.describe(),
                    q0=cfg.q0, seconds=time.time() - t0, networks=batch_id)
    return out


# ----------------------------------------------------------------------
# Trajectories, stationary states and Lyapunov exponents
# ----------------------------------------------------------------------
def run_trajectories(cfg: SimConfig, B: int, L: Optional[int] = None, batch_id: int = 0) -> np.ndarray:
    """qhat_l for l = 0..L of B inputs (array B x (L+1)); no avalanche truncation."""
    L = cfg.L if L is None else L
    engine = make_engine(cfg)
    state, qhat0 = engine.new_batch(batch_id, B)
    out = np.empty((B, L + 1))
    out[:, 0] = qhat0
    for l in range(1, L + 1):
        out[:, l], state = engine.step(state, l)
    return out


def lyapunov_exponent(cfg: SimConfig, n_networks: int = 100, B: int = 16, L: int = 50):
    """
    Mean log-growth rate  lambda = E[ln qhat_{l+1} - ln qhat_l]  in the small-signal regime
    (use a tiny q0).  In that regime lambda = ln sigma_w^2 + const, hence the finite-N critical
    point is  sigma_c^2(N) = sigma_w^2 exp(-lambda)   (derivations/21, eq. W4).

    For the full engine all B inputs of one batch share a network (quenched disorder), so the
    error bar is computed from the scatter *between* networks.
    Returns (lambda, standard error, sigma_c^2 estimate, sigma_c^2 error).
    """
    per_net = []
    for b in range(n_networks):
        tr = run_trajectories(cfg, B, L, batch_id=1000 + b)
        per_net.append(np.mean((np.log(tr[:, -1]) - np.log(tr[:, 0])) / L))
    per_net = np.array(per_net)
    m, se = per_net.mean(), per_net.std(ddof=1) / np.sqrt(per_net.size)
    sc = cfg.sigma_w2 * np.exp(-m)
    return float(m), float(se), float(sc), float(sc * se)


def stationary_signal(cfg: SimConfig, B: int = 500, L_burn: int = 200, L_meas: int = 200):
    """<sqrt(qhat)> and <qhat> in the stationary state (averaged over layers and inputs)."""
    tr = run_trajectories(cfg, B, L_burn + L_meas)[:, L_burn + 1:]
    return float(np.sqrt(tr).mean()), float(tr.mean()), tr
