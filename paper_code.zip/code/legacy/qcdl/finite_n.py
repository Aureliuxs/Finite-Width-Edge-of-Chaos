"""
finite_n.py
===========

Finite-width (finite-N) theory.  Derivations: derivations/21_finite_width_theory.md.

1. Finite-N critical point.  In the small-signal regime the per-layer growth factor of
   qhat is  sigma_w^2 A_l  with  A_l = (1/N) sum_i phi_lin(g_i)^2,  g_i ~ N(0,1) i.i.d.
   The log-signal X_l = ln qhat_l is a random walk; it has zero drift (the avalanche critical
   point) when   ln sigma_w^2 + E[ln A] = 0:

        smooth phi, slope a:   sigma_c^2(N) = (1/a^2) (N/2) exp(-psi(N/2)) = (1/a^2)(1 + 1/N + O(N^-2))   (W4)

   (psi = digamma).  Non-Gaussian i.i.d. weights with excess kurtosis kappa_w add
   Var(ln A) -> Var(ln A) + 3 kappa_w / N^2, i.e. sigma_c^2 -> sigma_c^2 exp(3 kappa_w / (2 N^2)).  (W7)

2. Brownian-excursion avalanche class.  At sigma_c^2(N) the log-signal is a driftless random walk
   started *at* the threshold, so the avalanches are its excursions:

        P(T >= n) = binom(2n, n) / 4^n            (Sparre Andersen; exact for symmetric steps)
        tau_t = 3/2,   <s>_T ∝ T^{3/2}  (D/z = 3/2),   tau_s = 1 + (tau_t - 1)/(D/z) = 4/3,
        mean shape  <V(u)> ∝ sqrt(u (1 - u))   (semicircle),
        off criticality (drift mu):  T_xi ∝ mu^-2  (sigma_t = 1/2),  s_xi ∝ |mu|^-3 (sigma = 1/3),
        <s> ∝ |mu|^-gamma  with  gamma = (2 - tau_s)/sigma = 2.

3. Stationary distribution at finite N (Langevin / Fokker-Planck).  Near the MF critical point,
        dQ = [h + t Q - g Q^{1+theta}] dl + s Q dW,        s^2 = Var(ln A) ~ 2/N,
   whose stationary density is (Ito)
        P(Q) ∝ Q^{2 t_eff/s^2 - 2} exp{ -(2/s^2) [ h/Q + g Q^theta / theta ] }.            (W12)
   For theta = 1 this is a generalised inverse Gaussian law; at h = 0 it is a Gamma law with
   <Q> = (t - s^2/2)/g: the transition is *shifted* to t_c = s^2/2 ≈ 1/N but stays sharp
   (beta = 1): finite N rounds the Widom line but does not move the exponents.
"""
from __future__ import annotations

from functools import lru_cache
from typing import Dict

import numpy as np
from scipy.special import digamma, gammaln, polygamma

from .activations import get_activation


# ----------------------------------------------------------------------
# 1. finite-N critical point and log-noise
# ----------------------------------------------------------------------
def _elnA_kinked(N: int, ap: float, am: float, n_mc: int = 400000, seed: int = 12345):
    """E[ln A] and Var[ln A] for A = (a+^2 X+ + a-^2 X-)/N with K ~ Bin(N,1/2) (Monte Carlo)."""
    rng = np.random.default_rng(seed)
    K = rng.binomial(N, 0.5, n_mc)
    K = K[K > 0] if am == 0 else K                   # K = 0 kills a ReLU net (prob 2^-N): excluded
    Xp = 2 * rng.gamma(np.maximum(K, 1e-300) / 2) * (K > 0)
    Xm = 2 * rng.gamma(np.maximum(N - K, 1e-300) / 2) * (K < N)
    lnA = np.log((ap ** 2 * Xp + am ** 2 * Xm) / N)
    return lnA.mean(), lnA.var()


def log_growth_stats(act, N: int) -> Dict[str, float]:
    """Mean and variance of ln A (per-layer log-growth at sigma_w^2 = 1, Gaussian weights)."""
    act = get_activation(act)
    ap, am = act.slopes
    if ap == am:
        m = np.log(ap ** 2) + digamma(N / 2) + np.log(2.0 / N)
        v = polygamma(1, N / 2)
    else:
        m, v = _elnA_kinked(N, ap, am)
    return dict(mean=float(m), var=float(v))


def sigma_c2_finite_N(act, N: int, kappa_w: float = 0.0) -> float:
    """Finite-N (avalanche) critical point sigma_c^2(N), eqs. (W4), (W7)."""
    st = log_growth_stats(act, N)
    return float(np.exp(-st["mean"] + 1.5 * kappa_w / N ** 2))


# ----------------------------------------------------------------------
# 2. Brownian-excursion predictions
# ----------------------------------------------------------------------
BROWNIAN_EXCURSION = dict(tau_t=1.5, tau_s=4.0 / 3.0, D_over_z=1.5, sigma_t=0.5, sigma_s=1.0 / 3.0,
                          gamma_s=2.0, shape_exponent=0.5, D_depth=1.5, z_depth=1.0)


def sparre_andersen_survival(n):
    """P(T >= n) = binom(2n, n) 4^-n  (computed in log space, valid for large n)."""
    n = np.asarray(n, float)
    return np.exp(gammaln(2 * n + 1) - 2 * gammaln(n + 1) - n * np.log(4.0))


def sparre_andersen_pmf(n):
    """P(T = n | T >= 1) = 2 [P(T >= n) - P(T >= n+1)]  for n >= 1."""
    n = np.asarray(n, float)
    return 2.0 * (sparre_andersen_survival(n) - sparre_andersen_survival(n + 1))


def valid_fraction_exact(act, N: int, sigma_w2=None) -> float:
    """
    Exact P(T >= 1) for a normalised input (smooth phi, small signal): the first step is
    qhat_1 / qhat_0 = sigma_w^2 a^2 chi^2_N / N, so P(T >= 1) = P(chi^2_N >= N / (sigma_w^2 a^2)).
    At sigma_c^2(N) this exceeds 1/2 (0.509 for N = 100) because ln chi^2 is skewed (median > mean).
    """
    from scipy.stats import chi2
    act = get_activation(act)
    a2 = act.slopes[0] ** 2
    s2 = sigma_c2_finite_N(act.name, N) if sigma_w2 is None else sigma_w2
    return float(chi2.sf(N / (s2 * a2), N))


def sparre_andersen_expected_mle(T_min: int, T_max: int) -> float:
    """
    The value a truncated discrete power-law MLE on [T_min, T_max] *converges to* when the data
    follow the exact Sparre Andersen law.  It differs from 3/2 by corrections to scaling; comparing
    a measured tau_t with this number (instead of 3/2) removes the fitting-window bias.
    """
    from scipy.optimize import brentq
    n = np.arange(T_min, T_max + 1, dtype=float)
    p = sparre_andersen_pmf(n)
    target = np.sum(p * np.log(n)) / p.sum()

    def mean_log(tau):
        w = n ** (-tau)
        return np.sum(w * np.log(n)) / w.sum() - target
    return float(brentq(mean_log, 1.0001, 4.0))


def excursion_mean_shape(u):
    """Mean of the normalised Brownian excursion: E[e(u)] = sqrt(8/pi) sqrt(u (1-u))."""
    u = np.asarray(u, float)
    return np.sqrt(8.0 / np.pi) * np.sqrt(u * (1 - u))


def excursion_mean_size(T, q0: float, N: int, act="tanh"):
    """
    Small-excursion (T << N) prediction  <s>_T ≈ sqrt(q0) (s/2) sqrt(pi/8) T^{3/2}
    for size exponent a = 1/2 (s = sum_l (||z^l|| - ||z^0||)), with s^2 = Var(ln A).
    """
    s = np.sqrt(log_growth_stats(act, N)["var"])
    return np.sqrt(q0) * 0.5 * s * np.sqrt(np.pi / 8.0) * np.asarray(T, float) ** 1.5


# ----------------------------------------------------------------------
# 3. Stationary distribution (Langevin) and finite-N order parameter
# ----------------------------------------------------------------------
@lru_cache(maxsize=32)
def _fp_grid(name, params, n_grid):
    """Log-Q grid with V(Q) = E phi^2 and W(Q) = E phi^4 (cached: reused by every stationary_moments call)."""
    from .gauss import gauss_expect
    act = get_activation(name, **dict(params))
    x = np.linspace(-60, np.log(20.0), n_grid)
    Q = np.exp(x)
    V = gauss_expect(lambda u: act.phi(u) ** 2, Q, act.kinks)
    W4 = gauss_expect(lambda u: act.phi(u) ** 4, Q, act.kinks)
    return x, Q, V, W4


def stationary_moments(sw2, sb2, N: int, act="tanh", exact: bool = True,
                       n_grid: int = 6000) -> Dict[str, float]:
    """
    <Q>, <sqrt Q> of the stationary Fokker-Planck density of the diffusion approximation

        dQ = A(Q) dl + B(Q) dW,     P(Q) ∝ B(Q)^-2 exp( int^Q 2 A / B^2 ).

    exact=False : germ coefficients, A = h + t_eff Q - g Q^{1+theta}, B^2 = s^2 Q^2   (eq. W12)
    exact=True  : full coefficients from Gaussian quadrature,
                  A(Q) = sigma_w^2 V(Q) + h - Q + delta Q,   B^2(Q) = sigma_w^4 [E phi^4 - V^2](Q) / N,
                  with delta fixing the small-signal log-drift to its exact discrete-time value (W11).
    Returns Q = sqrtQ = 0 in the absorbing phase (density not normalisable, h = 0).
    """
    act = get_activation(act)
    g0 = act.germ
    st = log_growth_stats(act, N)
    s2 = st["var"]
    lnA1 = st["mean"] - np.log(g0.V1)
    t_eff = np.log(sw2 * g0.V1) + lnA1 + 0.5 * s2       # exact small-signal (Ito) linear drift
    if sb2 == 0 and t_eff <= s2 / 2:
        return dict(Q=0.0, sqrtQ=0.0, sqrt_qhat=0.0, t_eff=t_eff, s2=s2)
    x, Q, V, W4 = _fp_grid(act.name, tuple(sorted(act.params.items())), n_grid)
    if exact:
        B2 = sw2 ** 2 * np.maximum(W4 - V ** 2, 1e-300) / N
        t_lin = sw2 * g0.V1 - 1.0
        A = sw2 * V + sb2 - Q + (t_eff - t_lin) * Q
        # rescale B^2 so that the small-signal noise equals the exact Var[ln A] (O(1/N^2) fix)
        B2 *= s2 / (2.0 * (sw2 * g0.V1) ** 2 / N)
    else:
        A = sb2 + t_eff * Q - sw2 * g0.c * Q ** (1 + g0.theta)
        B2 = s2 * Q ** 2
    integrand = 2 * A * Q / B2                            # d/dx of int 2A/B^2 dQ
    # integrate from the large-Q end backwards: the h/Q term makes the integrand ~1/Q huge at
    # small Q, and a forward cumulative sum would destroy the O(1) structure near the peak.
    seg = 0.5 * (integrand[1:] + integrand[:-1]) * np.diff(x)
    F = -np.concatenate([np.cumsum(seg[::-1])[::-1], [0.0]])
    logp = F - np.log(B2) + x                             # density in x = ln Q
    logp -= logp.max()
    p = np.exp(logp)
    Z = np.trapezoid(p, x)
    sqrtQ = float(np.trapezoid(p * np.sqrt(Q), x) / Z)
    # the measured signal strength is sqrt(qhat) with qhat = Q chi^2_N / N  ->  extra factor E sqrt(chi^2_N/N)
    chi_factor = float(np.exp(0.5 * np.log(2.0 / N) + gammaln((N + 1) / 2) - gammaln(N / 2)))
    return dict(Q=float(np.trapezoid(p * Q, x) / Z), sqrtQ=sqrtQ, sqrt_qhat=sqrtQ * chi_factor,
                t_eff=float(t_eff), s2=float(s2))
