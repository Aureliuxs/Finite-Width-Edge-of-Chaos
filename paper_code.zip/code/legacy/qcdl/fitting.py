"""
fitting.py
==========

Statistical tools for extracting critical exponents.

* ``loglog_fit``              : straight line through the last points of a log-log plot
* ``fit_powerlaw``            : maximum-likelihood exponent of P(x) ∝ x^{-tau} on [x_min, x_max]
                                (continuous or discrete, optionally truncated), with Fisher errors
* ``find_xmin``               : Clauset-Shalizi-Newman KS choice of the lower cut-off
* ``bootstrap_powerlaw``      : bootstrap uncertainty of tau
* ``log_bin`` / ``adaptive_bin`` : PDFs for plotting (Christensen & Moloney App. E / paper Methods)
* ``size_duration_fit``       : <s>_T ∝ T^{D/z}, weighted least squares (paper Methods)
* ``shape_collapse``          : optimal collapse exponent of mean avalanche shapes (paper eqs. 10-14)
* ``fss_extrapolate``         : tau(N) = tau_inf + c N^{-omega}
* ``moment_analysis``         : Christensen & Moloney sec. 3.7:  <s^k> ∝ L^{D(1+k-tau_s)}
"""
from __future__ import annotations

from typing import Dict, Optional, Sequence

import numpy as np
from scipy.optimize import curve_fit, minimize_scalar
from scipy.special import zeta


# ----------------------------------------------------------------------
# Straight lines on log-log axes
# ----------------------------------------------------------------------
def loglog_fit(x, y, n_last: Optional[int] = None, window=None, weights=None) -> Dict:
    """
    Least-squares fit  log y = slope * log x + intercept.

    n_last : use only the last n points of the arrays as given (e.g. the points closest to
             the critical point if x is ordered away from it)
    window : (x_lo, x_hi) alternative selection by value
    Returns slope, its standard error, intercept, and the fitted points (for plotting).
    """
    x, y = np.asarray(x, float), np.asarray(y, float)
    ok = np.isfinite(x) & np.isfinite(y) & (x > 0) & (y > 0)
    idx = np.where(ok)[0]
    if window is not None:
        idx = idx[(x[idx] >= window[0]) & (x[idx] <= window[1])]
    if n_last is not None:
        idx = idx[-n_last:]
    if idx.size < 2:
        return dict(slope=np.nan, stderr=np.nan, intercept=np.nan, x=x[idx], y=y[idx], n=idx.size)
    lx, ly = np.log(x[idx]), np.log(y[idx])
    w = None if weights is None else np.asarray(weights, float)[idx]
    if idx.size == 2:
        p = np.polyfit(lx, ly, 1, w=w)
        se = np.nan
    else:
        p, cov = np.polyfit(lx, ly, 1, w=w, cov="unscaled" if w is not None else True)
        se = float(np.sqrt(cov[0, 0]))
    return dict(slope=float(p[0]), stderr=se, intercept=float(p[1]), x=x[idx], y=y[idx], n=idx.size)


# ----------------------------------------------------------------------
# Maximum-likelihood power laws
# ----------------------------------------------------------------------
def _neg_loglik(tau, x, xmin, xmax, discrete, sumlog, n):
    if discrete:
        if xmax is None:
            Z = zeta(tau, xmin)
        else:
            k = np.arange(xmin, xmax + 1, dtype=float)
            Z = np.sum(k ** (-tau))
    else:
        if xmax is None:
            Z = xmin ** (1 - tau) / (tau - 1)
        else:
            Z = (xmin ** (1 - tau) - xmax ** (1 - tau)) / (tau - 1)
    return tau * sumlog + n * np.log(Z)


def fit_powerlaw(x, xmin, xmax=None, discrete: bool = False, bounds=(1.001, 5.0)) -> Dict:
    """
    MLE of tau for P(x) ∝ x^{-tau}, x in [xmin, xmax] (xmax=None: untruncated).
    The error bar is the inverse square root of the observed Fisher information.
    """
    x = np.asarray(x, float)
    sel = x >= xmin
    if xmax is not None:
        sel &= x <= xmax
    xs = x[sel]
    n = xs.size
    if n < 10:
        return dict(tau=np.nan, err=np.nan, n=n, xmin=xmin, xmax=xmax)
    sumlog = np.sum(np.log(xs))
    f = lambda t: _neg_loglik(t, xs, xmin, xmax, discrete, sumlog, n)
    r = minimize_scalar(f, bounds=bounds, method="bounded", options=dict(xatol=1e-7))
    tau = float(r.x)
    h = 1e-4
    d2 = (f(tau + h) - 2 * f(tau) + f(tau - h)) / h ** 2
    err = float(1.0 / np.sqrt(d2)) if d2 > 0 else np.nan
    return dict(tau=tau, err=err, n=int(n), xmin=float(xmin), xmax=None if xmax is None else float(xmax),
                nll=float(r.fun))


def _model_cdf(xs_sorted, tau, xmin, xmax, discrete):
    """Model CDF evaluated at the sorted sample (for the KS distance)."""
    if discrete:
        top = xs_sorted.max() if xmax is None else xmax
        k = np.arange(xmin, top + 1, dtype=float)
        p = k ** (-tau)
        if xmax is None:
            p = p / zeta(tau, xmin)
        else:
            p = p / p.sum()
        cdf = np.cumsum(p)
        return cdf[(xs_sorted - xmin).astype(int)]
    if xmax is None:
        return 1 - (xs_sorted / xmin) ** (1 - tau)
    return (1 - (xs_sorted / xmin) ** (1 - tau)) / (1 - (xmax / xmin) ** (1 - tau))


def ks_distance(x, tau, xmin, xmax=None, discrete=False):
    x = np.asarray(x, float)
    sel = x >= xmin
    if xmax is not None:
        sel &= x <= xmax
    xs = np.sort(x[sel])
    n = xs.size
    if n == 0:
        return np.nan
    F = _model_cdf(xs, tau, xmin, xmax, discrete)
    emp_hi = np.arange(1, n + 1) / n
    emp_lo = np.arange(0, n) / n
    return float(max(np.max(np.abs(emp_hi - F)), np.max(np.abs(emp_lo - F))))


def find_xmin(x, discrete=False, xmax=None, candidates=None, min_tail: int = 200) -> Dict:
    """
    Clauset, Shalizi & Newman (2009): choose x_min minimising the KS distance between the data
    above x_min and the fitted power law.  Returns the best fit dict (with 'ks').
    """
    x = np.asarray(x, float)
    if candidates is None:
        pos = x[x > 0]
        lo, hi = np.quantile(pos, [0.0, 0.99])
        candidates = np.unique(np.round(np.logspace(np.log10(max(lo, 1 if discrete else lo)),
                                                    np.log10(hi), 40))) if discrete \
            else np.logspace(np.log10(lo), np.log10(hi), 40)
    best = None
    for xm in candidates:
        if np.sum(x >= xm) < min_tail:
            break
        fr = fit_powerlaw(x, xm, xmax, discrete)
        if not np.isfinite(fr["tau"]):
            continue
        fr["ks"] = ks_distance(x, fr["tau"], xm, xmax, discrete)
        if best is None or fr["ks"] < best["ks"]:
            best = fr
    return best if best is not None else dict(tau=np.nan, err=np.nan, xmin=np.nan, ks=np.nan, n=0)


def bootstrap_powerlaw(x, xmin, xmax=None, discrete=False, n_boot: int = 200, seed: int = 0) -> float:
    """Bootstrap standard deviation of the MLE exponent (x_min held fixed)."""
    rng = np.random.default_rng(seed)
    x = np.asarray(x, float)
    taus = [fit_powerlaw(rng.choice(x, x.size, replace=True), xmin, xmax, discrete)["tau"]
            for _ in range(n_boot)]
    return float(np.nanstd(taus))


def fit_powerlaw_package(x, discrete=False, xmin=None, xmax=None):
    """Same fit with the `powerlaw` package (Alstott et al. 2014) used by the paper, if installed."""
    import powerlaw  # noqa
    f = powerlaw.Fit(np.asarray(x), discrete=discrete, xmin=xmin, xmax=xmax, verbose=False)
    return dict(tau=float(f.power_law.alpha), err=float(f.power_law.sigma), xmin=float(f.xmin))


# ----------------------------------------------------------------------
# Binned PDFs (for plotting only; exponents always come from the MLE)
# ----------------------------------------------------------------------
def log_bin(x, a: float = 1.25, discrete: bool = False, x_min=None):
    """
    Logarithmic binning (Christensen & Moloney, Appendix E).  Bin j is [x_min a^j, x_min a^{j+1});
    for discrete data the bin width is the number of integers it contains.  Returns
    (bin centres = geometric means, PDF).
    """
    x = np.asarray(x, float)
    x = x[x > 0]
    if x.size == 0:
        return np.array([]), np.array([])
    x0 = x.min() if x_min is None else x_min
    nb = int(np.ceil(np.log(x.max() / x0) / np.log(a))) + 2
    edges = x0 * a ** np.arange(nb)
    if discrete:
        edges = np.unique(np.ceil(edges - 1e-9))
    counts, _ = np.histogram(x, bins=edges)
    widths = np.diff(edges)
    centres = np.sqrt(edges[:-1] * np.maximum(edges[1:] - (1 if discrete else 0), edges[:-1]))
    pdf = counts / (x.size * widths)
    ok = counts > 0
    return centres[ok], pdf[ok]


def adaptive_bin(x, k: int = 50):
    """Paper's adaptive binning: each bin contains at least k points (dense -> narrow bins)."""
    xs = np.sort(np.asarray(x, float))
    xs = xs[xs > 0]
    edges = [xs[0]]
    i = 0
    while i + k < xs.size:
        i += k
        if xs[i] > edges[-1]:
            edges.append(xs[i])
    edges.append(xs[-1] * (1 + 1e-12))
    edges = np.array(edges)
    counts, _ = np.histogram(xs, bins=edges)
    pdf = counts / (xs.size * np.diff(edges))
    centres = np.sqrt(edges[:-1] * edges[1:])
    return centres[counts > 0], pdf[counts > 0]


# ----------------------------------------------------------------------
# Scaling of average size with duration
# ----------------------------------------------------------------------
def conditional_mean(T, S):
    """<S>_T and the paper's weights w(T) = N_T / Var[log S]_T (T with >= 2 avalanches)."""
    T = np.asarray(T)
    S = np.asarray(S, float)
    order = np.argsort(T)
    T, S = T[order], S[order]
    u, start, cnt = np.unique(T, return_index=True, return_counts=True)
    mS = np.add.reduceat(S, start) / cnt
    logS = np.log(np.maximum(S, 1e-300))
    m1 = np.add.reduceat(logS, start) / cnt
    m2 = np.add.reduceat(logS ** 2, start) / cnt
    var = np.maximum(m2 - m1 ** 2, 1e-300) * cnt / np.maximum(cnt - 1, 1)
    w = np.where(cnt > 1, cnt / var, 0.0)
    return u, mS, w, cnt


def size_duration_fit(T, S, T_min=1, T_max=None) -> Dict:
    """<S>_T ∝ T^{D/z} by weighted least squares in log-log (paper Methods, 'gamma')."""
    u, mS, w, cnt = conditional_mean(T, S)
    sel = (u >= T_min) & (cnt > 1) & (mS > 0)
    if T_max is not None:
        sel &= u <= T_max
    if sel.sum() < 3:
        return dict(slope=np.nan, stderr=np.nan, T=u, meanS=mS)
    lx, ly, ww = np.log(u[sel]), np.log(mS[sel]), w[sel]
    p, cov = np.polyfit(lx, ly, 1, w=np.sqrt(ww), cov=True)
    return dict(slope=float(p[0]), stderr=float(np.sqrt(cov[0, 0])), intercept=float(p[1]),
                T=u, meanS=mS, sel=sel)


def size_duration_fit_corrected(T, S, T_min=1, T_max=None, omega: float = 0.5) -> Dict:
    """
    <S>_T = A T^{D/z} (1 + B T^{-omega}): D/z with the leading correction to scaling
    (omega = 1/2 for lattice random-walk excursions, whose area is c T^{3/2} + c' T + ...).
    Weighted non-linear least squares in log space (paper's weights).
    """
    u, mS, w, cnt = conditional_mean(T, S)
    sel = (u >= T_min) & (cnt > 1) & (mS > 0)
    if T_max is not None:
        sel &= u <= T_max
    x, y, ww = u[sel].astype(float), np.log(mS[sel]), w[sel]
    f = lambda x, lnA, a, B: lnA + a * np.log(x) + np.log(np.abs(1 + B * x ** (-omega)))
    try:
        p, cov = curve_fit(f, x, y, p0=(y[0], 1.5, 0.0), sigma=1 / np.sqrt(ww), maxfev=20000)
        return dict(slope=float(p[1]), stderr=float(np.sqrt(cov[1, 1])), B=float(p[2]))
    except Exception:  # pragma: no cover
        return dict(slope=np.nan, stderr=np.nan, B=np.nan)


# ----------------------------------------------------------------------
# Shape collapse (paper eqs. 10-14)
# ----------------------------------------------------------------------
def mean_shapes(profile_sums: Dict[int, np.ndarray], profile_counts: Dict[int, int],
                T_min: int, T_max: int, min_count: int = 20, n_grid: int = 50):
    """Mean avalanche profiles V_T(u_j), interpolated on u_j = (j + 1/2)/n_grid."""
    u = (np.arange(n_grid) + 0.5) / n_grid
    Ts, shapes = [], []
    for T in sorted(profile_sums):
        if T_min <= T <= T_max and profile_counts[T] >= min_count:
            prof = profile_sums[T] / profile_counts[T]
            l = (np.arange(1, T + 1) - 0.5) / T            # layer l = 1..T mapped to (0, 1)
            Ts.append(T)
            shapes.append(np.interp(u, l, prof))
    return np.array(Ts), u, np.array(shapes)


def nmse(gamma, Ts, shapes):
    resc = shapes / Ts[:, None] ** (gamma - 1.0)
    mean = resc.mean(axis=0)
    return float(np.sum((resc - mean) ** 2) / np.sum(mean ** 2))


def shape_collapse(Ts, shapes, gamma_grid=None, n_fit: int = 15) -> Dict:
    """gamma* = argmin NMSE(gamma), error sigma = sqrt(1/(2a)) from a local parabola (eq. 14)."""
    if gamma_grid is None:
        gamma_grid = np.linspace(1.0, 2.5, 1501)
    err = np.array([nmse(g, Ts, shapes) for g in gamma_grid])
    j = int(np.argmin(err))
    lo, hi = max(j - n_fit, 0), min(j + n_fit + 1, gamma_grid.size)
    a, b, c = np.polyfit(gamma_grid[lo:hi], err[lo:hi], 2)
    sig = float(np.sqrt(1.0 / (2 * a))) if a > 0 else np.nan
    return dict(gamma=float(gamma_grid[j]), err=sig, grid=gamma_grid, nmse=err)


# ----------------------------------------------------------------------
# Finite-size scaling
# ----------------------------------------------------------------------
def fss_extrapolate(Ns, taus, errs=None, omega0: float = 0.5) -> Dict:
    """Fit tau(N) = tau_inf + c N^{-omega} (paper Fig. 2 d-e)."""
    Ns, taus = np.asarray(Ns, float), np.asarray(taus, float)
    f = lambda N, ti, c, om: ti + c * N ** (-om)
    try:
        p, cov = curve_fit(f, Ns, taus, p0=(taus[-1], (taus[0] - taus[-1]) * Ns[0] ** omega0, omega0),
                           sigma=errs, absolute_sigma=errs is not None, maxfev=20000,
                           bounds=([1.0, -np.inf, 0.05], [2.5, np.inf, 3.0]))
        e = np.sqrt(np.diag(cov))
        return dict(tau_inf=float(p[0]), tau_inf_err=float(e[0]), c=float(p[1]), omega=float(p[2]),
                    omega_err=float(e[2]), model=lambda N: f(np.asarray(N, float), *p))
    except Exception as ex:  # pragma: no cover
        return dict(tau_inf=np.nan, tau_inf_err=np.nan, omega=np.nan, error=str(ex), model=None)


def moment_analysis(samples: Dict[float, np.ndarray], ks: Sequence[float] = (1, 1.5, 2, 2.5, 3, 3.5, 4),
                    n_last: Optional[int] = None) -> Dict:
    """
    Christensen & Moloney sec. 3.7 (moment analysis).  For a finite-size scaling form
    P(s; L) = s^{-tau_s} G(s / L^D),  the k-th moment scales as

            <s^k>  ∝  L^{D (1 + k - tau_s)}      for k > tau_s - 1.

    Fitting log <s^k> vs log L gives slopes sigma_k; a straight line sigma_k = D k + D(1 - tau_s)
    then yields the avalanche dimension D (slope) and tau_s (from the intercept).
    """
    Ls = np.array(sorted(samples))
    ks = np.asarray(ks, float)
    moments = np.array([[np.mean(np.asarray(samples[L], float) ** k) for L in Ls] for k in ks])
    slopes, errs = [], []
    for row in moments:
        fr = loglog_fit(Ls, row, n_last=n_last)
        slopes.append(fr["slope"])
        errs.append(fr["stderr"])
    slopes, errs = np.array(slopes), np.array(errs)
    p, cov = np.polyfit(ks, slopes, 1, cov=True)
    D = float(p[0])
    tau = 1.0 - float(p[1]) / D
    return dict(Ls=Ls, ks=ks, moments=moments, sigma_k=slopes, sigma_k_err=errs, D=D,
                D_err=float(np.sqrt(cov[0, 0])), tau_s=tau, intercept=float(p[1]))
