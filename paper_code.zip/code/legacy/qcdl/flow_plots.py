"""
flow_plots.py
=============

"Statistical-physics" pictures of the mean-field variance map  q_{l+1} = F(q_l) = sigma_w^2 V(q_l) + sigma_b^2
for one activation at a time (no simulations -- pure algebra of the map):

  (a) F(q) vs q with the diagonal F = q, several sigma_w^2, sigma_b^2 = 0; fixed points marked
      (filled = stable |F'| < 1, open = unstable) and one cobweb (the iteration through depth).
  (b) the same with a field sigma_b^2 > 0.
  (c) flow diagram in the (sigma_w^2, q_0) plane at sigma_b^2 = 0: background = sign of G(q) = F(q) - q
      (red: the signal grows, blue: it decays), arrows = direction of the flow of an input q_0 through depth,
      lines of dots = fixed-point branches (the bifurcation diagram).
  (d) the same at sigma_b^2 > 0.
  (e) the (sigma_w^2, sigma_b^2) plane: stationary signal q* (colour), run-away region (grey), critical point.
  (f) depth trajectories q_l for sigma_w^2 below / at / above the critical value.

Plus: activation shapes grouped by class, and cross-activation summaries (V(q)/q and the germ).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import ListedColormap, LogNorm

from .activations import get_activation
from .meanfield import MeanField
from .plotting import (BLUE, CMAP_COOL, DEEP_BLUE, DEEP_RED, FIT_COLOR, INK, LIGHT_BLUE, ORANGE, RED, dots,
                       label)

GROW, DECAY = "#F7D9D4", "#DCE8F5"          # background tints: growth / decay of the signal
STABLE, UNSTABLE = DEEP_BLUE, RED

CLASSES = {
    "I": ("smooth and odd (tanh-like)", ["tanh", "erf"]),
    "II": ("different curvature on the two sides of 0 (ELU-like)", ["elu", "selu"]),
    "III": ("piecewise linear (ReLU-like)", ["relu", "leaky_relu"]),
    "IV": ("smooth but not odd (GELU-like)", ["gelu", "silu"]),
    "V": ("non-zero at the origin (sigmoid-like)", ["sigmoid", "softplus"]),
    "VI": ("linear near 0, kinks away from 0 (hard-tanh)", ["hardtanh"]),
}


@dataclass
class FlowSpec:
    """Plot ranges for one activation."""
    sw2_list: Sequence[float]                 # curves in panels (a), (b)
    sw2_range: Tuple[float, float]            # x-range of panels (c)-(f)
    q_max: float = 1.5                        # x-range of panels (a), (b)
    q_log: Tuple[float, float] = (1e-5, 10.0)  # y-range of (c), (d)
    h_flow: float = 1e-3                      # field used in (b) is h_F, in (d) h_flow
    h_F: float = 0.05
    traj_sw2: Optional[Sequence[float]] = None
    traj_q0: float = 1.0
    act_params: Dict = field(default_factory=dict)


SPECS: Dict[str, FlowSpec] = {
    "tanh": FlowSpec([0.6, 1.0, 1.4, 2.0], (0.4, 2.0)),
    "erf": FlowSpec([0.5, np.pi / 4, 1.1, 1.6], (0.3, 1.6)),
    "sigmoid": FlowSpec([4.0, 10.0, 16.0, 30.0], (1.0, 32.0), q_max=8.0, q_log=(1e-2, 30.0),
                        traj_sw2=[4.0, 16.0, 30.0]),
    "relu": FlowSpec([1.0, 1.6, 2.0, 2.4], (0.5, 3.0), q_max=2.0),
    "leaky_relu": FlowSpec([1.0, 1.6, 2.0, 2.4], (0.5, 3.0), q_max=2.0, act_params={"alpha": 0.1}),
    "elu": FlowSpec([0.6, 1.0, 1.5, 2.4], (0.4, 2.8), q_max=3.0),
    "selu": FlowSpec([0.3, 0.4768, 0.9, 2.0], (0.2, 2.4), q_max=3.0),
    "gelu": FlowSpec([1.5, 2.5, 3.5, 4.5], (1.0, 5.5), q_max=1.2, q_log=(1e-5, 30.0),
                     traj_sw2=[3.0, 4.0, 5.0], traj_q0=0.05),
    "silu": FlowSpec([1.5, 2.5, 3.5, 4.5], (1.0, 5.5), q_max=1.2, q_log=(1e-5, 30.0),
                     traj_sw2=[3.0, 4.0, 5.0], traj_q0=0.05),
    "softplus": FlowSpec([0.5, 1.0, 1.6, 2.4], (0.2, 3.0), q_max=4.0, q_log=(1e-2, 30.0),
                         traj_sw2=[0.5, 1.5, 2.4]),
    "hardtanh": FlowSpec([0.6, 1.0, 1.4, 2.0], (0.4, 2.0)),
}


def _curve_colors(n):
    from matplotlib.colors import LinearSegmentedColormap
    cm = LinearSegmentedColormap.from_list("c", [DEEP_BLUE, BLUE, ORANGE, RED, DEEP_RED])
    return [cm(x) for x in np.linspace(0, 1, n)]


# ----------------------------------------------------------------------
# Fixed points on a grid
# ----------------------------------------------------------------------
def fixed_points(mf: MeanField, sw2: float, h: float, q: np.ndarray, V: np.ndarray):
    """All fixed points of F on the grid q (sign changes of G = F - q, refined linearly), with stability.
    q = 0 is included when it is a fixed point (V0 = 0 and h = 0)."""
    G = sw2 * V + h - q
    out = []
    s = np.sign(G)
    idx = np.where(s[:-1] * s[1:] < 0)[0]
    for i in idx:
        x0, x1, g0, g1 = q[i], q[i + 1], G[i], G[i + 1]
        qs = x0 - g0 * (x1 - x0) / (g1 - g0)
        slope = sw2 * float(mf.dV(np.array([qs]))[0])
        out.append((qs, abs(slope) < 1.0))
    if h == 0 and mf.act.germ.V0 == 0:
        out.append((0.0, sw2 * mf.act.germ.V1 < 1.0))
    return out


def _mark(ax, fps, x=None, y=None, size=38, label_once=None):
    """Fixed points: filled = stable, open = unstable."""
    for k, (qs, st) in enumerate(fps):
        xx = qs if x is None else x
        yy = qs if y is None else y
        ax.scatter(xx, yy, s=size, zorder=6, facecolors=STABLE if st else "white",
                   edgecolors=STABLE if st else UNSTABLE, linewidths=1.3)


# ----------------------------------------------------------------------
# Panels
# ----------------------------------------------------------------------
def panel_F(ax, mf: MeanField, spec: FlowSpec, h: float, title: str):
    q = np.linspace(0, spec.q_max, 700)
    V = mf.V(q)
    cols = _curve_colors(len(spec.sw2_list))
    ax.plot(q, q, "--", color=FIT_COLOR, lw=1.1, label="$F(q)=q$")
    for c, s in zip(cols, spec.sw2_list):
        F = s * V + h
        ax.plot(q, F, "-", color=c, lw=1.6, label=f"$\\sigma_w^2={s:.3g}$")
        _mark(ax, [fp for fp in fixed_points(mf, s, h, q, V) if fp[0] > 0])
    # cobweb for the curve closest to (just above) the critical value
    s_cw = spec.sw2_list[min(2, len(spec.sw2_list) - 1)]
    traj = [0.9 * spec.q_max]
    for _ in range(25):
        traj.append(s_cw * float(mf.V(np.array([traj[-1]]))[0]) + h)
        if traj[-1] > spec.q_max * 1.2:
            break
    path = np.repeat(np.array(traj), 2)
    ax.plot(path[:-1], path[1:], "-", color="#9A9A9A", lw=0.7, zorder=2, label=f"cobweb, $\\sigma_w^2={s_cw:.3g}$")
    ax.scatter([], [], s=38, facecolors=STABLE, edgecolors=STABLE, label="stable fixed point")
    ax.scatter([], [], s=38, facecolors="white", edgecolors=UNSTABLE, label="unstable fixed point")
    ax.set_xlim(0, spec.q_max)
    ax.set_ylim(0, spec.q_max * 1.15)
    label(ax, "$q$", "$F(q)$", title)
    ax.legend(fontsize=6.8, loc="upper left")


def panel_flow(ax, mf: MeanField, spec: FlowSpec, h: float, title: str, n_sw=260, n_q=260):
    """Flow of an input signal q_0 in the (sigma_w^2, q_0) plane + fixed-point branches."""
    sw = np.linspace(*spec.sw2_range, n_sw)
    q = np.logspace(np.log10(spec.q_log[0]), np.log10(spec.q_log[1]), n_q)
    V = mf.V(q)
    Gsign = np.sign(sw[None, :] * V[:, None] + h - q[:, None])
    ax.pcolormesh(sw, q, Gsign, cmap=ListedColormap([DECAY, "#FFFFFF", GROW]), vmin=-1, vmax=1,
                  shading="nearest", rasterized=True)
    # arrows: direction and (log) strength of one layer's change ln(F/q)
    swa = np.linspace(*spec.sw2_range, 15)
    qa = np.logspace(np.log10(spec.q_log[0]), np.log10(spec.q_log[1]), 13)
    SW, QA = np.meshgrid(swa, qa)
    Va = mf.V(QA)
    r = np.log((SW * Va + h) / QA)
    L = np.tanh(2 * np.abs(r))
    for x, y, rr, ll in zip(SW.ravel(), QA.ravel(), r.ravel(), L.ravel()):
        if ll < 0.03:
            continue
        fac = np.exp(np.sign(rr) * 0.75 * ll * np.log(spec.q_log[1] / spec.q_log[0]) / 13)
        ax.annotate("", xy=(x, y * fac), xytext=(x, y), zorder=3,
                    arrowprops=dict(arrowstyle="-|>", color="#5A5A5A", lw=1.0, mutation_scale=9))
    # fixed-point branches
    swb = np.linspace(*spec.sw2_range, 120)
    qf = np.logspace(np.log10(spec.q_log[0]) - 2, np.log10(spec.q_log[1]) + 1, 1400)
    Vf = mf.V(qf)
    first_s = first_u = True
    for s in swb:
        for qs, st in fixed_points(mf, s, h, qf, Vf):
            if qs <= 0 or not (spec.q_log[0] <= qs <= spec.q_log[1]):
                continue
            ax.scatter(s, qs, s=9, zorder=5, facecolors=STABLE if st else "white",
                       edgecolors=STABLE if st else UNSTABLE, linewidths=0.8,
                       label=("stable branch $q^*$" if st and first_s else
                              ("unstable branch (threshold)" if (not st) and first_u else None)))
            first_s = first_s and not st
            first_u = first_u and st
    g = mf.act.germ
    if g.V0 == 0 and h == 0:   # the absorbing state q* = 0 lives below the axis: show its stability on the edge
        yb = spec.q_log[0] * 1.12
        st = sw <= g.sigma_w2_c
        ax.plot(sw[st], np.full(st.sum(), yb), "-", color=STABLE, lw=4, solid_capstyle="butt", zorder=6,
                label="$q^*=0$ stable (absorbing)")
        ax.plot(sw[~st], np.full((~st).sum(), yb), "-", color=UNSTABLE, lw=4, alpha=0.6, solid_capstyle="butt",
                zorder=6, label="$q^*=0$ unstable")
    if g.V0 == 0:
        ax.axvline(g.sigma_w2_c, color=INK, ls=":", lw=1.0, label=f"$\\sigma_{{w,c}}^2={g.sigma_w2_c:.3g}$")
    if g.r_inf > 0 and spec.sw2_range[0] < 1 / g.r_inf < spec.sw2_range[1]:
        ax.axvline(1 / g.r_inf, color=DEEP_RED, ls="-.", lw=1.0,
                   label=f"run-away for $\\sigma_w^2>1/r_\\infty={1 / g.r_inf:.3g}$")
    ax.fill_between([], [], color=GROW, label="$F(q)>q$: signal grows")
    ax.fill_between([], [], color=DECAY, label="$F(q)<q$: signal decays")
    ax.set_yscale("log")
    ax.set_xlim(*spec.sw2_range)
    ax.set_ylim(*spec.q_log)
    label(ax, "$\\sigma_w^2$", "$q_0$", title)
    ax.legend(fontsize=6.5, loc="lower right", framealpha=0.85, frameon=True)


def panel_plane(ax, mf: MeanField, spec: FlowSpec, title: str, q_init: float = 1e-2):
    """Stationary signal q* over (sigma_w^2, sigma_b^2), starting from q_init."""
    sw = np.linspace(*spec.sw2_range, 170)
    sb = np.logspace(-6, 0, 110)
    W, H = np.meshgrid(sw, sb)
    Q = mf.fixed_point(W, H, q_init=q_init)
    run = ~np.isfinite(Q)
    Qp = np.where(np.isfinite(Q) & (Q > 0), Q, np.nan)
    m = ax.pcolormesh(sw, sb, Qp, cmap=CMAP_COOL, norm=LogNorm(vmin=max(np.nanmin(Qp), 1e-6), vmax=np.nanmax(Qp)),
                      shading="nearest", rasterized=True)
    if run.any():
        ax.pcolormesh(sw, sb, np.where(run, 1.0, np.nan), cmap=ListedColormap(["#BDBDBD"]), shading="nearest",
                      rasterized=True)
        ax.fill_between([], [], color="#BDBDBD", label="run-away ($q_\\ell\\to\\infty$)")
    cb = plt.colorbar(m, ax=ax, pad=0.02)
    cb.ax.set_title("$q^*$", fontsize=10, pad=6)
    cb.outline.set_visible(False)
    g = mf.act.germ
    if g.V0 == 0:
        ax.scatter([g.sigma_w2_c], [1.1e-6], marker="*", s=160, color=RED, zorder=6, clip_on=False,
                   label="critical point $(\\sigma_{w,c}^2, 0)$")
        if np.isfinite(g.theta) and g.c > 0:
            se, he, _ = mf.edge_of_chaos(np.logspace(-8, 1, 400))
            ok = (he >= 1e-6) & (se <= spec.sw2_range[1])
            ax.plot(se[ok], he[ok], "--", color=INK, lw=1.1, label="edge of chaos")
    ax.set_yscale("log")
    ax.set_xlim(*spec.sw2_range)
    label(ax, "$\\sigma_w^2$", "$\\sigma_b^2$", title)
    if ax.get_legend_handles_labels()[0]:
        ax.legend(fontsize=6.8, loc="upper left", framealpha=0.85, frameon=True)


def panel_traj(ax, mf: MeanField, spec: FlowSpec, title: str, L: int = 10000):
    g = mf.act.germ
    q0 = spec.traj_q0
    lq, lV = np.log(mf.q_grid), np.log(np.maximum(mf.V_grid, 1e-320))
    sws = spec.traj_sw2 or ([0.8 * g.sigma_w2_c, g.sigma_w2_c, 1.2 * g.sigma_w2_c])
    cols = [BLUE, INK, RED]
    for c, s in zip(cols, sws):
        q = [q0]
        for _ in range(L):
            nxt = s * float(np.exp(np.interp(np.log(q[-1]), lq, lV))) if q[-1] > 0 else 0.0
            q.append(nxt)
            if nxt < 1e-12 or nxt > 1e6:
                break
        q = np.array(q)
        l = np.arange(q.size)
        sel = np.unique(np.logspace(0, np.log10(max(l.size - 1, 1)), 70).astype(int))
        if g.V0 == 0:
            rel = s / g.sigma_w2_c - 1
            tag = " (at $\\sigma_{w,c}^2$)" if abs(rel) < 1e-9 else (" (below)" if rel < 0 else " (above)")
        else:
            tag = ""
        dots(ax, l[sel], q[sel], color=c, size=12, label_=f"$\\sigma_w^2={s:.3g}${tag}")
    if g.V0 == 0 and np.isfinite(g.theta) and g.c > 0:
        ll = np.logspace(1.5, np.log10(L), 20)
        amp = (g.theta * g.c / g.V1 * ll) ** (-1 / g.theta)
        ax.plot(ll, amp, "--", color=FIT_COLOR, lw=1.1,
                label=f"$(\\vartheta\\,\\sigma_w^2 c\\,\\ell)^{{-1/\\vartheta}}\\propto\\ell^{{-{1 / g.theta:.3g}}}$")
    ax.set_xscale("log")
    ax.set_yscale("log")
    label(ax, "$\\ell$", "$q_\\ell$", title)
    ax.legend(fontsize=6.8, loc="lower left")


def activation_figure(name: str, spec: Optional[FlowSpec] = None):
    spec = spec or SPECS[name]
    mf = MeanField(name, **spec.act_params)
    act = mf.act
    fig, axs = plt.subplots(2, 3, figsize=(17, 10.2))
    a = axs.ravel()
    panel_F(a[0], mf, spec, 0.0, "(a) variance map, $\\sigma_b^2=0$")
    panel_F(a[1], mf, spec, spec.h_F, f"(b) variance map, $\\sigma_b^2={spec.h_F:g}$")
    panel_flow(a[2], mf, spec, 0.0, "(c) flow of $q_0$ through depth, $\\sigma_b^2=0$")
    panel_flow(a[3], mf, spec, spec.h_flow, f"(d) flow of $q_0$, $\\sigma_b^2={spec.h_flow:g}$")
    panel_plane(a[4], mf, spec, "(e) stationary signal $q^*$ ($q_0=10^{-2}$)")
    panel_traj(a[5], mf, spec, f"(f) depth profiles from $q_0={spec.traj_q0:g}$, $\\sigma_b^2=0$")
    extra = f" ($\\alpha$={act.params['alpha']})" if "alpha" in act.params else ""
    k = [c for c, (_, ns) in CLASSES.items() if name in ns][0]
    fig.suptitle(f"{name}{extra} — Class {k}: {CLASSES[k][0]}", y=1.0, fontsize=14)
    fig.tight_layout()
    return fig


# ----------------------------------------------------------------------
# Activation shapes by class and cross-activation summaries
# ----------------------------------------------------------------------
def class_shapes_figure():
    fig, axs = plt.subplots(2, 3, figsize=(15, 8.6))
    x = np.linspace(-3, 3, 600)
    for ax, (k, (desc, names)) in zip(axs.ravel(), CLASSES.items()):
        ax.axhline(0, color="#C8C8C8", lw=0.6)
        ax.axvline(0, color="#C8C8C8", lw=0.6)
        ax.plot(x, x, ":", color="#9A9A9A", lw=1.0, label="$y=x$")
        for c, nm in zip([BLUE, RED], names):
            p = {"alpha": 0.1} if nm == "leaky_relu" else {}
            act = get_activation(nm, **p)
            lab = nm + (" ($\\alpha=0.1$)" if p else "")
            ax.plot(x, act.phi(x), "-", color=c, lw=2.0, label=lab)
            ax.plot(x, act.dphi(x), "--", color=c, lw=1.0, alpha=0.8, label=f"{nm}$'$")
        ax.set_xlim(-3, 3)
        ax.set_ylim(-2.2, 3.2)
        label(ax, "$x$", "$\\phi(x)$", f"Class {k}: {desc}")
        ax.legend(fontsize=7.5, loc="upper left")
    fig.suptitle("Activation functions by universality class (solid: $\\phi$, dashed: $\\phi'$)", fontsize=14)
    fig.tight_layout()
    return fig


def summary_figure():
    """V(q)/q and the germ |V0 + V1 q - V(q)| for all activations."""
    fig, axs = plt.subplots(1, 3, figsize=(17, 4.9))
    cls_col = {"I": BLUE, "II": RED, "III": ORANGE, "IV": DEEP_RED, "V": DEEP_BLUE, "VI": LIGHT_BLUE}
    q = np.logspace(-6, 4, 300)
    qg = np.logspace(-7, -0.5, 120)
    for k, (desc, names) in CLASSES.items():
        for j, nm in enumerate(names):
            mf = MeanField(nm)
            g = mf.act.germ
            ls = "-" if j == 0 else "--"
            axs[0].plot(q, mf.V(q) / q, ls, color=cls_col[k], lw=1.6, label=f"{k}: {nm}")
            if g.V0 == 0:
                r = np.abs(g.V1 * qg - mf.V(qg)) / g.V1
                ok = r > 1e-15 * qg
                axs[1].plot(qg[ok], r[ok], ls, color=cls_col[k], lw=1.6, label=f"{k}: {nm}")
                if np.isfinite(g.theta) and g.c > 0:
                    t = np.logspace(-6, -1, 40)
                    qs = mf.fixed_point(g.sigma_w2_c * (1 + t), 0.0)
                    dots(axs[2], t, qs, color=cls_col[k], size=10, label_=f"{k}: {nm}",
                         marker="o" if j == 0 else "s")
    axs[0].set_xscale("log"); axs[0].set_yscale("log")
    axs[0].set_ylim(0.05, 5)
    label(axs[0], "$q$", "$V(q)/q$", "effective gain: $V_1$ as $q\\to0$, $r_\\infty$ as $q\\to\\infty$")
    axs[0].legend(fontsize=7, ncol=2)
    qq = np.logspace(-6, -1, 10)
    axs[1].plot(qq, 0.3 * qq ** 2, ":", color=INK, lw=1, label="$\\propto q^{2}$ ($\\vartheta=1$)")
    axs[1].plot(qq, 0.3 * qq ** 1.5, "-.", color=INK, lw=1, label="$\\propto q^{3/2}$ ($\\vartheta=1/2$)")
    axs[1].set_xscale("log"); axs[1].set_yscale("log")
    axs[1].set_ylim(1e-20, 1)
    label(axs[1], "$q$", "$|V_1q-V(q)|/V_1$", "the germ: slope $1+\\vartheta$")
    axs[1].legend(fontsize=7, ncol=2)
    t = np.logspace(-6, -1, 10)
    axs[2].plot(t, 0.5 * t, ":", color=INK, lw=1, label="$\\propto t^{1}$ ($\\beta=1$)")
    axs[2].plot(t, 1.6 * t ** 2, "-.", color=INK, lw=1, label="$\\propto t^{2}$ ($\\beta=2$)")
    axs[2].set_xscale("log"); axs[2].set_yscale("log")
    label(axs[2], "$t$", "$q^*$", "order parameter of the continuous classes")
    axs[2].legend(fontsize=7)
    fig.tight_layout()
    return fig
