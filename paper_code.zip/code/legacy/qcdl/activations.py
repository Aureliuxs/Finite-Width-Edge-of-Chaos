"""
activations.py
==============

Registry of activation functions phi(x) together with everything the
mean-field (MF) theory needs to know about them.

For every activation we store

* ``phi``, ``dphi``           : NumPy implementations of phi and phi'
* ``torch_phi``               : the matching torch function (full-network engine / training)
* ``kinks``                   : x-locations where phi is not smooth (quadrature breakpoints)
* ``slopes``                  : (a_+, a_-) = (phi'(0+), phi'(0-)), used by the linear-response engine
* ``germ``                    : the "Landau germ" of the variance map, see below
* ``V_exact``                 : closed form of V(q) = E_z[phi(sqrt(q) z)^2] when one exists

The Landau germ
---------------
The whole MF theory of signal propagation is governed by the single function

        V(q) = E_z[ phi(sqrt(q) z)^2 ],   z ~ N(0, 1).

Its small-q expansion ("germ")

        V(q) = V0 + V1 q - c q^(1 + theta) + ...

fixes the universality class (derivations/00_framework_and_notation.md):

* V0 = phi(0)^2            : an *intrinsic field*; V0 > 0 destroys the critical point
* V1                       : sets the critical point sigma_{w,c}^2 = 1 / V1
* theta, c                 : theta sets the exponents (beta = 1/theta, delta = 1 + theta, gamma = 1);
                             c > 0 -> continuous (supercritical) transition,
                             c < 0 -> discontinuous (subcritical) transition,
                             c = 0 at all orders -> marginal (ReLU) or essential singularity (hard-tanh).
* r_inf = lim_{q->inf} V(q)/q : 0 for bounded phi, > 0 for unbounded phi (possible run-away).

All the germ coefficients below are derived explicitly in derivations/<activation>.md and are
re-checked numerically by ``qcdl.meanfield.detect_germ`` and by the unit tests.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, Optional, Tuple

import numpy as np
from scipy.special import erf, expit

SQRT2PI = np.sqrt(2.0 * np.pi)
SQRT_2_OVER_PI = np.sqrt(2.0 / np.pi)

# SELU constants (Klambauer et al. 2017)
SELU_LAMBDA = 1.0507009873554804934193349852946
SELU_ALPHA = 1.6732632423543772848170429916717


@dataclass
class Germ:
    """Small-q expansion V(q) = V0 + V1 q - c q^(1+theta) + ... (see module docstring)."""
    V0: float
    V1: float
    theta: float          # np.inf for 'no power-law correction' (ReLU: none at all, hard-tanh: essential)
    c: float              # sign encodes super-/sub-critical
    r_inf: float          # lim V(q)/q, q -> infinity
    klass: str            # human-readable universality-class label

    @property
    def sigma_w2_c(self) -> float:
        """MF critical weight variance sigma_{w,c}^2 = 1/V1 (only meaningful if V0 = 0)."""
        return 1.0 / self.V1

    @property
    def has_critical_point(self) -> bool:
        return self.V0 == 0.0

    def predicted_exponents(self) -> Dict[str, float]:
        """
        MF exponents predicted from the germ, in Christensen & Moloney notation
        (order parameter q*, control t = sigma_w^2 V1 - 1, field h = sigma_b^2):

            q*          ∝ t^beta              (h = 0, t -> 0+)
            q*          ∝ h^(1/delta)         (t = 0, h -> 0+)
            chi_h       ∝ |t|^(-gamma)        (h = 0, both sides), amplitude ratio chi_-/chi_+ = theta
            xi_depth    ∝ |t|^(-nu_par)       (depth correlation length)
            q_l         ∝ l^(-beta/nu_par)    (critical decay at t = h = 0)
            Delta       = beta * delta        (gap exponent, Widom scaling)
            chi_sigma_w ∝ t^(-(1 - beta/2))   (paper's sigma_w-susceptibility d sqrt(q*)/d sigma_w^2)
            t_Widom     ∝ h^(1/Delta)         (Widom-like line)
            chi_max     ∝ h^(-(1 - beta/2)/Delta)  (height of the ridge along the Widom-like line)
            h_EOC       ∝ t^(Delta + 1)       (edge of chaos; one power flatter than the Widom line)
        """
        th = self.theta
        if not self.has_critical_point:
            return {"note": "intrinsic field V0 > 0: no critical point, crossover only"}
        if not np.isfinite(th) or self.c <= 0:
            return {"note": f"no continuous transition with power-law germ ({self.klass})"}
        beta = 1.0 / th
        delta = 1.0 + th
        Delta = beta * delta
        return {
            "beta": beta,
            "gamma": 1.0,
            "gamma_prime": 1.0,
            "delta": delta,
            "one_over_delta": 1.0 / delta,
            "nu_par": 1.0,
            "beta_over_nu_par": beta,
            "Delta": Delta,
            "amplitude_ratio_chi_minus_over_plus": th,
            "chi_sigma_w_exponent": 1.0 - beta / 2.0,     # chi_{sigma_w^2} ∝ t^{-(this)}
            "widom_t_vs_h": 1.0 / Delta,
            "widom_chi_max_vs_h": -(1.0 - beta / 2.0) / Delta,
            "sqrt_q_vs_h_at_tc": 1.0 / (2.0 * delta),      # sqrt(q*) ∝ h^{1/(2 delta)}
            "chi_sigma_b_exponent": 1.0 - 1.0 / (2.0 * delta),  # d sqrt(q)/dh ∝ h^{-(this)}
            # Widom line from chi_h = dq*/dh: t_W = (1+theta)(1-theta) g q*^theta -> t_W ∝ h^{1/Delta},
            # except theta = 1 where the leading-order ridge sits exactly at t = 0 (then subleading)
            "widom_h_t_vs_h": (1.0 / Delta) if th != 1.0 else None,
            "widom_h_chi_max_vs_h": -1.0 / Delta,           # chi_h,max ∝ h^{-gamma/Delta}
            "eoc_h_vs_t": Delta + 1.0,                      # edge of chaos h ∝ t^{Delta+1} (Stein/Poincare)
        }


@dataclass
class Activation:
    name: str
    phi: Callable[[np.ndarray], np.ndarray]
    dphi: Callable[[np.ndarray], np.ndarray]
    torch_name: str                       # resolved lazily in torch_phi()
    kinks: Tuple[float, ...] = ()
    slopes: Tuple[float, float] = (1.0, 1.0)   # (phi'(0+), phi'(0-))
    germ: Optional[Germ] = None
    V_exact: Optional[Callable[[np.ndarray], np.ndarray]] = None
    params: Dict[str, float] = field(default_factory=dict)
    latex: str = r"\phi(x)"
    description: str = ""

    # ------------------------------------------------------------------
    def __call__(self, x):
        return self.phi(x)

    @property
    def is_positively_homogeneous(self) -> bool:
        """True for ReLU / leaky-ReLU / linear: phi(lambda x) = lambda phi(x), lambda > 0."""
        return self.name in ("relu", "leaky_relu", "linear")

    def torch_phi(self):
        """Return a torch callable implementing phi (imported lazily: torch is optional)."""
        import torch
        import torch.nn.functional as F
        p = self.params
        table = {
            "tanh": torch.tanh,
            "erf": torch.special.erf,
            "sigmoid": torch.sigmoid,
            "relu": F.relu,
            "leaky_relu": lambda x: F.leaky_relu(x, negative_slope=p.get("alpha", 0.01)),
            "elu": lambda x: F.elu(x, alpha=p.get("alpha", 1.0)),
            "selu": F.selu,
            "gelu": lambda x: F.gelu(x, approximate="none"),
            "silu": F.silu,
            "softplus": F.softplus,
            "hardtanh": F.hardtanh,
            "linear": lambda x: x,
        }
        return table[self.name]

    def torch_module(self):
        """nn.Module version (used when building trainable networks)."""
        import torch.nn as nn
        p = self.params
        table = {
            "tanh": nn.Tanh, "sigmoid": nn.Sigmoid, "relu": nn.ReLU,
            "leaky_relu": lambda: nn.LeakyReLU(p.get("alpha", 0.01)),
            "elu": lambda: nn.ELU(p.get("alpha", 1.0)), "selu": nn.SELU,
            "gelu": nn.GELU, "silu": nn.SiLU, "softplus": nn.Softplus,
            "hardtanh": nn.Hardtanh, "linear": nn.Identity,
        }
        if self.name == "erf":
            import torch

            class Erf(nn.Module):
                def forward(self, x):
                    return torch.special.erf(x)
            return Erf()
        return table[self.name]()


# ----------------------------------------------------------------------
# Individual activation constructors
# ----------------------------------------------------------------------
def _tanh() -> Activation:
    # phi = x - x^3/3 + ...  ->  V = q - 2 q^2 + 17/3 q^3 - ...   (derivations/01_tanh.md)
    return Activation(
        "tanh", np.tanh, lambda x: 1.0 / np.cosh(x) ** 2, "tanh",
        slopes=(1.0, 1.0),
        germ=Germ(V0=0.0, V1=1.0, theta=1.0, c=2.0, r_inf=0.0,
                  klass="odd-saturating: MF directed percolation (theta = 1)"),
        latex=r"\tanh x",
        description="Hyperbolic tangent (the paper's default).")


def _erf() -> Activation:
    a = 2.0 / np.sqrt(np.pi)
    # phi = a (x - x^3/3 + ...) -> V = a^2 q - 2 a^2 q^2 ; closed form (2/pi) arcsin(2q/(1+2q))
    return Activation(
        "erf", erf, lambda x: a * np.exp(-x ** 2), "erf",
        slopes=(a, a),
        germ=Germ(V0=0.0, V1=a ** 2, theta=1.0, c=2.0 * a ** 2, r_inf=0.0,
                  klass="odd-saturating: MF directed percolation (theta = 1)"),
        V_exact=lambda q: (2.0 / np.pi) * np.arcsin(2.0 * q / (1.0 + 2.0 * q)),
        latex=r"\mathrm{erf}\,x",
        description="Error function: exactly solvable member of the tanh class.")


def _sigmoid() -> Activation:
    # sigmoid(x) = 1/2 + tanh(x/2)/2  ->  V(q) = 1/4 + V_tanh(q/4)/4 = 1/4 + q/16 - q^2/32 + ...
    return Activation(
        "sigmoid", expit, lambda x: expit(x) * (1.0 - expit(x)), "sigmoid",
        slopes=(0.25, 0.25),
        germ=Germ(V0=0.25, V1=1.0 / 16.0, theta=1.0, c=1.0 / 32.0, r_inf=0.0,
                  klass="intrinsic field (phi(0) != 0): no critical point"),
        latex=r"\sigma(x) = 1/(1+e^{-x})",
        description="Logistic sigmoid; maps exactly onto a tanh network in a strong field.")


def _relu() -> Activation:
    return Activation(
        "relu", lambda x: np.maximum(x, 0.0), lambda x: (x > 0).astype(float), "relu",
        kinks=(0.0,), slopes=(1.0, 0.0),
        germ=Germ(V0=0.0, V1=0.5, theta=np.inf, c=0.0, r_inf=0.5,
                  klass="positively homogeneous: marginal/Gaussian (linear map)"),
        V_exact=lambda q: 0.5 * np.asarray(q, float),
        latex=r"\max(0, x)",
        description="Rectified linear unit.")


def _leaky_relu(alpha: float = 0.01) -> Activation:
    v1 = 0.5 * (1.0 + alpha ** 2)
    return Activation(
        "leaky_relu", lambda x: np.where(x > 0, x, alpha * x),
        lambda x: np.where(x > 0, 1.0, alpha), "leaky_relu",
        kinks=(0.0,), slopes=(1.0, alpha),
        germ=Germ(V0=0.0, V1=v1, theta=np.inf, c=0.0, r_inf=v1,
                  klass="positively homogeneous: marginal/Gaussian (linear map)"),
        V_exact=lambda q: v1 * np.asarray(q, float),
        params={"alpha": alpha}, latex=r"\max(\alpha x, x)",
        description=f"Leaky ReLU with negative slope alpha = {alpha}.")


def _elu(alpha: float = 1.0) -> Activation:
    # x<0: alpha (e^x - 1) = alpha (x + x^2/2 + ...) -> phi^2 = alpha^2 (x^2 + x^3 + ...)
    # E[x^3; x<0] = -sqrt(2/pi) q^{3/2} -> V = (1+alpha^2)/2 q - alpha^2 sqrt(2/pi) q^{3/2} + ...
    def phi(x):
        return np.where(x > 0, x, alpha * np.expm1(np.minimum(x, 0.0)))

    def dphi(x):
        return np.where(x > 0, 1.0, alpha * np.exp(np.minimum(x, 0.0)))
    return Activation(
        "elu", phi, dphi, "elu", kinks=(0.0,), slopes=(1.0, alpha),
        germ=Germ(V0=0.0, V1=0.5 * (1.0 + alpha ** 2), theta=0.5,
                  c=alpha ** 2 * SQRT_2_OVER_PI, r_inf=0.5,
                  klass="kinked-saturating: theta = 1/2 class"),
        params={"alpha": alpha}, latex=r"x\,\Theta(x) + \alpha(e^{x}-1)\Theta(-x)",
        description=f"Exponential linear unit, alpha = {alpha}.")


def _selu() -> Activation:
    lam, al = SELU_LAMBDA, SELU_ALPHA

    def phi(x):
        return lam * np.where(x > 0, x, al * np.expm1(np.minimum(x, 0.0)))

    def dphi(x):
        return lam * np.where(x > 0, 1.0, al * np.exp(np.minimum(x, 0.0)))
    return Activation(
        "selu", phi, dphi, "selu", kinks=(0.0,), slopes=(lam, lam * al),
        germ=Germ(V0=0.0, V1=lam ** 2 * 0.5 * (1.0 + al ** 2), theta=0.5,
                  c=lam ** 2 * al ** 2 * SQRT_2_OVER_PI, r_inf=0.5 * lam ** 2,
                  klass="kinked-saturating: theta = 1/2 class"),
        latex=r"\lambda[x\Theta(x) + \alpha(e^{x}-1)\Theta(-x)]",
        description="Scaled ELU (self-normalising networks).")


def _gelu() -> Activation:
    from scipy.special import ndtr

    def phi(x):
        return x * ndtr(x)

    def dphi(x):
        return ndtr(x) + x * np.exp(-0.5 * x ** 2) / SQRT2PI
    # phi = x/2 + x^2/sqrt(2 pi) + O(x^4) -> V = q/4 + 3 q^2/(2 pi) + ...  (c < 0: subcritical)
    return Activation(
        "gelu", phi, dphi, "gelu", slopes=(0.5, 0.5),
        germ=Germ(V0=0.0, V1=0.25, theta=1.0, c=-3.0 / (2.0 * np.pi), r_inf=0.5,
                  klass="smooth non-odd: subcritical (discontinuous) transition"),
        latex=r"x\,\Phi(x)",
        description="Gaussian error linear unit (exact, erf form).")


def _silu() -> Activation:
    def phi(x):
        return x * expit(x)

    def dphi(x):
        s = expit(x)
        return s + x * s * (1.0 - s)
    # phi = x/2 + x^2/4 - x^4/48 -> V = q/4 + 3 q^2/16 + ...  (c < 0: subcritical)
    return Activation(
        "silu", phi, dphi, "silu", slopes=(0.5, 0.5),
        germ=Germ(V0=0.0, V1=0.25, theta=1.0, c=-3.0 / 16.0, r_inf=0.5,
                  klass="smooth non-odd: subcritical (discontinuous) transition"),
        latex=r"x\,\sigma(x)",
        description="Sigmoid-weighted linear unit (Swish with beta = 1).")


def _softplus() -> Activation:
    ln2 = np.log(2.0)
    # phi = ln2 + x/2 + x^2/8 - x^4/192 -> V0 = (ln 2)^2, V1 = 1/4 + ln2/4, c = -(3/64 - ln2/32)
    return Activation(
        "softplus", lambda x: np.logaddexp(0.0, x), expit, "softplus",
        slopes=(0.5, 0.5),
        germ=Germ(V0=ln2 ** 2, V1=0.25 + 0.25 * ln2, theta=1.0, c=-(3.0 / 64.0 - ln2 / 32.0), r_inf=0.5,
                  klass="intrinsic field (phi(0) != 0): no critical point"),
        latex=r"\ln(1+e^{x})",
        description="Softplus (smooth ReLU).")


def _hardtanh() -> Activation:
    def V_exact(q):
        # V(q) = E[clip(sqrt(q) z, -1, 1)^2] = q (1 - 2 Qc) - 2 sqrt(q) u phi_N(u)... evaluated exactly:
        # with u = 1/sqrt(q):  V = q [ (2Phi(u)-1) - 2 u phi_N(u) ] + 2 (1 - Phi(u))
        from scipy.special import ndtr
        q = np.asarray(q, float)
        u = 1.0 / np.sqrt(np.maximum(q, 1e-300))
        pdf = np.exp(-0.5 * u ** 2) / SQRT2PI
        return q * ((2.0 * ndtr(u) - 1.0) - 2.0 * u * pdf) + 2.0 * (1.0 - ndtr(u))
    return Activation(
        "hardtanh", lambda x: np.clip(x, -1.0, 1.0),
        lambda x: ((x > -1.0) & (x < 1.0)).astype(float), "hardtanh",
        kinks=(-1.0, 1.0), slopes=(1.0, 1.0),
        germ=Germ(V0=0.0, V1=1.0, theta=np.inf, c=0.0, r_inf=0.0,
                  klass="essential singularity: q* ~ 1/ln(1/t) (infinite order)"),
        V_exact=V_exact, latex=r"\mathrm{clip}(x,-1,1)",
        description="Hard tanh (piecewise-linear saturating).")


def _linear() -> Activation:
    return Activation(
        "linear", lambda x: np.asarray(x, float), lambda x: np.ones_like(np.asarray(x, float)),
        "linear", slopes=(1.0, 1.0),
        germ=Germ(V0=0.0, V1=1.0, theta=np.inf, c=0.0, r_inf=1.0,
                  klass="positively homogeneous: marginal/Gaussian (linear map)"),
        V_exact=lambda q: np.asarray(q, float), latex="x",
        description="Identity (deep linear network), for reference.")


_REGISTRY = {
    "tanh": _tanh, "erf": _erf, "sigmoid": _sigmoid, "relu": _relu,
    "leaky_relu": _leaky_relu, "elu": _elu, "selu": _selu, "gelu": _gelu,
    "silu": _silu, "softplus": _softplus, "hardtanh": _hardtanh, "linear": _linear,
}

#: activations studied in the survey (order used in tables / figures)
STANDARD_ACTIVATIONS = ["tanh", "erf", "sigmoid", "relu", "leaky_relu", "elu",
                        "selu", "gelu", "silu", "softplus", "hardtanh"]


def get_activation(name: str | Activation, **params) -> Activation:
    """Return an :class:`Activation` by name, e.g. ``get_activation('leaky_relu', alpha=0.2)``."""
    if isinstance(name, Activation):
        return name
    key = name.lower().replace("-", "_")
    aliases = {"swish": "silu", "lrelu": "leaky_relu", "hard_tanh": "hardtanh", "identity": "linear"}
    key = aliases.get(key, key)
    if key not in _REGISTRY:
        raise KeyError(f"unknown activation '{name}'. Available: {sorted(_REGISTRY)}")
    return _REGISTRY[key](**params)


def list_activations():
    return list(_REGISTRY)
