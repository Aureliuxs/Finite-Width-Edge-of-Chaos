"""
plotting.py
===========

House style and reusable plotting helpers.

Style rules (as requested)
--------------------------
* x/y ticks, **no grid lines**, a legend and a title on every panel;
* axes labelled by the *variable only* (e.g. ``$q^*$``, ``$t$``);
* the y-label is written **horizontally, above the y-axis** (not rotated, not at the side);
* data are plotted as simple **circular dots**; fits as thin dashed lines;
* colours: validated pastel reds / oranges / blues (colour-blind safe, see ``PALETTE``).

Every helper takes an optional ``ax`` and returns what it drew, so panels can be composed freely.
"""
from __future__ import annotations

from typing import Callable, Dict, Optional, Sequence

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import LinearSegmentedColormap

from .fitting import loglog_fit

# Categorical order (validated: CVD dE >= 12, normal-vision dE >= 16 for adjacent pairs).
PALETTE = ["#4F86C6", "#E0645C", "#E8A33C", "#2D5F95", "#B8433D", "#6FA3DC", "#C77A2A"]
BLUE, RED, ORANGE, DEEP_BLUE, DEEP_RED, LIGHT_BLUE, DEEP_ORANGE = PALETTE
FIT_COLOR = "#3A3A3A"
INK = "#2B2B2B"

# Sequential maps (single hue family, monotone lightness) for heat maps
CMAP_WARM = LinearSegmentedColormap.from_list("pastel_warm", ["#FBF7F2", "#F8D9B0", "#F2A46B", "#E0645C", "#8E2F2B"])
CMAP_COOL = LinearSegmentedColormap.from_list("pastel_cool", ["#F6F9FC", "#CFE0F3", "#8FB8E3", "#4F86C6", "#1F4470"])


def apply_style(font_size: float = 11.0):
    """Set the matplotlib rcParams of the house style (idempotent)."""
    mpl.rcParams.update({
        "figure.dpi": 110, "savefig.dpi": 200, "savefig.bbox": "tight",
        "font.size": font_size, "axes.titlesize": font_size + 1, "axes.labelsize": font_size + 1,
        "axes.grid": False, "axes.spines.top": False, "axes.spines.right": False,
        "axes.edgecolor": INK, "axes.labelcolor": INK, "text.color": INK,
        "xtick.color": INK, "ytick.color": INK, "xtick.direction": "out", "ytick.direction": "out",
        "legend.frameon": False, "legend.fontsize": font_size - 1,
        "axes.prop_cycle": mpl.cycler(color=PALETTE),
        "lines.markersize": 5, "mathtext.fontset": "cm",
    })


apply_style()


def label(ax, xlabel: str = "", ylabel: str = "", title: Optional[str] = None):
    """Variable-only labels; y-label horizontal and placed above the y-axis."""
    if xlabel:
        ax.set_xlabel(xlabel)
    if ylabel:
        ax.set_ylabel(ylabel, rotation=0, ha="left", va="bottom")
        ax.yaxis.set_label_coords(-0.02, 1.02)
    if title:
        ax.set_title(title, pad=24 if ylabel else 6)
    return ax


def dots(ax, x, y, color=BLUE, label_=None, size: float = 22, alpha: float = 0.95, **kw):
    """Circular dots with a thin darker edge (keeps pale colours visible on white)."""
    return ax.scatter(x, y, s=size, color=color, edgecolors=_darken(color), linewidths=0.5,
                      alpha=alpha, label=label_, zorder=3, **kw)


def _darken(c, f: float = 0.75):
    r, g, b = mpl.colors.to_rgb(c)
    return (r * f, g * f, b * f)


def fit_line(ax, fit: Dict, extend: float = 1.8, color=FIT_COLOR, label_=None, sign_label: str = "",
             lw: float = 1.3):
    """Draw the fitted power law through (and slightly beyond) the fitted points."""
    if not np.isfinite(fit.get("slope", np.nan)) or fit["x"].size < 2:
        return None
    x0, x1 = fit["x"].min() / extend, fit["x"].max() * extend
    xx = np.logspace(np.log10(x0), np.log10(x1), 50)
    yy = np.exp(fit["intercept"]) * xx ** fit["slope"]
    if label_ is None:
        err = fit.get("stderr", np.nan)
        e = f" ± {err:.2g}" if np.isfinite(err) else ""
        label_ = f"slope {sign_label}{fit['slope']:.4g}{e}"
    return ax.plot(xx, yy, "--", color=color, lw=lw, label=label_, zorder=4)[0]


def loglog_panel(x, y, xlabel, ylabel, title, n_last=None, window=None, ax=None, color=BLUE,
                 data_label="data", predicted: Optional[float] = None, fit_color=FIT_COLOR,
                 show_fit_points: bool = True):
    """
    Generic 'find the exponent' panel: dots on log-log axes and a straight line through the
    last ``n_last`` points (or the points inside ``window``).  Returns (ax, fit).
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(4.2, 3.4))
    fit = loglog_fit(x, y, n_last=n_last, window=window)
    dots(ax, x, y, color=color, label_=data_label)
    if show_fit_points and fit["x"].size:
        ax.scatter(fit["x"], fit["y"], s=40, facecolors="none", edgecolors=fit_color, linewidths=0.8,
                   zorder=5, label="fitted points")
    lab = f"fit: {fit['slope']:.4f}" if np.isfinite(fit["slope"]) else "fit"
    if predicted is not None:
        lab += f"  (theory {predicted:.4g})"
    fit_line(ax, fit, color=fit_color, label_=lab)
    ax.set_xscale("log")
    ax.set_yscale("log")
    label(ax, xlabel, ylabel, title)
    ax.legend(loc="best")
    return ax, fit


def pdf_panel(ax, centres, pdf, color, label_):
    dots(ax, centres, pdf, color=color, label_=label_, size=14)
    ax.set_xscale("log")
    ax.set_yscale("log")


def powerlaw_guide(ax, x_lo, x_hi, tau, y_at_lo, label_=None, color=FIT_COLOR):
    """Dashed guide x^{-tau} anchored at (x_lo, y_at_lo)."""
    xx = np.logspace(np.log10(x_lo), np.log10(x_hi), 40)
    return ax.plot(xx, y_at_lo * (xx / x_lo) ** (-tau), "--", color=color, lw=1.3, label=label_)[0]


def heatmap(ax, x, y, Z, cmap=CMAP_WARM, logy: bool = True, vmin=None, vmax=None, cbar_label: str = "",
            norm=None):
    """Heat map on (x, y) grid centres; y typically sigma_b^2 on log axis."""
    m = ax.pcolormesh(x, y, Z, cmap=cmap, shading="nearest", vmin=vmin, vmax=vmax, norm=norm,
                      rasterized=True)
    if logy:
        ax.set_yscale("log")
    cb = plt.colorbar(m, ax=ax, pad=0.02)
    cb.ax.set_title(cbar_label, fontsize=10, pad=6)
    cb.outline.set_visible(False)
    return m, cb


def savefig(fig, path_stem: Optional[str]):
    """Save as PNG and PDF (vector) if a path stem is given."""
    if path_stem:
        fig.savefig(f"{path_stem}.png")
        fig.savefig(f"{path_stem}.pdf")


# ----------------------------------------------------------------------
# Interactive slider (notebook: ipywidgets; script: matplotlib.widgets)
# ----------------------------------------------------------------------
def interactive(plot_fn: Callable, sliders: Dict[str, Sequence[float]], backend: str = "auto"):
    """
    Make any ``plot_fn(**params) -> Figure`` interactive.

    sliders : {name: (min, max, step, initial)}
    backend : 'ipywidgets' (Jupyter), 'matplotlib' (plain Python window) or 'auto'.
    """
    if backend in ("auto", "ipywidgets"):
        try:
            import ipywidgets as W
            from IPython.display import display

            ctrls = {k: W.FloatSlider(min=v[0], max=v[1], step=v[2], value=v[3], description=k,
                                      continuous_update=False, readout_format=".3g")
                     for k, v in sliders.items()}

            def _f(**kw):
                fig = plot_fn(**kw)
                plt.show()
                return fig
            out = W.interactive_output(_f, ctrls)
            display(W.VBox([W.HBox(list(ctrls.values())), out]))
            return ctrls
        except ImportError:
            if backend == "ipywidgets":
                raise
    from matplotlib.widgets import Slider
    init = {k: v[3] for k, v in sliders.items()}
    fig = plot_fn(**init)
    fig.subplots_adjust(bottom=0.12 + 0.05 * len(sliders))
    widgets = {}
    for i, (k, v) in enumerate(sliders.items()):
        axs = fig.add_axes([0.2, 0.02 + 0.05 * i, 0.6, 0.03])
        widgets[k] = Slider(axs, k, v[0], v[1], valinit=v[3], valstep=v[2])

    def update(_):
        params = {k: w.val for k, w in widgets.items()}
        for a in list(fig.axes):
            if a not in [w.ax for w in widgets.values()]:
                a.remove()
        plot_fn(fig=fig, **params)
        fig.canvas.draw_idle()
    for w in widgets.values():
        w.on_changed(update)
    return widgets
