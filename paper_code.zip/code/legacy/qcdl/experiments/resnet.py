"""
resnet.py -- avalanches in (untrained) ResNets (paper Fig. 4).  Requires torch + torchvision.

Every leaf operation (conv, batch-norm, ReLU, max-pool, ...) is a 'layer' l with N^l components.
Signal strength  sqrt(q~_l) = ||x^l|| / sqrt(N^l).  Layer-dependent thresholds
theta_l = mu_l + n sigma_l are calibrated on n_calibration random inputs; an avalanche is the run of
consecutive layers (from the first) with sqrt(q~_l) > theta_l:

        T = number of such layers,       s~ = sum_{l=1}^{T} (sqrt(q~_l) - theta_l).
"""
from __future__ import annotations

import time

import matplotlib.pyplot as plt
import numpy as np

from ..finite_n import BROWNIAN_EXCURSION
from ..fitting import fit_powerlaw, find_xmin, log_bin, size_duration_fit
from ..plotting import BLUE, DEEP_BLUE, FIT_COLOR, ORANGE, PALETTE, RED, dots, fit_line, label
from ..simulate import resolve_device
from .common import Run, fmt, merge

RESNET_DEFAULTS = dict(models=["resnet18"], resolution=64, n_calibration=2000, n_perturbations=20000,
                       thresholds_n=[0, 1, 2, 3], batch=250, bn_mode="train", seed=0, device="auto")


def _signal_strengths(model, x):
    """Forward pass recording sqrt(||x_l||^2 / N_l) after every leaf module, in call order."""
    import torch
    rec = []

    def hook(_m, _i, out):
        o = out.flatten(1)
        rec.append(torch.sqrt((o ** 2).mean(1)).detach())
    hs = [m.register_forward_hook(hook) for m in model.modules() if len(list(m.children())) == 0]
    with torch.no_grad():
        model(x)
    for h in hs:
        h.remove()
    return torch.stack(rec, 1).double().cpu().numpy()     # (batch, layers)


def _strengths(model, n, cfg, device, gen_seed):
    import torch
    g = torch.Generator().manual_seed(gen_seed)
    out = []
    for b in range(0, n, cfg["batch"]):
        x = torch.randn(min(cfg["batch"], n - b), 3, cfg["resolution"], cfg["resolution"], generator=g).to(device)
        out.append(_signal_strengths(model, x))
    return np.concatenate(out)


def exp_resnet(run: Run, cfg=None):
    import torch
    import torchvision
    cfg = merge(RESNET_DEFAULTS, cfg)
    device, _ = resolve_device(cfg["device"], "float32")
    res, t0 = {}, time.time()
    fig, axs = plt.subplots(1, 4, figsize=(18, 4.2))
    k = 0
    for name in cfg["models"]:
        torch.manual_seed(cfg["seed"])
        model = getattr(torchvision.models, name)(weights=None).to(device)
        model.train() if cfg["bn_mode"] == "train" else model.eval()
        cal = _strengths(model, cfg["n_calibration"], cfg, device, cfg["seed"] + 1)
        mu, sd = cal.mean(0), cal.std(0)
        q = _strengths(model, cfg["n_perturbations"], cfg, device, cfg["seed"] + 2)
        for nth in cfg["thresholds_n"]:
            th = mu + nth * sd
            above = q > th[None, :]
            T = np.argmin(np.concatenate([above, np.zeros((q.shape[0], 1), bool)], 1), axis=1)
            S = np.array([np.sum(q[i, :T[i]] - th[:T[i]]) for i in range(q.shape[0])])
            v = T >= 1
            S, T = S[v], T[v]
            if S.size < 200:
                continue
            ft = fit_powerlaw(T, 2, q.shape[1] - 1, discrete=True)
            fs = find_xmin(S, xmax=np.quantile(S, 0.999))
            sd_ = size_duration_fit(T, S, 2)
            key = f"{name}_n{nth}"
            res[key] = dict(tau_s=fs["tau"], tau_s_err=fs["err"], tau_t=ft["tau"], tau_t_err=ft["err"],
                            D_over_z=sd_["slope"], D_over_z_err=sd_["stderr"], n=int(S.size), layers=int(q.shape[1]))
            c = PALETTE[k % len(PALETTE)]
            k += 1
            if nth == 2:
                x, p = log_bin(S, a=1.4); dots(axs[0], x, p, color=c, size=12, label_=key)
                x, p = log_bin(T, a=1.3, discrete=True); dots(axs[1], x, p, color=c, size=12, label_=key)
                dots(axs[2], sd_["T"], sd_["meanS"], color=c, size=12, label_=key)
            axs[3].errorbar(ft["tau"] - 1, fs["tau"] - 1, xerr=ft["err"], yerr=fs["err"], fmt="o", color=c,
                            mec=FIT_COLOR, mew=0.5, label=key)
        print(f"  {name}: {q.shape[1]} layers ({time.time() - t0:.0f}s)")
    for ax in axs[:3]:
        ax.set_xscale("log"); ax.set_yscale("log")
        if ax.get_legend_handles_labels()[0]:
            ax.legend(fontsize=7)
    label(axs[0], r"$\tilde s$", r"$P(\tilde s)$", "(a) sizes (n = 2)")
    label(axs[1], r"$T$", r"$P(T)$", "(b) durations (n = 2)")
    label(axs[2], r"$T$", r"$\langle\tilde s\rangle_T$", "(c) size vs duration")
    xx = np.linspace(0, 2, 10)
    axs[3].plot(xx, xx / 2, ":", color=FIT_COLOR, label=r"$D/z=2$ (MF DP)")
    axs[3].plot(xx, xx / 1.5, "--", color=RED, lw=0.8, label=r"$D/z=3/2$ (Brownian)")
    axs[3].scatter([1.0], [0.5], color="k", zorder=6, label="MF directed percolation")
    label(axs[3], r"$\tau_t-1$", r"$\tau_s-1$", "(d) exponents")
    axs[3].legend(fontsize=6.5)
    fig.suptitle(f"Avalanches in untrained ResNets (BN mode: {cfg['bn_mode']}, {cfg['resolution']}px inputs)")
    fig.tight_layout()
    run.fig(fig, "resnet_avalanches")
    rows = ["", "### ResNet avalanches", "", "| model / n | layers | τ_s | τ_t | D/z |", "|---|---|---|---|---|"]
    for key, r in res.items():
        rows.append(f"| {key} | {r['layers']} | {fmt(r['tau_s'], r['tau_s_err'], 3)} | {fmt(r['tau_t'], r['tau_t_err'], 3)} | "
                    f"{fmt(r['D_over_z'], r['D_over_z_err'], 3)} |")
    run.note("\n".join(rows))
    run.record("resnet", res)
    return res
