"""
common.py -- bookkeeping shared by all experiments: output folder, figure saving, results json.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field
from typing import Any, Dict

import numpy as np

from ..plotting import savefig


def _jsonable(x):
    if isinstance(x, dict):
        return {str(k): _jsonable(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_jsonable(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist() if x.size <= 2000 else f"<array shape={x.shape}>"
    if isinstance(x, (np.floating,)):
        return float(x)
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, float) and not np.isfinite(x):
        return str(x)
    if callable(x):
        return "<function>"
    return x


@dataclass
class Run:
    """An output folder collecting figures, a results.json and a human-readable summary.md."""
    root: str = "results"
    name: str = ""
    results: Dict[str, Any] = field(default_factory=dict)
    summary: list = field(default_factory=list)
    save: bool = True

    def __post_init__(self):
        if not self.name:
            self.name = time.strftime("run_%Y%m%d_%H%M%S")
        self.dir = os.path.join(self.root, self.name)
        if self.save:
            os.makedirs(os.path.join(self.dir, "figures"), exist_ok=True)
            # re-using a run name appends to it (e.g. re-running one experiment with --only)
            rj, sm = os.path.join(self.dir, "results.json"), os.path.join(self.dir, "summary.md")
            if os.path.exists(rj):
                with open(rj) as f:
                    self.results = json.load(f)
            if os.path.exists(sm):
                with open(sm) as f:
                    self.summary = f.read().rstrip("\n").split("\n")

    def fig(self, fig, stem: str):
        if self.save:
            savefig(fig, os.path.join(self.dir, "figures", stem))

    def record(self, experiment: str, data: Dict[str, Any]):
        self.results[experiment] = data
        if self.save:
            with open(os.path.join(self.dir, "results.json"), "w") as f:
                json.dump(_jsonable(self.results), f, indent=1)

    def note(self, text: str):
        """Append a line (markdown) to summary.md and print it."""
        print(text)
        self.summary.append(text)
        if self.save:
            with open(os.path.join(self.dir, "summary.md"), "w") as f:
                f.write("\n".join(self.summary) + "\n")


def merge(defaults: Dict, override: Dict | None) -> Dict:
    """Recursive dict merge (config file values override experiment defaults)."""
    out = dict(defaults)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = merge(out[k], v)
        else:
            out[k] = v
    return out


def fmt(x, err=None, nd=4):
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return "–"
    if err is None or not np.isfinite(err):
        return f"{x:.{nd}f}"
    return f"{x:.{nd}f} ± {err:.1g}"
