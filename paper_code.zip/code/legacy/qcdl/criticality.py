"""
criticality.py
==============

Numerical measurement of the mean-field critical exponents of any activation, and
comparison with the analytic predictions of the Landau germ (activations.Germ).

Notation (Christensen & Moloney):  t = sigma_w^2 / sigma_{w,c}^2 - 1 (reduced control parameter),
h = sigma_b^2 (field), q* = order parameter.

Every exponent is obtained as the slope of a straight line through the points of a log-log
plot closest to the critical point (fitting window configurable), exactly as one would do
with experimental data -- the analytic prediction is *not* used in the measurement.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

import numpy as np

from .fitting import loglog_fit
from .meanfield import MeanField


@dataclass
class MFWindows:
    """Fitting windows (in |t| or h) used to extract each exponent."""
    t_range: Tuple[float, float] = (1e-7, 1e-1)       # sweep range of |t|
    t_fit: Tuple[float, float] = (1e-7, 1e-4)         # fit window in |t|
    h_range: Tuple[float, float] = (1e-16, 1e-2)
    h_fit: Tuple[float, float] = (1e-16, 1e-10)
    widom_h: Tuple[float, float] = (1e-10, 1e-3)
    widom_h_fit: Tuple[float, float] = (1e-10, 1e-6)
    decay_L: int = 200000                              # layers for the critical decay q_l
    decay_fit: Tuple[float, float] = (1e3, 2e5)
    eoc_t_fit: Tuple[float, float] = (1e-4, 1e-2)
    n_points: int = 40
    n_last: Optional[int] = None      # if set: fit the n points closest to the critical point instead of windows


def measure_mf_exponents(mf: MeanField, w: MFWindows = MFWindows()) -> Dict:
    """
    Returns a dict  {'fits': {name: fit-dict}, 'data': {...arrays for plotting...},
                     'predicted': {...}, 'table': [(name, measured, err, predicted), ...]}.
    """
    g = mf.act.germ
    V1 = g.V1
    swc = 1.0 / V1
    t = np.logspace(np.log10(w.t_range[0]), np.log10(w.t_range[1]), w.n_points)
    h = np.logspace(np.log10(w.h_range[0]), np.log10(w.h_range[1]), w.n_points)
    fits, data = {}, {}

    # ---- above t_c, h = 0 : order parameter, chi_h, chi_t, xi
    Rp = mf.response(swc * (1 + t), 0.0, q_init=1.0)
    # ---- below t_c, h = 0 : chi_h, xi (q* = 0)
    Rm = mf.response(swc * (1 - t), 0.0, q_init=1.0)
    # ---- at t_c, field sweep
    Rh = mf.response(swc * np.ones_like(h), h, q_init=1.0)
    data.update(t=t, h=h, above=Rp, below=Rm, crit=Rh)

    def fit(name, x, y, window, sign=1.0, asymptote_large=False):
        # n_last: the n points closest to the critical point -- smallest |t| or h (arrays are ascending),
        # or the largest depths for the critical decay (asymptote_large=True)
        if w.n_last:
            xx, yy = (np.asarray(x), np.asarray(y)) if asymptote_large else (np.asarray(x)[::-1], np.asarray(y)[::-1])
            fr = loglog_fit(xx, yy, n_last=w.n_last)
        else:
            fr = loglog_fit(x, y, window=window)
        fr["exponent"] = sign * fr["slope"]
        fits[name] = fr

    fit("beta", t, Rp["q"], w.t_fit)                         # q* ∝ t^beta
    fit("gamma", t, Rp["chi_h"], w.t_fit, -1)                # chi_h ∝ t^-gamma
    fit("gamma_prime", t, Rm["chi_h"], w.t_fit, -1)          # chi_h ∝ |t|^-gamma'
    fit("nu_par", t, Rp["xi"], w.t_fit, -1)                  # xi ∝ t^-nu
    fit("nu_par_prime", t, Rm["xi"], w.t_fit, -1)
    fit("one_over_delta", h, Rh["q"], w.h_fit)               # q* ∝ h^{1/delta}
    fit("chi_sigma_w_exponent", t, Rp["chi_t"], w.t_fit, -1)  # paper's eq. (5)
    fit("chi_sigma_b_exponent", h, Rh["chi_b"], w.h_fit, -1)  # d sqrt q / dh ∝ h^-x
    if np.isfinite(fits["one_over_delta"]["exponent"]) and fits["one_over_delta"]["exponent"] > 0:
        fits["delta"] = dict(exponent=1.0 / fits["one_over_delta"]["exponent"],
                             stderr=fits["one_over_delta"]["stderr"] / fits["one_over_delta"]["exponent"] ** 2)

    # amplitude ratio chi_-/chi_+ at the smallest |t|
    k = np.argmin(np.abs(t - w.t_fit[0]))
    fits["amplitude_ratio"] = dict(exponent=float(Rm["chi_h"][k] / Rp["chi_h"][k]), stderr=0.0)

    # ---- critical decay at t = h = 0:  q_l ∝ l^{-beta/nu_par}
    if g.has_critical_point:
        ql = mf.trajectory(1e-2, w.decay_L, swc, 0.0, use_grid=True)
        l = np.arange(ql.size)
        data["decay_l"], data["decay_q"] = l[1:], ql[1:]
        fit("beta_over_nu_par", l[1:], ql[1:], w.decay_fit, -1, asymptote_large=True)

    # ---- Widom-like line: maxima of chi_t at fixed h
    hw = np.logspace(np.log10(w.widom_h[0]), np.log10(w.widom_h[1]), 16)
    tg = np.concatenate([-np.logspace(-1, -9, 60), np.logspace(-9, 0.2, 700)])
    Wm, Hm = np.meshgrid(swc * (1 + tg), hw)
    Rw = mf.response(Wm, Hm)
    sw_max, chi_max = mf.widom_line(hw, swc * (1 + tg), R=Rw)
    tW = sw_max / swc - 1
    data.update(widom_h=hw, widom_t=tW, widom_chi=chi_max)
    fit("widom_t_vs_h", hw, tW, w.widom_h_fit)
    fit("widom_chi_max_vs_h", hw, chi_max, w.widom_h_fit)
    # the same with the susceptibility proper chi_h = dq*/dh (always has a ridge, gamma = 1)
    sw_max_h, chih_max = mf.widom_line(hw, swc * (1 + tg), observable="chi_h", R=Rw)
    tWh = sw_max_h / swc - 1
    data.update(widom_h_t=tWh, widom_h_chi=chih_max)
    fit("widom_h_t_vs_h", hw, tWh, w.widom_h_fit)
    fit("widom_h_chi_max_vs_h", hw, chih_max, w.widom_h_fit)

    # ---- edge of chaos (parametric in q*): h_EOC ∝ t_EOC^{x}
    s_e, h_e, q_e = mf.edge_of_chaos(np.logspace(-8, 1, 600))
    t_e = s_e / swc - 1
    data.update(eoc_sw2=s_e, eoc_h=h_e, eoc_t=t_e)
    fit("eoc_h_vs_t", t_e, h_e, w.eoc_t_fit)

    pred = g.predicted_exponents()
    pred_map = {
        "beta": pred.get("beta"), "gamma": pred.get("gamma"), "gamma_prime": pred.get("gamma_prime"),
        "delta": pred.get("delta"), "nu_par": pred.get("nu_par"), "nu_par_prime": pred.get("nu_par"),
        "beta_over_nu_par": pred.get("beta_over_nu_par"),
        "amplitude_ratio": pred.get("amplitude_ratio_chi_minus_over_plus"),
        "chi_sigma_w_exponent": pred.get("chi_sigma_w_exponent"),
        "chi_sigma_b_exponent": pred.get("chi_sigma_b_exponent"),
        "widom_t_vs_h": pred.get("widom_t_vs_h"), "widom_chi_max_vs_h": pred.get("widom_chi_max_vs_h"),
        "widom_h_t_vs_h": pred.get("widom_h_t_vs_h"),
        "widom_h_chi_max_vs_h": pred.get("widom_h_chi_max_vs_h"),
        "eoc_h_vs_t": pred.get("eoc_h_vs_t"),
    }
    table = []
    for name, p in pred_map.items():
        f = fits.get(name, {})
        table.append((name, f.get("exponent", np.nan), f.get("stderr", np.nan), p))
    return dict(fits=fits, data=data, predicted=pred, table=table, activation=mf.act.name,
                klass=g.klass)


def widom_scaling_collapse(mf: MeanField, beta: float, Delta: float,
                           t_values=(1e-5, 3e-5, 1e-4, 3e-4, 1e-3), n_h: int = 60):
    """
    Data for the Widom scaling-form collapse (Christensen & Moloney sec. 2.9):

        q*(t, h) = |t|^beta  F_±( h / |t|^Delta ).

    Returns a list of (t, x = h/|t|^Delta, y = q*/|t|^beta) for both signs of t.
    """
    swc = 1.0 / mf.act.germ.V1
    out = []
    for sgn in (+1, -1):
        for t in t_values:
            h = np.abs(t) ** Delta * np.logspace(-4, 4, n_h)
            q = mf.fixed_point(swc * (1 + sgn * t) * np.ones_like(h), h)
            out.append((sgn * t, h / t ** Delta, q / t ** beta))
    return out
