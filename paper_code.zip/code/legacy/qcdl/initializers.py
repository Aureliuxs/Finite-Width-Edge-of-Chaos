"""
initializers.py
===============

Weight / bias initialisation schemes and their mapping onto the mean-field knobs
(sigma_w^2, sigma_b^2).  Derivations: derivations/20_initializers.md.

Key result
----------
For any scheme whose weights W_ij are i.i.d. with zero mean and variance Var(W), the
pre-activation z_i = sum_j W_ij y_j + b_i is, by the central limit theorem, Gaussian at
N -> infinity with variance

        q_{l+1} = [fan_in * Var(W)] * (1/N) sum_j y_j^2 + Var(b).

Hence the *only* two numbers the MF theory sees are

        sigma_w^2 = fan_in * Var(W),         sigma_b^2 = Var(b)        (I1)

The shape of the weight distribution enters only at finite N, through its excess kurtosis
kappa_w = E[W^4]/E[W^2]^2 - 3, which adds a term of relative order kappa_w / N to the
layer-to-layer fluctuations of q_l (derivations/21_finite_width_theory.md, eq. W7).  Orthogonal
weights are *not* i.i.d.: they preserve norms exactly and remove the dominant O(1/N)
fluctuation altogether -> different finite-N physics (tested in the survey).

Every scheme below has a native parameter (a gain g, a bound a, a std s, ...).  Because
(I1) is monotone in that parameter, every scheme can be *driven by* (sigma_w^2, sigma_b^2):
``Initializer.from_sigma(name, sigma_w2, sigma_b2)`` sets the native parameters that
reproduce a target point of the MF phase diagram.

Schemes (fan_in = fan_out = N for the square hidden layers used here)
---------------------------------------------------------------------
name              native parameters                         Var(W)                      sigma_w^2
gaussian          sigma_w  (paper)                          sigma_w^2 / N               sigma_w^2
uniform           a  : W ~ U(-a/sqrt N, a/sqrt N)           a^2 / (3N)                  a^2/3
xavier_normal     g  : std = g sqrt(2/(fi+fo))              2 g^2/(fi+fo)               g^2 (square layers)
xavier_uniform    g  : bound = g sqrt(6/(fi+fo))            2 g^2/(fi+fo)               g^2
kaiming_normal    g  : std = g / sqrt(fan_in)               g^2 / N                     g^2   (He: g^2 = 2/(1+a^2))
kaiming_uniform   g  : bound = g sqrt(3/fan_in)             g^2 / N                     g^2
lecun_normal      g  : std = g / sqrt(fan_in)  (g = 1)      g^2 / N                     g^2
truncated_normal  g, c : N(0, s^2) cut at +-c s, s=g/sqrtN  s^2 r(c)                    g^2 r(c)
                  r(c) = 1 - 2 c phi(c) / (2 Phi(c) - 1)
orthogonal        g  : W = g O,  O Haar-orthogonal          g^2 / N                     g^2  (NOT i.i.d.)
sparse            g, k : k non-zeros per row, N(0, g^2/k)   g^2 / N                     g^2  (kappa_w = 3N/k - 3)
pytorch_default   (nn.Linear): kaiming_uniform(a=sqrt 5)    1/(3N)                      1/3

Bias schemes:  zeros (0),  normal(sigma_b),  uniform(a_b): U(-a_b, a_b) -> a_b^2/3,
               constant(b0): every b_i = b0 -> sigma_b^2 = b0^2 in the MF recursion
               (but no bias *sampling* noise),  pytorch_default: U(+-1/sqrt N) -> 1/(3N).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional

import numpy as np
from scipy.special import ndtr

_SQ2PI = np.sqrt(2 * np.pi)


def truncation_factor(c: float) -> float:
    """Var of N(0,1) truncated to [-c, c]:  r(c) = 1 - 2 c phi(c) / (2 Phi(c) - 1)."""
    return 1.0 - 2.0 * c * np.exp(-0.5 * c * c) / _SQ2PI / (2.0 * ndtr(c) - 1.0)


def truncated_kurtosis(c: float) -> float:
    """Excess kurtosis of the standard normal truncated at +-c."""
    Z = 2.0 * ndtr(c) - 1.0
    pdf = np.exp(-0.5 * c * c) / _SQ2PI
    m2 = 1.0 - 2 * c * pdf / Z
    m4 = 3.0 * m2 - 2 * c ** 3 * pdf / Z
    return m4 / m2 ** 2 - 3.0


WEIGHT_SCHEMES = {
    # name: (native parameter names, description)
    "gaussian": (("sigma_w",), "W ~ N(0, sigma_w^2/N)  [paper]"),
    "uniform": (("a",), "W ~ U(-a/sqrt(N), a/sqrt(N))"),
    "xavier_normal": (("gain",), "Glorot & Bengio (2010), normal"),
    "xavier_uniform": (("gain",), "Glorot & Bengio (2010), uniform"),
    "kaiming_normal": (("gain",), "He et al. (2015), normal, fan_in mode"),
    "kaiming_uniform": (("gain",), "He et al. (2015), uniform, fan_in mode"),
    "lecun_normal": (("gain",), "LeCun et al. (1998), normal (SELU default)"),
    "truncated_normal": (("gain", "cut"), "N(0, (gain^2/N)) truncated at +-cut std (TF/Keras)"),
    "orthogonal": (("gain",), "Saxe et al. (2014): gain * Haar-orthogonal matrix"),
    "sparse": (("gain", "k"), "Martens (2010): k non-zero N(0, gain^2/k) entries per row"),
    "pytorch_default": ((), "torch.nn.Linear default: kaiming_uniform(a=sqrt 5)"),
}
BIAS_SCHEMES = {
    "zeros": ((), "b = 0"),
    "normal": (("sigma_b",), "b ~ N(0, sigma_b^2)  [paper]"),
    "uniform": (("a_b",), "b ~ U(-a_b, a_b)"),
    "constant": (("b0",), "b_i = b0 for all i"),
    "pytorch_default": ((), "b ~ U(-1/sqrt(N), 1/sqrt(N))"),
}
DEFAULTS = {"sigma_w": 1.0, "a": np.sqrt(3.0), "gain": 1.0, "cut": 2.0, "k": 15,
            "sigma_b": 0.0, "a_b": 0.0, "b0": 0.0}
# library default gains that differ from 1 (PyTorch kaiming_*: nonlinearity='leaky_relu', a=0 -> gain sqrt 2)
SCHEME_DEFAULT_GAIN = {"kaiming_normal": np.sqrt(2.0), "kaiming_uniform": np.sqrt(2.0)}


@dataclass
class Initializer:
    """
    A weight scheme + a bias scheme with their native parameters.

    Example
    -------
    >>> init = Initializer("uniform", {"a": 1.8}, "uniform", {"a_b": 0.01})
    >>> init.sigma_w2(), init.sigma_b2()          # effective MF knobs
    >>> Initializer.from_sigma("orthogonal", sigma_w2=1.05, sigma_b2=1e-5)
    """
    weight: str = "gaussian"
    weight_params: Dict[str, float] = field(default_factory=dict)
    bias: str = "zeros"
    bias_params: Dict[str, float] = field(default_factory=dict)

    def __post_init__(self):
        if self.weight not in WEIGHT_SCHEMES:
            raise KeyError(f"unknown weight scheme {self.weight}; choose from {list(WEIGHT_SCHEMES)}")
        if self.bias not in BIAS_SCHEMES:
            raise KeyError(f"unknown bias scheme {self.bias}; choose from {list(BIAS_SCHEMES)}")
        for k in WEIGHT_SCHEMES[self.weight][0]:
            default = SCHEME_DEFAULT_GAIN.get(self.weight, DEFAULTS[k]) if k == "gain" else DEFAULTS[k]
            self.weight_params.setdefault(k, default)
        for k in BIAS_SCHEMES[self.bias][0]:
            self.bias_params.setdefault(k, DEFAULTS[k])

    # ------------------------------------------------------------------
    # Mapping native parameters -> (sigma_w^2, sigma_b^2, kappa_w)
    # ------------------------------------------------------------------
    def sigma_w2(self, fan_in: Optional[int] = None, fan_out: Optional[int] = None) -> float:
        p, s = self.weight_params, self.weight
        if s == "gaussian":
            return p["sigma_w"] ** 2
        if s == "uniform":
            return p["a"] ** 2 / 3.0
        if s in ("xavier_normal", "xavier_uniform"):
            if fan_in is None or fan_out is None:
                return p["gain"] ** 2               # square layers
            return p["gain"] ** 2 * 2.0 * fan_in / (fan_in + fan_out)
        if s in ("kaiming_normal", "kaiming_uniform", "lecun_normal", "orthogonal", "sparse"):
            return p["gain"] ** 2
        if s == "truncated_normal":
            return p["gain"] ** 2 * truncation_factor(p["cut"])
        if s == "pytorch_default":
            return 1.0 / 3.0
        raise ValueError(s)

    def sigma_b2(self, fan_in: Optional[int] = None) -> float:
        p, s = self.bias_params, self.bias
        if s == "zeros":
            return 0.0
        if s == "normal":
            return p["sigma_b"] ** 2
        if s == "uniform":
            return p["a_b"] ** 2 / 3.0
        if s == "constant":
            return p["b0"] ** 2
        if s == "pytorch_default":
            if fan_in is None:
                raise ValueError("pytorch_default bias needs fan_in")
            return 1.0 / (3.0 * fan_in)
        raise ValueError(s)

    def kurtosis_w(self, N: Optional[int] = None) -> float:
        """Excess kurtosis kappa_w of a single weight (0 for Gaussian); nan for orthogonal."""
        s, p = self.weight, self.weight_params
        if s in ("gaussian", "xavier_normal", "kaiming_normal", "lecun_normal"):
            return 0.0
        if s in ("uniform", "xavier_uniform", "kaiming_uniform", "pytorch_default"):
            return -1.2
        if s == "truncated_normal":
            return truncated_kurtosis(p["cut"])
        if s == "sparse":
            return 3.0 * N / p["k"] - 3.0 if N else np.nan
        if s == "orthogonal":
            return np.nan  # not i.i.d.
        raise ValueError(s)

    @property
    def iid(self) -> bool:
        return self.weight != "orthogonal"

    @property
    def is_paper_gaussian(self) -> bool:
        """True if the exact Markov reduction applies (i.i.d. Gaussian weights, Gaussian/zero bias)."""
        gauss_w = self.weight in ("gaussian", "xavier_normal", "kaiming_normal", "lecun_normal")
        return gauss_w and self.bias in ("zeros", "normal")

    def describe(self) -> str:
        wp = {k: round(float(v), 5) for k, v in self.weight_params.items()}
        bp = {k: round(float(v), 6) for k, v in self.bias_params.items()}
        return f"{self.weight}{wp} + bias {self.bias}{bp}  ->  sigma_w^2 = {self.sigma_w2():.5g}"

    # ------------------------------------------------------------------
    # Inverse map: (sigma_w^2, sigma_b^2) -> native parameters
    # ------------------------------------------------------------------
    @classmethod
    def from_sigma(cls, weight: str = "gaussian", sigma_w2: float = 1.0, sigma_b2: float = 0.0,
                   bias: Optional[str] = None, **extra) -> "Initializer":
        """
        Build an initializer of type `weight` whose MF knobs equal (sigma_w2, sigma_b2).
        Extra native parameters that do not affect sigma_w^2 (e.g. cut, k) can be passed.
        Bias default: 'normal' for the paper's Gaussian scheme, 'uniform' otherwise, 'zeros' if sigma_b2 = 0.
        """
        wp = dict(extra)
        if weight == "gaussian":
            wp["sigma_w"] = np.sqrt(sigma_w2)
        elif weight == "uniform":
            wp["a"] = np.sqrt(3.0 * sigma_w2)
        elif weight == "truncated_normal":
            wp.setdefault("cut", DEFAULTS["cut"])
            wp["gain"] = np.sqrt(sigma_w2 / truncation_factor(wp["cut"]))
        elif weight == "pytorch_default":
            if abs(sigma_w2 - 1 / 3) > 1e-12:
                raise ValueError("pytorch_default has fixed sigma_w^2 = 1/3")
        else:
            wp["gain"] = np.sqrt(sigma_w2)
        if bias is None:
            bias = "zeros" if sigma_b2 == 0 else ("normal" if weight == "gaussian" else "uniform")
        bp = {}
        if bias == "normal":
            bp["sigma_b"] = np.sqrt(sigma_b2)
        elif bias == "uniform":
            bp["a_b"] = np.sqrt(3.0 * sigma_b2)
        elif bias == "constant":
            bp["b0"] = np.sqrt(sigma_b2)
        elif bias == "zeros" and sigma_b2 != 0:
            raise ValueError("zeros bias cannot realise sigma_b2 > 0")
        return cls(weight, wp, bias, bp)

    # ------------------------------------------------------------------
    # Sampling
    # ------------------------------------------------------------------
    def sample_weights(self, n_out: int, n_in: int, rng: np.random.Generator) -> np.ndarray:
        """Draw one (n_out x n_in) weight matrix (float64 NumPy)."""
        s, p = self.weight, self.weight_params
        if s == "gaussian":
            return rng.normal(0.0, p["sigma_w"] / np.sqrt(n_in), (n_out, n_in))
        if s == "uniform":
            a = p["a"] / np.sqrt(n_in)
            return rng.uniform(-a, a, (n_out, n_in))
        if s == "xavier_normal":
            return rng.normal(0.0, p["gain"] * np.sqrt(2.0 / (n_in + n_out)), (n_out, n_in))
        if s == "xavier_uniform":
            a = p["gain"] * np.sqrt(6.0 / (n_in + n_out))
            return rng.uniform(-a, a, (n_out, n_in))
        if s in ("kaiming_normal", "lecun_normal"):
            return rng.normal(0.0, p["gain"] / np.sqrt(n_in), (n_out, n_in))
        if s == "kaiming_uniform":
            a = p["gain"] * np.sqrt(3.0 / n_in)
            return rng.uniform(-a, a, (n_out, n_in))
        if s == "truncated_normal":
            sd = p["gain"] / np.sqrt(n_in)
            c = p["cut"]
            W = rng.normal(0.0, 1.0, (n_out, n_in))
            bad = np.abs(W) > c
            while bad.any():                    # rejection sampling
                W[bad] = rng.normal(0.0, 1.0, bad.sum())
                bad = np.abs(W) > c
            return sd * W
        if s == "orthogonal":
            A = rng.normal(size=(max(n_out, n_in), min(n_out, n_in)))
            Q, R = np.linalg.qr(A)
            Q = Q * np.sign(np.diag(R))          # Haar measure (Mezzadri 2007)
            if n_out < n_in:
                Q = Q.T
            return p["gain"] * Q[:n_out, :n_in]
        if s == "sparse":
            k = int(p["k"])
            W = np.zeros((n_out, n_in))
            cols = np.argsort(rng.random((n_out, n_in)), axis=1)[:, :k]
            W[np.arange(n_out)[:, None], cols] = rng.normal(0.0, p["gain"] / np.sqrt(k), (n_out, k))
            return W
        if s == "pytorch_default":
            a = 1.0 / np.sqrt(n_in)
            return rng.uniform(-a, a, (n_out, n_in))
        raise ValueError(s)

    def sample_bias(self, n_out: int, n_in: int, rng: np.random.Generator) -> np.ndarray:
        s, p = self.bias, self.bias_params
        if s == "zeros":
            return np.zeros(n_out)
        if s == "normal":
            return rng.normal(0.0, p["sigma_b"], n_out)
        if s == "uniform":
            return rng.uniform(-p["a_b"], p["a_b"], n_out)
        if s == "constant":
            return np.full(n_out, p["b0"])
        if s == "pytorch_default":
            a = 1.0 / np.sqrt(n_in)
            return rng.uniform(-a, a, n_out)
        raise ValueError(s)


# ----------------------------------------------------------------------
# Standardised ("shape-only") torch samplers used by the full-network engine.
# Every scheme is  W = sqrt(sigma_w^2 / N) * W_hat,  b = sigma_b * b_hat  with unit-variance
# W_hat, b_hat whose *shape* is set by the scheme.  Sampling the shape once and rescaling it
# lets a whole (sigma_w^2, sigma_b^2) sweep share the same random numbers ("common random
# numbers"), which removes most of the noise from numerical derivatives such as dS/dsigma_w^2.
# ----------------------------------------------------------------------
def standardized_weights_torch(init: "Initializer", n_out: int, n_in: int, gen, device, dtype):
    import torch
    s, p = init.weight, init.weight_params
    kw = dict(generator=gen, device=device, dtype=dtype)
    if s in ("gaussian", "xavier_normal", "kaiming_normal", "lecun_normal"):
        return torch.randn(n_out, n_in, **kw)
    if s in ("uniform", "xavier_uniform", "kaiming_uniform", "pytorch_default"):
        return (2.0 * torch.rand(n_out, n_in, **kw) - 1.0) * np.sqrt(3.0)
    if s == "truncated_normal":
        c = float(p["cut"])
        W = torch.randn(n_out, n_in, **kw)
        bad = W.abs() > c
        while bool(bad.any()):
            W = torch.where(bad, torch.randn(n_out, n_in, **kw), W)
            bad = W.abs() > c
        return W / np.sqrt(truncation_factor(c))
    if s == "orthogonal":
        A = torch.randn(max(n_out, n_in), min(n_out, n_in), generator=gen, device=device, dtype=dtype)
        Q, R = torch.linalg.qr(A.cpu() if str(device).startswith("mps") else A)
        Q = (Q * torch.sign(torch.diagonal(R))).to(device)
        if n_out < n_in:
            Q = Q.T
        return Q[:n_out, :n_in] * np.sqrt(n_in)
    if s == "sparse":
        k = int(p["k"])
        order = torch.rand(n_out, n_in, **kw).argsort(dim=1)[:, :k]
        W = torch.zeros(n_out, n_in, device=device, dtype=dtype)
        W.scatter_(1, order, torch.randn(n_out, k, **kw) * np.sqrt(n_in / k))
        return W
    raise ValueError(s)


def standardized_bias_torch(init: "Initializer", n_out: int, gen, device, dtype):
    import torch
    kw = dict(generator=gen, device=device, dtype=dtype)
    if init.bias == "zeros":
        return torch.zeros(n_out, device=device, dtype=dtype)
    if init.bias == "normal":
        return torch.randn(n_out, **kw)
    if init.bias in ("uniform", "pytorch_default"):
        return (2.0 * torch.rand(n_out, **kw) - 1.0) * np.sqrt(3.0)
    if init.bias == "constant":
        return torch.ones(n_out, device=device, dtype=dtype) * float(np.sign(init.bias_params["b0"]) or 1.0)
    raise ValueError(init.bias)


def list_schemes() -> str:
    """Pretty table of all schemes and their native parameters (printed in the notebook)."""
    lines = ["WEIGHT SCHEMES"]
    for k, (params, d) in WEIGHT_SCHEMES.items():
        lines.append(f"  {k:17s} params={list(params)!s:22s} {d}")
    lines.append("BIAS SCHEMES")
    for k, (params, d) in BIAS_SCHEMES.items():
        lines.append(f"  {k:17s} params={list(params)!s:22s} {d}")
    return "\n".join(lines)
