"""
meanfield.py
============

Mean-field (N -> infinity) theory of signal propagation in deep random networks,
written in the language of Christensen & Moloney, *Complexity and Criticality*.

Dictionary (paper  ->  this code / Christensen & Moloney)
---------------------------------------------------------
    q_l^(MF)                      ->  q_l          layer variance ("signal energy")
    q_ss^(MF)                     ->  q*           order parameter (stationary state)
    sqrt(q_ss)                    ->  m = sqrt(q*) signal strength
    sigma_w^2                     ->  control parameter;  t = sigma_w^2 / sigma_{w,c}^2 - 1 (reduced)
    sigma_b^2                     ->  h            external field (conjugate to q)
    chi_{sigma_w^2} (paper eq. 5) ->  chi_t = d m / d sigma_w^2   ("sigma_w-susceptibility")
    chi_{sigma_b^2}               ->  chi_b = d m / d h
    -                             ->  chi_h = d q* / d h            (the susceptibility proper)
    -                             ->  xi   = depth correlation length of q_l (analogue of xi)

The variance map (derivations/00_framework_and_notation.md, eq. (F1)):

        q_{l+1} = F(q_l) = sigma_w^2 V(q_l) + sigma_b^2,       V(q) = E_z[phi(sqrt(q) z)^2].

Everything below is a functional of V(q), V'(q) and P(q) = E_z[phi'(sqrt(q) z)^2].
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np

from .activations import Activation, get_activation
from .gauss import gauss_expect, gauss_expect2


class MeanField:
    """Mean-field theory for one activation function.

    Parameters
    ----------
    activation : str or Activation
    n_quad     : Gauss-Legendre nodes per panel for all Gaussian integrals
    q_min, q_max, n_grid : log-spaced grid used to *bracket* fixed points
                 (the roots are then refined to machine precision with exact quadrature)
    """

    def __init__(self, activation="tanh", n_quad: int = 64,
                 q_min: float = 1e-30, q_max: float = 1e6, n_grid: int = 1500, **act_params):
        self.act: Activation = get_activation(activation, **act_params)
        self.n_quad = n_quad
        self.q_grid = np.logspace(np.log10(q_min), np.log10(q_max), n_grid)
        self.V_grid = self.V(self.q_grid)

    # ------------------------------------------------------------------
    # Gaussian functionals of phi
    # ------------------------------------------------------------------
    def V(self, q):
        """V(q) = E[phi(sqrt q z)^2] (closed form if known, else kink-aware quadrature)."""
        q = np.asarray(q, float)
        if self.act.V_exact is not None:
            return np.asarray(self.act.V_exact(q), float)
        phi = self.act.phi
        return gauss_expect(lambda x: phi(x) ** 2, q, self.act.kinks, n=self.n_quad).reshape(q.shape)

    def dV(self, q):
        """V'(q) = E[phi(u) phi'(u) z] / sqrt(q),  u = sqrt(q) z  (Gaussian integration by parts)."""
        q = np.asarray(q, float)
        qs = np.maximum(q, 1e-300)
        phi, dphi = self.act.phi, self.act.dphi
        out = gauss_expect(lambda x: phi(x) * dphi(x) * x, qs, self.act.kinks, n=self.n_quad) / qs
        # E[phi phi' u]/q with u = sqrt(q) z  equals  E[phi phi' z]/sqrt(q)
        out = np.where(q > 0, out, self.act.germ.V1 if self.act.germ else np.nan)
        return out.reshape(q.shape)

    def P(self, q):
        """P(q) = E[phi'(sqrt q z)^2]; chi_1 = sigma_w^2 P(q*) is the edge-of-chaos multiplier."""
        q = np.asarray(q, float)
        d = self.act.dphi
        return gauss_expect(lambda x: d(x) ** 2, q, self.act.kinks, n=self.n_quad).reshape(q.shape)

    def qmap(self, q, sw2, sb2=0.0):
        """One layer of the MF variance map F(q) = sigma_w^2 V(q) + sigma_b^2."""
        return sw2 * self.V(q) + sb2

    # ------------------------------------------------------------------
    # Fixed points
    # ------------------------------------------------------------------
    def fixed_point(self, sw2, sb2=0.0, q_init: float = 1.0, chunk: int = 1500, n_bisect: int = 52):
        """
        Stationary variance q* reached by iterating the map from q_init.

        For a monotone increasing map F (true for every activation here) the attractor
        reached from q_init is the nearest root of G(q) = F(q) - q in the direction of
        sign G(q_init).  Returns 0 in the absorbing phase (h = 0, t <= 0) and +inf when
        the signal runs away (unbounded phi with sigma_w^2 r_inf > 1).

        Vectorised over broadcastable arrays ``sw2``, ``sb2``.
        """
        sw2, sb2 = np.broadcast_arrays(np.asarray(sw2, float), np.asarray(sb2, float))
        shape = sw2.shape
        sw2, sb2 = sw2.ravel(), sb2.ravel()
        out = np.empty(sw2.size)
        qg, Vg = self.q_grid, self.V_grid
        V0 = float(self.V(np.array([0.0]))[0])
        Vq0 = float(self.V(np.array([q_init]))[0])
        i0 = np.searchsorted(qg, q_init)
        for s in range(0, sw2.size, chunk):
            w, h = sw2[s:s + chunk, None], sb2[s:s + chunk, None]
            G = w * Vg[None, :] + h - qg[None, :]
            G0 = (w * Vq0 + h - q_init)[:, 0]
            lo = np.full(w.shape[0], np.nan)
            hi = np.full(w.shape[0], np.nan)
            res = np.full(w.shape[0], np.nan)
            # --- case G(q_init) > 0: signal grows -> first root above q_init
            up = G0 > 0
            if up.any():
                Gu = G[up][:, i0:]
                neg = Gu <= 0
                has = neg.any(axis=1)
                j = np.argmax(neg, axis=1) + i0
                idx = np.where(up)[0]
                res[idx[~has]] = np.inf
                jj = j[has]
                lo[idx[has]] = np.where(jj - 1 >= i0, qg[np.maximum(jj - 1, 0)], q_init)
                hi[idx[has]] = qg[jj]
            # --- case G(q_init) < 0: signal decays -> last root below q_init
            dn = G0 < 0
            if dn.any():
                Gd = G[dn][:, :i0]
                pos = Gd >= 0
                has = pos.any(axis=1)
                idx = np.where(dn)[0]
                jrev = np.argmax(pos[:, ::-1], axis=1)
                j = i0 - 1 - jrev
                # no bracket: absorbing state q* = 0 (only possible when V0 = 0 and h = 0)
                res[idx[~has]] = 0.0
                jj = j[has]
                lo[idx[has]] = qg[jj]
                hi[idx[has]] = np.where(jj + 1 < i0, qg[np.minimum(jj + 1, qg.size - 1)], q_init)
            res[G0 == 0] = q_init
            # --- vectorised bisection in log q on the brackets, with the *exact* V
            need = np.isfinite(lo) & np.isfinite(hi) & np.isnan(res)
            if need.any():
                a, b = np.log(lo[need]), np.log(hi[need])
                ww, hh = w[need, 0], h[need, 0]
                Ga = ww * self.V(np.exp(a)) + hh - np.exp(a)
                for _ in range(n_bisect):
                    m = 0.5 * (a + b)
                    Gm = ww * self.V(np.exp(m)) + hh - np.exp(m)
                    same = np.sign(Gm) == np.sign(Ga)
                    a = np.where(same, m, a)
                    Ga = np.where(same, Gm, Ga)
                    b = np.where(same, b, m)
                res[need] = np.exp(0.5 * (a + b))
            out[s:s + chunk] = res
        del V0
        return out.reshape(shape)

    # ------------------------------------------------------------------
    # Response functions and correlation lengths at the fixed point
    # ------------------------------------------------------------------
    def response(self, sw2, sb2=0.0, q=None, q_init: float = 1.0) -> Dict[str, np.ndarray]:
        """
        All MF observables at the fixed point (vectorised).

        Returns a dict with
            q        : q*
            m        : sqrt(q*)                        signal strength
            slope    : F'(q*) = sigma_w^2 V'(q*)       (< 1 for a stable fixed point)
            chi_h    : dq*/dh = 1/(1 - F'(q*))         susceptibility (conjugate field h = sigma_b^2)
            chi_t    : dm/dsigma_w^2                   paper's sigma_w-susceptibility (eq. 5, 9)
            chi_b    : dm/dh                           paper's sigma_b-susceptibility
            xi       : -1/ln F'(q*)                    depth correlation length of q_l
            chi1     : sigma_w^2 P(q*)                 edge-of-chaos multiplier (ordered iff < 1)
            zeta_c   : -1/ln chi1  (ordered phase)     cross-input correlation depth
        """
        sw2, sb2 = np.broadcast_arrays(np.asarray(sw2, float), np.asarray(sb2, float))
        if q is None:
            q = self.fixed_point(sw2, sb2, q_init=q_init)
        q = np.asarray(q, float)
        fin = np.isfinite(q)
        qf = np.where(fin, q, 1.0)
        Vq = self.V(qf)
        dVq = self.dV(qf)
        slope = sw2 * dVq
        with np.errstate(divide="ignore", invalid="ignore"):
            chi_h = 1.0 / (1.0 - slope)
            dq_dsw2 = Vq * chi_h
            m = np.sqrt(qf)
            chi_t = np.where(qf > 0, dq_dsw2 / (2 * m), 0.0)
            chi_b = np.where(qf > 0, chi_h / (2 * m), np.inf)
            xi = -1.0 / np.log(np.abs(slope))
            chi1 = sw2 * self.P(qf)
            zeta_c = np.where(chi1 < 1, -1.0 / np.log(chi1), np.nan)
        nanify = lambda a: np.where(fin, a, np.nan)
        return dict(q=q, m=np.where(fin, m, np.inf), slope=nanify(slope), chi_h=nanify(chi_h),
                    chi_t=nanify(chi_t), chi_b=nanify(chi_b), xi=nanify(xi),
                    chi1=nanify(chi1), zeta_c=nanify(zeta_c))

    # ------------------------------------------------------------------
    # Cross-input correlations (edge of chaos, Schoenholz et al. 2016)
    # ------------------------------------------------------------------
    def cmap(self, c, q, sw2, sb2=0.0):
        """Correlation map C_{l+1} = [sigma_w^2 E[phi(u1) phi(u2)] + sigma_b^2] / q*."""
        phi = self.act.phi
        return (sw2 * gauss_expect2(phi, phi, q, c, self.act.kinks) + sb2) / q

    def chaotic_correlation(self, sw2, sb2=0.0, q=None, n_iter: int = 400):
        """Stable fixed point c* of the C-map and chi_c = sigma_w^2 E[phi'(u1)phi'(u2)] at c*."""
        if q is None:
            q = float(self.fixed_point(sw2, sb2))
        c = 0.0
        for _ in range(n_iter):
            c_new = float(np.clip(self.cmap(c, q, sw2, sb2), -1.0, 1.0))
            if abs(c_new - c) < 1e-12:
                break
            c = c_new
        d = self.act.dphi
        chi_c = sw2 * gauss_expect2(d, d, q, c, self.act.kinks)
        zeta = -1.0 / np.log(chi_c) if 0 < chi_c < 1 else np.inf
        return c, chi_c, zeta

    def edge_of_chaos(self, q=None):
        """
        Edge of chaos chi_1 = sigma_w^2 P(q*) = 1, parametrised exactly by q* (derivations, eq. F12):

            sigma_w^2(q) = 1/P(q),      h(q) = q - V(q)/P(q).

        Only the part with h >= 0 is physical.
        """
        if q is None:
            q = np.logspace(-10, 1, 800)
        q = np.asarray(q, float)
        Pq = self.P(q)
        sw2 = 1.0 / Pq
        h = q - self.V(q) / Pq
        ok = h >= 0
        return sw2[ok], h[ok], q[ok]

    # ------------------------------------------------------------------
    # Widom-like line
    # ------------------------------------------------------------------
    def widom_line(self, h_values, sw2_grid=None, observable: str = "chi_t", R=None):
        """
        Locus of the maximum of a response function at fixed field h = sigma_b^2 > 0.
        Default observable: the paper's chi_t = d sqrt(q*)/d sigma_w^2 ('chi_h' for dq*/dh).
        Returns arrays (sw2_max, chi_max), refined by a parabola through the top 3 grid points
        (in the index coordinate, so non-uniform grids are fine).  NaN where the maximum sits on
        the boundary of the grid (no interior ridge).  Pass R = self.response(...) on the
        (h, sw2) mesh to reuse a computation.
        """
        if sw2_grid is None:
            c = self.act.germ.sigma_w2_c if self.act.germ else 1.0
            sw2_grid = c * np.linspace(0.95, 1.6, 1400)
        sw2_grid = np.asarray(sw2_grid, float)
        if R is None:
            W, H = np.meshgrid(sw2_grid, np.asarray(h_values, float))
            R = self.response(W, H)
        Z = R[observable]
        sw2_max = np.full(Z.shape[0], np.nan)
        chi_max = np.full(Z.shape[0], np.nan)
        idx = np.arange(sw2_grid.size)
        for i in range(Z.shape[0]):
            r = Z[i]
            if not np.isfinite(r).any():
                continue
            j = int(np.nanargmax(r))
            if 0 < j < r.size - 1 and np.all(np.isfinite(r[j - 1:j + 2])):
                y0, y1, y2 = r[j - 1:j + 2]
                den = (y0 - 2 * y1 + y2)
                shift = 0.5 * (y0 - y2) / den if den != 0 else 0.0
                sw2_max[i] = np.interp(j + shift, idx, sw2_grid)
                chi_max[i] = y1 - 0.25 * (y0 - y2) * shift
        return sw2_max, chi_max

    # ------------------------------------------------------------------
    # Depth dynamics
    # ------------------------------------------------------------------
    def trajectory(self, q0: float, L: int, sw2: float, sb2: float = 0.0, use_grid: bool = False):
        """Deterministic MF depth profile q_0, q_1, ..., q_L."""
        q = np.empty(L + 1)
        q[0] = q0
        if use_grid:  # fast log-log interpolation of V (for very long runs)
            lq, lV = np.log(self.q_grid), np.log(np.maximum(self.V_grid, 1e-320))
            Vf = lambda x: np.exp(np.interp(np.log(x), lq, lV))
        else:
            Vf = lambda x: float(self.V(np.array([x]))[0])
        for l in range(L):
            q[l + 1] = sw2 * Vf(q[l]) + sb2
        return q


# ----------------------------------------------------------------------
# Automatic "universality-class detector"
# ----------------------------------------------------------------------
def detect_germ(mf: MeanField, q_lo: float = 1e-7, q_hi: float = 1e-3) -> Dict[str, float]:
    """
    Numerically determine the Landau germ V(q) = V0 + V1 q - c q^(1+theta) of *any* activation
    (useful for user-defined activations; used in the tests to check the analytic germs).
    """
    V0 = float(mf.V(np.array([0.0]))[0])
    if V0 == 0:
        qs = 1e-12
    else:  # an intrinsic field: avoid catastrophic cancellation against V0
        qs, q_lo, q_hi = 1e-5, 1e-3, 3e-2
    V1 = float((mf.V(np.array([qs]))[0] - V0) / qs)
    if V0 != 0:  # second-order accurate one-sided derivative
        V1 = float((4 * mf.V(np.array([qs]))[0] - mf.V(np.array([2 * qs]))[0] - 3 * V0) / (2 * qs))
    q = np.logspace(np.log10(q_lo), np.log10(q_hi), 25)
    r = V0 + V1 * q - mf.V(q)                     # = c q^{1+theta} + ...
    r_inf = float(mf.V(np.array([1e8]))[0] / 1e8)
    out = dict(V0=V0, V1=V1, r_inf=r_inf)
    if np.all(np.abs(r) < 1e-13 * (V1 * q + V0 + 1e-300)):
        if r_inf < 0.999 * V1:
            out.update(theta=np.inf, c=0.0,
                       note="correction vanishes faster than any power (essential singularity)")
        else:
            out.update(theta=np.inf, c=0.0, note="exactly linear map (positively homogeneous phi)")
        return out
    ok = np.abs(r) > 0
    slope, icpt = np.polyfit(np.log(q[ok]), np.log(np.abs(r[ok])), 1)
    theta = slope - 1.0
    if theta > 4:
        out.update(theta=np.inf, c=0.0, note="correction vanishes faster than any power (essential singularity)")
        return out
    out.update(theta=theta, c=float(np.sign(np.median(r[ok])) * np.exp(icpt)))
    return out
