"""
training.py -- learning performance vs initialisation (paper Fig. 3 c, f).  Requires torch + torchvision.

training_grid  : training accuracy after E epochs on MNIST over a (sigma_w^2, sigma_b^2) grid,
                 overlaid on the MF quasi-critical ridge (paper Fig. 3c); any initializer / activation.
training_width : epochs needed to reach a target training accuracy vs (sigma_w^2, width N), sigma_b^2 = 0
                 (paper Fig. 3f).

As in the paper: SGD, lr = 1e-3, batch 128, cross-entropy, a fixed subset of the MNIST training set
(n_batches x 128 images); accuracy = fraction of correctly classified training images seen during
the epoch.  Thread counts are fixed for reproducibility (paper Methods).
"""
from __future__ import annotations

import os
import time

import matplotlib.pyplot as plt
import numpy as np

from ..activations import get_activation
from ..initializers import Initializer
from ..meanfield import MeanField
from ..plotting import CMAP_COOL, DEEP_BLUE, FIT_COLOR, dots, heatmap, label
from ..simulate import resolve_device
from .common import Run, merge


def set_threads(n: int = 8):
    import torch
    for v in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        os.environ[v] = str(n)
    torch.set_num_threads(n)
    try:
        torch.set_num_interop_threads(n)
    except RuntimeError:
        pass


def synthetic_subset(n_batches: int, batch_size: int = 128, seed: int = 0, dim: int = 784):
    """Offline stand-in for MNIST: 10 Gaussian clusters in 784 dimensions (for testing the pipeline)."""
    import torch
    g = torch.Generator().manual_seed(seed)
    centres = torch.randn(10, dim, generator=g) * 0.15
    y = torch.randint(0, 10, (n_batches * batch_size,), generator=g)
    X = centres[y] + torch.randn(y.numel(), dim, generator=g)
    return X, y


def mnist_subset(n_batches: int, batch_size: int = 128, data_dir: str = "data", seed: int = 0,
                 dataset: str = "mnist"):
    """Tensor dataset of n_batches * batch_size flattened MNIST training images (downloaded once)."""
    import torch
    if dataset == "synthetic":
        return synthetic_subset(n_batches, batch_size, seed)
    from torchvision import datasets, transforms
    ds = datasets.MNIST(data_dir, train=True, download=True, transform=transforms.ToTensor())
    g = torch.Generator().manual_seed(seed)
    idx = torch.randperm(len(ds), generator=g)[: n_batches * batch_size]
    X = ds.data[idx].float().div(255.0).view(-1, 784)
    X = (X - 0.1307) / 0.3081                       # standard MNIST normalisation
    y = ds.targets[idx]
    return X, y


def build_mlp(depth: int, width: int, activation, init: Initializer, seed: int = 0, in_dim=784, out_dim=10):
    """Fully connected net: input -> depth hidden layers of width N -> output, initialised by `init`."""
    import torch
    import torch.nn as nn
    act = get_activation(activation)
    rng = np.random.default_rng(seed)
    dims = [in_dim] + [width] * depth + [out_dim]
    layers = []
    for i in range(len(dims) - 1):
        lin = nn.Linear(dims[i], dims[i + 1])
        with torch.no_grad():
            lin.weight.copy_(torch.as_tensor(init.sample_weights(dims[i + 1], dims[i], rng)))
            lin.bias.copy_(torch.as_tensor(init.sample_bias(dims[i + 1], dims[i], rng)))
        layers.append(lin)
        if i < len(dims) - 2:
            layers.append(act.torch_module())
    return nn.Sequential(*layers)


def train(model, X, y, epochs: int, lr: float = 1e-3, batch_size: int = 128, device="cpu",
          target: float | None = None, seed: int = 0):
    """SGD training; returns per-epoch training accuracy and the epoch at which `target` was reached."""
    import torch
    torch.manual_seed(seed)
    model = model.to(device)
    X, y = X.to(device), y.to(device)
    opt = torch.optim.SGD(model.parameters(), lr=lr)
    lossf = torch.nn.CrossEntropyLoss()
    accs, reached = [], None
    n = X.shape[0]
    for ep in range(epochs):
        perm = torch.randperm(n, device=device)
        correct = 0
        for b in range(0, n, batch_size):
            idx = perm[b:b + batch_size]
            out = model(X[idx])
            loss = lossf(out, y[idx])
            opt.zero_grad()
            loss.backward()
            opt.step()
            correct += (out.argmax(1) == y[idx]).sum().item()
        acc = correct / n
        accs.append(acc)
        if not np.isfinite(loss.item()):
            accs += [0.1] * (epochs - ep - 1)
            break
        if target is not None and acc >= target:
            reached = ep + 1
            break
    return accs, reached


TRAIN_GRID_DEFAULTS = dict(
    activation="tanh", init="gaussian", depth=50, width=100, epochs=3, n_batches=100, lr=1e-3,
    sw2_range=[0.9, 1.44], n_sw2=12, log10_sb2=[None, -4.0, -2.2], seed=0, device="auto", threads=8,
    data_dir="data", dataset="mnist",
)


def exp_training_grid(run: Run, cfg=None):
    cfg = merge(TRAIN_GRID_DEFAULTS, cfg)
    set_threads(cfg["threads"])
    device, _ = resolve_device(cfg["device"])
    X, y = mnist_subset(cfg["n_batches"], data_dir=cfg["data_dir"], seed=cfg["seed"], dataset=cfg["dataset"])
    sw2 = np.linspace(*cfg["sw2_range"], cfg["n_sw2"])
    acc = np.zeros((len(cfg["log10_sb2"]), sw2.size))
    t0 = time.time()
    for i, l in enumerate(cfg["log10_sb2"]):
        sb2 = 0.0 if l is None else 10.0 ** l
        for j, s in enumerate(sw2):
            init = Initializer.from_sigma(cfg["init"], s, sb2)
            model = build_mlp(cfg["depth"], cfg["width"], cfg["activation"], init, seed=cfg["seed"])
            accs, _ = train(model, X, y, cfg["epochs"], cfg["lr"], device=device, seed=cfg["seed"])
            acc[i, j] = accs[-1]
        print(f"  sigma_b^2 row {i + 1}/{len(cfg['log10_sb2'])} ({time.time() - t0:.0f}s)")
    from .mean_field import _sb2_colors
    cols = _sb2_colors(len(cfg["log10_sb2"]))
    mf = MeanField(cfg["activation"])
    fig, axs = plt.subplots(1, 2, figsize=(11, 4.2))
    for c, l, a in zip(cols, cfg["log10_sb2"], acc):
        lab = r"$\sigma_b^2=0$" if l is None else f"$\\log_{{10}}\\sigma_b^2={l}$"
        axs[0].plot(sw2, a, "-", color=c, lw=0.6, alpha=0.6)
        dots(axs[0], sw2, a, color=c, label_=lab)
        sb2 = 0.0 if l is None else 10.0 ** l
        axs[1].plot(sw2, mf.response(sw2, sb2)["chi_t"], "-", color=c, lw=1.2, label=lab)
    axs[0].axhline(0.8, color=FIT_COLOR, ls="--", lw=0.8, label="80%")
    label(axs[0], r"$\sigma_w^2$", "accuracy",
          f"(c) training accuracy, L={cfg['depth']}, N={cfg['width']}, {cfg['epochs']} epochs")
    axs[0].legend(fontsize=7)
    axs[1].set_ylim(0, 5)
    label(axs[1], r"$\sigma_w^2$", r"$\chi_{\sigma_w^2}$", "MF susceptibility (same colours)")
    axs[1].legend(fontsize=7)
    fig.suptitle(f"Learning vs quasi-criticality ({cfg['activation']}, init={cfg['init']})")
    fig.tight_layout()
    run.fig(fig, f"training_grid_{cfg['init']}")
    out = dict(sw2=sw2, acc=acc, seconds=time.time() - t0)
    run.record(f"training_grid_{cfg['init']}", out)
    return out


TRAIN_WIDTH_DEFAULTS = dict(
    activation="tanh", init="gaussian", depth=50, widths=[50, 100, 200], epochs=10, target=0.97,
    n_batches=100, lr=1e-3, sw2_range=[0.9, 1.44], n_sw2=10, seed=0, device="auto", threads=8, data_dir="data",
    dataset="mnist",
)


def exp_training_width(run: Run, cfg=None):
    cfg = merge(TRAIN_WIDTH_DEFAULTS, cfg)
    set_threads(cfg["threads"])
    device, _ = resolve_device(cfg["device"])
    X, y = mnist_subset(cfg["n_batches"], data_dir=cfg["data_dir"], seed=cfg["seed"], dataset=cfg["dataset"])
    sw2 = np.linspace(*cfg["sw2_range"], cfg["n_sw2"])
    E = np.full((len(cfg["widths"]), sw2.size), np.nan)
    for i, N in enumerate(cfg["widths"]):
        for j, s in enumerate(sw2):
            model = build_mlp(cfg["depth"], N, cfg["activation"], Initializer.from_sigma(cfg["init"], s, 0.0),
                              seed=cfg["seed"])
            _, reached = train(model, X, y, cfg["epochs"], cfg["lr"], device=device, target=cfg["target"],
                               seed=cfg["seed"])
            E[i, j] = np.nan if reached is None else reached
    fig, ax = plt.subplots(figsize=(6, 4.2))
    heatmap(ax, sw2, np.array(cfg["widths"], float), E, cmap=CMAP_COOL, logy=False,
            cbar_label="epochs")
    label(ax, r"$\sigma_w^2$", r"$N$", f"(f) epochs to {int(cfg['target'] * 100)}% (white: not reached)")
    fig.tight_layout()
    run.fig(fig, "training_width")
    run.record("training_width", dict(sw2=sw2, widths=cfg["widths"], epochs=E))
    return E
