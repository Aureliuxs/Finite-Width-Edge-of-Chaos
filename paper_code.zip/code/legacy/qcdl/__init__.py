"""qcdl: quasi-criticality in deep learning."""
