"""
Experiment registry.  Each experiment is  f(run: Run, cfg: dict | None) -> results,
where cfg overrides the experiment's *_DEFAULTS dict (see the individual modules).
"""
from .avalanches import (exp_avalanche_susceptibility, exp_avalanches, exp_depth_fss, exp_finite_n_widom,
                         exp_initializer_survey)
from .common import Run
from .mean_field import exp_activation_survey, exp_mf_exponents, exp_mf_landscape, exp_phase_diagram


def _training_grid(run, cfg=None):
    from .training import exp_training_grid
    return exp_training_grid(run, cfg)


def _training_width(run, cfg=None):
    from .training import exp_training_width
    return exp_training_width(run, cfg)


def _resnet(run, cfg=None):
    from .resnet import exp_resnet
    return exp_resnet(run, cfg)


EXPERIMENTS = {
    # --- mean field (paper eqs. 3-9, Figs. 3a-b, 5) and extensions
    "mf_exponents": exp_mf_exponents,
    "mf_landscape": exp_mf_landscape,
    "phase_diagram": exp_phase_diagram,
    "activation_survey": exp_activation_survey,
    # --- finite width (paper Figs. 2, 3d-e) and extensions
    "avalanches": exp_avalanches,
    "avalanche_susceptibility": exp_avalanche_susceptibility,
    "depth_fss": exp_depth_fss,
    "initializer_survey": exp_initializer_survey,
    "finite_n_widom": exp_finite_n_widom,
    # --- optional (need torchvision + data / longer runtimes): paper Figs. 3c, 3f, 4
    "training_grid": _training_grid,
    "training_width": _training_width,
    "resnet": _resnet,
}

__all__ = ["EXPERIMENTS", "Run"]
