"""
avalanches.py -- finite-width (event-resolved) experiments.

avalanches                : paper Fig. 2 -- crackling-noise statistics vs width N, with the
                            Brownian-excursion predictions overlaid (no fit parameters)
avalanche_susceptibility  : paper Fig. 3(d,e) -- mean avalanche size and chi = dS/dsigma_w^2 over the
                            (sigma_w^2, sigma_b^2) plane, any initializer, + heat map of the ridge
depth_fss                 : Christensen & Moloney finite-size scaling in the depth L: data collapse and
                            moment analysis  <s^k> ∝ L^{D(1+k-tau_s)}
initializer_survey        : 10 initialisation schemes: finite-N critical point and avalanche class
finite_n_widom            : finite-N stationary signal strength: simulation vs Fokker-Planck theory vs MF
"""
from __future__ import annotations

import time

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import LinearSegmentedColormap, LogNorm

from ..finite_n import (BROWNIAN_EXCURSION, excursion_mean_shape, excursion_mean_size, sigma_c2_finite_N,
                        sparre_andersen_expected_mle, sparre_andersen_pmf, stationary_moments,
                        valid_fraction_exact)
from ..fitting import (find_xmin, fit_powerlaw, fss_extrapolate, log_bin, loglog_fit, mean_shapes,
                       moment_analysis, shape_collapse, size_duration_fit, size_duration_fit_corrected)
from ..initializers import WEIGHT_SCHEMES, Initializer
from ..meanfield import MeanField
from ..plotting import (BLUE, CMAP_WARM, DEEP_BLUE, DEEP_RED, FIT_COLOR, LIGHT_BLUE, ORANGE, PALETTE, RED,
                        dots, fit_line, heatmap, label, powerlaw_guide)
from ..simulate import SimConfig, lyapunov_exponent, run_avalanches, stationary_signal
from .common import Run, fmt, merge

BE = BROWNIAN_EXCURSION
PAPER_OFFSETS = {25: 0.03, 50: 0.015, 75: 0.009, 100: 0.005, 200: 0.002, 500: 0.001, 1000: 0.001}


def _width_colors(n):
    cm = LinearSegmentedColormap.from_list("w", [DEEP_RED, RED, ORANGE, "#9CC3E6", BLUE, DEEP_BLUE])
    return [cm(x) for x in np.linspace(0, 1, n)]


def choose_sigma_w2(mode, N, activation="tanh", kappa_w=0.0):
    """'theory' -> sigma_c^2(N) (eq. W4);  'paper' -> 1 + paper's delta(N);  'mf' -> 1/V1;  float -> itself."""
    if isinstance(mode, (int, float)):
        return float(mode)
    if mode == "theory":
        return sigma_c2_finite_N(activation, N, kappa_w)
    if mode == "paper":
        return 1.0 + PAPER_OFFSETS.get(N, 1.0 / N)
    if mode == "mf":
        return MeanField(activation).act.germ.sigma_w2_c
    raise ValueError(mode)


def analyze(av, L, T_min=10, s_xmin="ks", s_max_quantile=0.999, T_fit=(5, None), N=None):
    """
    Exponents of one avalanche sample:
      tau_t         truncated discrete MLE on [T_min, L-1]           (uncensored avalanches)
      tau_t_SA      what the same estimator returns on the exact Sparre-Andersen law (window bias)
      tau_s         truncated continuous MLE, x_min by KS
      D_over_z      WLS of <s>_T over T_fit (paper's gamma)
      D_over_z_small  WLS restricted to the small-excursion (Brownian) regime T <= N/4
      D_over_z_corr   same window, with the leading correction to scaling  A T^{D/z} (1 + B T^{-1/2})
    """
    S, T = av.uncensored()
    out = {}
    ft = fit_powerlaw(T, T_min, L - 1, discrete=True)
    out["tau_t"], out["tau_t_err"] = ft["tau"], ft["err"]
    out["tau_t_SA"] = sparre_andersen_expected_mle(T_min, L - 1)
    smax = float(np.quantile(S, s_max_quantile)) if S.size else np.nan
    if s_xmin == "ks":
        cand = np.logspace(np.log10(np.quantile(S, 0.05)), np.log10(np.quantile(S, 0.7)), 25)
        fs = find_xmin(S, discrete=False, xmax=smax, candidates=cand)
    else:
        fs = fit_powerlaw(S, float(s_xmin), smax)
    out["tau_s"], out["tau_s_err"], out["s_min"], out["s_max"] = fs["tau"], fs["err"], fs["xmin"], smax
    Tmax = T_fit[1] if T_fit[1] else L - 1
    sd = size_duration_fit(av.T, av.S, T_fit[0], Tmax)
    out["D_over_z"], out["D_over_z_err"] = sd["slope"], sd["stderr"]
    # the Brownian regime is T << N (sec. 4 of derivations/21): the corrected fit and the 'small' fit
    # are restricted to T <= N/4, where the size is still linear in the log-signal
    out["D_over_z_corr"] = out["D_over_z_corr_err"] = np.nan
    if N is not None and N / 4 > 3 * T_fit[0]:
        Tb = min(Tmax, N / 4)
        ss = size_duration_fit(av.T, av.S, T_fit[0], Tb)
        out["D_over_z_small"], out["D_over_z_small_err"] = ss["slope"], ss["stderr"]
        if Tb >= 10 * max(T_fit[0], 20):      # needs >= 1 decade above T = 20 (higher corrections small)
            sc = size_duration_fit_corrected(av.T, av.S, max(T_fit[0], 20), Tb)
            out["D_over_z_corr"], out["D_over_z_corr_err"] = sc["slope"], sc["stderr"]
    out["crackling_prediction"] = (out["tau_t"] - 1) / (out["tau_s"] - 1)
    out["_sd"] = sd
    return out


# ======================================================================
# Paper Fig. 2
# ======================================================================
AVALANCHE_DEFAULTS = dict(
    activation="tanh", Ns=[25, 50, 100, 200, 500, 1000], L=3000, q0=0.01,
    n_avalanches=100000, engine="markov", sigma_w2="theory", batch_elements=2e7,
    T_min=10, profile_range=[20, 400], shape_T=[40, 300], seed=0, device="auto",
)


def exp_avalanches(run: Run, cfg=None):
    cfg = merge(AVALANCHE_DEFAULTS, cfg)
    Ns, L = cfg["Ns"], cfg["L"]
    res, avs = {}, {}
    for N in Ns:
        sw2 = choose_sigma_w2(cfg["sigma_w2"], N, cfg["activation"])
        sc = SimConfig(N=N, L=L, activation=cfg["activation"], init=Initializer.from_sigma("gaussian", sw2),
                       q0=cfg["q0"], engine=cfg["engine"], batch_size=int(min(50000, max(2000, cfg["batch_elements"] / N))),
                       profile_range=tuple(cfg["profile_range"]), seed=cfg["seed"], device=cfg["device"])
        t0 = time.time()
        av = run_avalanches(sc, n_avalanches=cfg["n_avalanches"])
        a = analyze(av, L, T_min=cfg["T_min"], N=N)
        a.update(N=N, sigma_w2=sw2, seconds=time.time() - t0, frac_censored=float(av.censored.mean()),
                 frac_valid=av.S.size / av.n_perturbations)
        res[N], avs[N] = a, av
        print(f"  N={N}: sigma_w^2={sw2:.5f}  tau_s={fmt(a['tau_s'], a['tau_s_err'])}  "
              f"tau_t={fmt(a['tau_t'], a['tau_t_err'])}  D/z={fmt(a['D_over_z'], a['D_over_z_err'])}  "
              f"({a['seconds']:.1f}s)")

    cols = _width_colors(len(Ns))
    fig, axs = plt.subplots(2, 4, figsize=(18, 8.4))
    axs = axs.ravel()
    Nmax = Ns[-1]
    # (a) size distributions, aligned by s -> sqrt(N) s (paper)
    ax = axs[0]
    for c, N in zip(cols, Ns):
        S, _ = avs[N].uncensored()
        x, p = log_bin(S * np.sqrt(N), a=1.3)
        dots(ax, x, p, color=c, size=10, label_=f"$N={N}$")
    a = res[Nmax]
    xs = np.array([a["s_min"], a["s_max"]]) * np.sqrt(Nmax)
    S, _ = avs[Nmax].uncensored()
    x, p = log_bin(S * np.sqrt(Nmax), a=1.3)
    y0 = np.interp(np.log(xs[0]), np.log(x), p)
    powerlaw_guide(ax, xs[0], xs[1], a["tau_s"], y0, label_=f"MLE $\\tau_s$={a['tau_s']:.3f} (N={Nmax})")
    powerlaw_guide(ax, xs[0], xs[1], BE["tau_s"], y0 * 3, color=RED, label_="theory 4/3")
    ax.set_xscale("log"); ax.set_yscale("log")
    label(ax, r"$\sqrt{N}\,s$", r"$P(s)$", "(a) avalanche sizes")
    ax.legend(fontsize=7)
    # (b) durations + Sparre-Andersen prediction (no free parameter)
    ax = axs[1]
    for c, N in zip(cols, Ns):
        _, T = avs[N].uncensored()
        x, p = log_bin(T, a=1.3, discrete=True)
        p = p * (T.size / avs[N].S.size)          # normalise by all valid avalanches
        dots(ax, x, p, color=c, size=10, label_=f"$N={N}$")
    n = np.unique(np.logspace(0, np.log10(L), 200).astype(int))
    ax.plot(n, sparre_andersen_pmf(n), "-", color=FIT_COLOR, lw=1.2,
            label="Sparre Andersen (exact, no fit)")
    ax.set_xscale("log"); ax.set_yscale("log")
    label(ax, r"$T$", r"$P(T)$", r"(b) durations, $\tau_t$")
    ax.legend(fontsize=7)
    # (c) <s>_T
    ax = axs[2]
    for c, N in zip(cols, Ns):
        sd = res[N]["_sd"]
        m = sd["meanS"] > 0
        sel = np.unique(np.logspace(0, np.log10(sd["T"].size - 1), 70).astype(int))
        dots(ax, sd["T"][sel], sd["meanS"][sel], color=c, size=8, label_=f"$N={N}$")
    sd = res[Nmax]["_sd"]
    fr = dict(slope=sd["slope"], intercept=sd["intercept"], x=sd["T"][sd["sel"]], stderr=sd["stderr"])
    fit_line(ax, fr, label_=f"WLS $D/z$={sd['slope']:.3f} (N={Nmax})")
    TT = np.logspace(0, np.log10(L), 50)
    ax.plot(TT, excursion_mean_size(TT, cfg["q0"], Nmax, cfg["activation"]), ":", color=RED,
            label=r"Brownian excursion, $T^{3/2}$ (no fit)")
    ax.set_xscale("log"); ax.set_yscale("log")
    label(ax, r"$T$", r"$\langle s\rangle_T$", r"(c) size vs duration, $D/z$")
    ax.legend(fontsize=7)
    # (d, e) finite-size extrapolation of the exponents
    for ax, key, th, name in ((axs[3], "tau_s", BE["tau_s"], r"$\tau_s$"), (axs[4], "tau_t", BE["tau_t"], r"$\tau_t$")):
        v = np.array([res[N][key] for N in Ns]); e = np.array([res[N][key + "_err"] for N in Ns])
        for c, N, vi, ei in zip(cols, Ns, v, e):
            ax.errorbar(N, vi, yerr=ei, fmt="o", color=c, ms=6, mec=FIT_COLOR, mew=0.5)
        fe = fss_extrapolate(Ns, v, e)
        res[key + "_inf"] = {k: fe[k] for k in ("tau_inf", "tau_inf_err", "omega")} if "omega" in fe else fe
        if fe.get("model"):
            NN = np.logspace(np.log10(min(Ns)), np.log10(max(Ns) * 3), 60)
            ax.plot(NN, fe["model"](NN), "--", color=FIT_COLOR,
                    label=f"$\\tau(N)=\\tau_\\infty+cN^{{-\\omega}}$: {fe['tau_inf']:.3f} ± {fe['tau_inf_err']:.2g}")
        ax.axhline(th, color=RED, lw=1, ls=":", label=f"theory {th:.4g}")
        if key == "tau_t":
            ax.axhline(res[Nmax]["tau_t_SA"], color=ORANGE, lw=1, ls="-.",
                       label=f"exact law, same fit window: {res[Nmax]['tau_t_SA']:.3f}")
        ax.set_xscale("log")
        label(ax, r"$N$", name, f"({'d' if key == 'tau_s' else 'e'}) finite-size extrapolation")
        ax.legend(fontsize=7)
    # (f) shape collapse (largest N) + semicircle
    ax = axs[5]
    av = avs[Nmax]
    Ts, u, shapes = mean_shapes(av.profile_sums, av.profile_counts, *cfg["shape_T"], min_count=30)
    sc = shape_collapse(Ts, shapes) if Ts.size > 3 else dict(gamma=np.nan, err=np.nan, grid=[], nmse=[])
    res["shape_gamma"], res["shape_gamma_err"] = sc["gamma"], sc["err"]
    if Ts.size > 3:
        cm = LinearSegmentedColormap.from_list("t", [LIGHT_BLUE, DEEP_BLUE])
        for k, (Tv, sh) in enumerate(zip(Ts, shapes)):
            ax.plot(u, sh / Tv ** (sc["gamma"] - 1), "-", color=cm(k / max(len(Ts) - 1, 1)), lw=0.8, alpha=0.7)
        mean = (shapes / Ts[:, None] ** (sc["gamma"] - 1)).mean(0)
        amp = np.sum(mean * excursion_mean_shape(u)) / np.sum(excursion_mean_shape(u) ** 2)
        ax.plot(u, amp * excursion_mean_shape(u), "--", color=RED, lw=1.5, label=r"$\propto\sqrt{u(1-u)}$ (excursion)")
        ax.plot([], [], color=BLUE, label=f"$T\\in[{Ts.min()},{Ts.max()}]$, $\\gamma^*$={sc['gamma']:.3f}")
    label(ax, r"$u=\ell/T$", r"$\bar V_T(u)/T^{\gamma^*-1}$", f"(f) shape collapse, N={Nmax}")
    ax.legend(fontsize=7)
    # (g) NMSE(gamma)
    ax = axs[6]
    if Ts.size > 3:
        dots(ax, sc["grid"][::10], sc["nmse"][::10], color=BLUE, size=8, label_="NMSE")
        ax.axvline(sc["gamma"], color=FIT_COLOR, ls="--", lw=1, label=f"$\\gamma^*$={sc['gamma']:.3f} ± {sc['err']:.2g}")
        ax.axvline(1.5, color=RED, ls=":", lw=1, label="theory 3/2")
        ax.set_yscale("log")
    label(ax, r"$\gamma$", r"NMSE", "(g) collapse quality")
    ax.legend(fontsize=7)
    # (h) finite-N critical point: theory vs the paper's empirical offsets
    ax = axs[7]
    NN = np.array(sorted(set(list(PAPER_OFFSETS) + list(Ns))))
    dots(ax, NN, [sigma_c2_finite_N(cfg["activation"], int(n)) - 1 for n in NN], color=BLUE,
         label_=r"theory $\sigma_c^2(N)-1$ (eq. W4)")
    dots(ax, list(PAPER_OFFSETS), list(PAPER_OFFSETS.values()), color=RED, label_="paper's empirical offsets")
    ax.plot(NN, 1.0 / NN, ":", color=FIT_COLOR, lw=1, label="$1/N$")
    ax.set_xscale("log"); ax.set_yscale("log")
    label(ax, r"$N$", r"$\delta\sigma_w^2$", "(h) finite-N critical point")
    ax.legend(fontsize=7)
    fig.suptitle(f"Avalanches in Gaussian networks, L={L}, $\\phi$={cfg['activation']} (paper Fig. 2) "
                 f"-- engine: {cfg['engine']}")
    fig.tight_layout()
    run.fig(fig, "avalanches_fig2")

    rows = ["", "### Avalanche exponents (paper Fig. 2)", "",
            "| N | σ_w² | τ_s | τ_t | τ_t (Sparre Andersen, same window) | D/z (=γ paper, all T) | D/z (T ≤ N/4) | D/z (T ≤ N/4, corrected) | (τ_t−1)/(τ_s−1) | censored |",
            "|---|---|---|---|---|---|---|---|---|---|"]
    for N in Ns:
        a = res[N]
        rows.append(f"| {N} | {a['sigma_w2']:.5f} | {fmt(a['tau_s'], a['tau_s_err'], 3)} | {fmt(a['tau_t'], a['tau_t_err'], 3)} | "
                    f"{a['tau_t_SA']:.3f} | {fmt(a['D_over_z'], a['D_over_z_err'], 3)} | "
                    f"{fmt(a.get('D_over_z_small'), a.get('D_over_z_small_err'), 3)} | {fmt(a['D_over_z_corr'], a['D_over_z_corr_err'], 3)} | "
                    f"{a['crackling_prediction']:.3f} | {a['frac_censored']:.3f} |")
    for key in ("tau_s_inf", "tau_t_inf"):
        v = res.get(key, {})
        rows.append(f"\n{key}: {fmt(v.get('tau_inf'), v.get('tau_inf_err'), 3)}  (Brownian excursion: "
                    f"{BE['tau_s'] if key == 'tau_s_inf' else BE['tau_t']:.4g})")
    rows.append(f"shape-collapse γ* (N={Nmax}) = {fmt(res['shape_gamma'], res['shape_gamma_err'], 3)}  (theory 3/2)")
    run.note("\n".join(rows))
    clean = {str(k): ({kk: vv for kk, vv in v.items() if not kk.startswith("_")} if isinstance(v, dict) else v)
             for k, v in res.items()}
    run.record("avalanches", clean)
    return res, avs


# ======================================================================
# Paper Fig. 3 (d, e): mean avalanche size and its sigma_w-susceptibility
# ======================================================================
SUSC_DEFAULTS = dict(
    activation="tanh", N=300, L=400, q0=0.01, init="gaussian", init_extra={},
    sw2_range=[0.9, 1.44], n_sw2=28,
    log10_sb2=[None, -8.0, -6.8, -5.6, -4.4, -4.0, -3.2, -2.8, -2.2],
    n_perturbations=200, perturbations_per_network=100, engine="full",
    size_exponent=1.0, dtype="float32", device="auto", seed=0, cache_weights_gb=1.5,
)


def _mf_avalanche_size(mf, sw2, sb2, q0, N, L, a):
    """Deterministic (MF) avalanche: q_l from the MF map started at qhat_0 = q0/N (guide curve)."""
    th = np.sqrt(q0 / N)
    q = mf.trajectory(q0 / N, L, sw2, sb2, use_grid=True)[1:]
    above = np.sqrt(q) >= th
    T = L if above.all() else int(np.argmin(above))
    return N ** a * np.sum(np.sqrt(q[:T]) - th)


def exp_avalanche_susceptibility(run: Run, cfg=None):
    cfg = merge(SUSC_DEFAULTS, cfg)
    sw2 = np.linspace(*cfg["sw2_range"], cfg["n_sw2"])
    lg = cfg["log10_sb2"]
    Sbar = np.full((len(lg), sw2.size), np.nan)
    Smf = np.full_like(Sbar, np.nan)
    mf = MeanField(cfg["activation"])
    t0 = time.time()
    for i, l in enumerate(lg):
        sb2 = 0.0 if l is None else 10.0 ** l
        for j, s in enumerate(sw2):
            init = Initializer.from_sigma(cfg["init"], s, sb2, **cfg["init_extra"])
            sc = SimConfig(N=cfg["N"], L=cfg["L"], activation=cfg["activation"], init=init, q0=cfg["q0"],
                           engine=cfg["engine"], perturbations_per_network=cfg["perturbations_per_network"],
                           size_exponent=cfg["size_exponent"], dtype=cfg["dtype"], device=cfg["device"],
                           seed=cfg["seed"], cache_weights_gb=cfg["cache_weights_gb"])
            # the full engine re-uses cached standardized weights across the whole sweep
            # (common random numbers -> smooth numerical derivative dS/dsigma_w^2)
            av = run_avalanches(sc, n_perturbations=cfg["n_perturbations"])
            Sbar[i, j] = av.mean_size_all
            Smf[i, j] = _mf_avalanche_size(mf, s, sb2, cfg["q0"], cfg["N"], cfg["L"], cfg["size_exponent"])
        print(f"  sigma_b^2 row {i + 1}/{len(lg)} done ({time.time() - t0:.0f}s)")
    chi = np.gradient(Sbar, sw2, axis=1)
    chi_mf = np.gradient(Smf, sw2, axis=1)

    from .mean_field import _sb2_colors
    cols = _sb2_colors(len(lg))
    fig, axs = plt.subplots(1, 3, figsize=(16, 4.5))
    for c, l, S, Sm, ch in zip(cols, lg, Sbar, Smf, chi):
        lab = r"$\sigma_b^2=0$" if l is None else f"$\\log_{{10}}\\sigma_b^2={l}$"
        axs[0].plot(sw2, S, "-", color=c, lw=0.6, alpha=0.5)
        dots(axs[0], sw2, S, color=c, size=14, label_=lab)
        axs[1].plot(sw2, ch, "-", color=c, lw=0.6, alpha=0.5)
        dots(axs[1], sw2, ch, color=c, size=14, label_=lab)
    axs[0].plot(sw2, Smf[0], "--", color=FIT_COLOR, lw=1, label=r"MF, $\sigma_b^2=0$")
    label(axs[0], r"$\sigma_w^2$", r"$\bar S$", f"(d) mean avalanche size, N={cfg['N']}, L={cfg['L']}")
    label(axs[1], r"$\sigma_w^2$", r"$\chi_{\sigma_w^2}=d\bar S/d\sigma_w^2$", "(e) avalanche susceptibility")
    axs[0].legend(fontsize=7)
    # heat map over the grid (rows: sigma_b^2 > 0 only, log axis)
    ax = axs[2]
    rows = [i for i, l in enumerate(lg) if l is not None]
    yb = np.array([10.0 ** lg[i] for i in rows])
    Z = chi[rows]
    heatmap(ax, sw2, yb, np.where(Z > 0, Z, np.nan), cmap=CMAP_WARM, norm=LogNorm(), cbar_label=r"$\chi_{\sigma_w^2}$")
    hw = np.logspace(np.log10(yb.min()), np.log10(yb.max()), 12)
    swW, _ = mf.widom_line(hw, np.concatenate([np.linspace(0.999, 1, 3), 1 + np.logspace(-8, 0, 600)]))
    ax.scatter(swW, hw, s=12, color=DEEP_BLUE, label="MF Widom-like line")
    label(ax, r"$\sigma_w^2$", r"$\sigma_b^2$", "(f) empirical quasi-critical ridge")
    ax.legend(fontsize=8, loc="lower right")
    if cfg["init"] != "gaussian":
        from .mean_field import _native_axes
        _native_axes(ax, cfg["init"])
    fig.suptitle(f"Avalanche susceptibility (paper Fig. 3 d-e), init = {cfg['init']}, engine = {cfg['engine']}")
    fig.tight_layout()
    run.fig(fig, f"avalanche_susceptibility_{cfg['init']}")
    out = dict(sw2=sw2, log10_sb2=[str(x) for x in lg], Sbar=Sbar, chi=chi,
               peak_sw2=[float(sw2[np.nanargmax(c)]) for c in chi], seconds=time.time() - t0)
    run.note(f"\n### Avalanche susceptibility ({cfg['init']}): peak σ_w² per σ_b² row: "
             + ", ".join(f"{l}: {p:.3f}" for l, p in zip(lg, out["peak_sw2"])))
    run.record(f"avalanche_susceptibility_{cfg['init']}", out)
    return out


# ======================================================================
# Finite-size scaling in the depth L (Christensen & Moloney secs. 1.8, 3.5-3.7)
# ======================================================================
DEPTH_FSS_DEFAULTS = dict(activation="tanh", N=1000000, Ls=[64, 128, 256, 512, 1024, 2048], q0=0.01,
                          n_avalanches=200000, engine="linear", ks=[1.5, 2.0, 2.5, 3.0, 3.5, 4.0],
                          moment_fit_last=4, seed=0)


def exp_depth_fss(run: Run, cfg=None):
    cfg = merge(DEPTH_FSS_DEFAULTS, cfg)
    N = cfg["N"]
    sw2 = sigma_c2_finite_N(cfg["activation"], N)
    samples_s, samples_T = {}, {}
    for L in cfg["Ls"]:
        sc = SimConfig(N=N, L=L, activation=cfg["activation"], init=Initializer.from_sigma("gaussian", sw2),
                       q0=cfg["q0"], engine=cfg["engine"], batch_size=50000, seed=cfg["seed"])
        av = run_avalanches(sc, n_avalanches=cfg["n_avalanches"])
        samples_s[L], samples_T[L] = av.S, av.T.astype(float)   # censored avalanches included (cut by L)
    # fit the moments over the largest depths only (corrections to scaling decay with L)
    ms = moment_analysis(samples_s, cfg["ks"], n_last=cfg["moment_fit_last"])
    mt = moment_analysis(samples_T, cfg["ks"], n_last=cfg["moment_fit_last"])
    cols = _width_colors(len(cfg["Ls"]))
    fig, axs = plt.subplots(2, 3, figsize=(15, 8.4))
    axs = axs.ravel()
    for c, L in zip(cols, cfg["Ls"]):
        x, p = log_bin(samples_s[L], a=1.3)
        dots(axs[0], x, p, color=c, size=10, label_=f"$L={L}$")
        dots(axs[1], x / L ** ms["D"], p * x ** ms["tau_s"], color=c, size=10, label_=f"$L={L}$")
        xt, pt = log_bin(samples_T[L], a=1.3, discrete=True)
        dots(axs[4], xt / L ** mt["D"], pt * xt ** mt["tau_s"], color=c, size=10, label_=f"$L={L}$")
    for ax in (axs[0], axs[1], axs[4]):
        ax.set_xscale("log"); ax.set_yscale("log"); ax.legend(fontsize=7)
    label(axs[0], r"$s$", r"$P(s;L)$", "(a) size distributions vs depth L")
    label(axs[1], r"$s/L^{D}$", r"$s^{\tau_s}P(s;L)$", f"(b) FSS collapse: D={ms['D']:.3f}, $\\tau_s$={ms['tau_s']:.3f}")
    label(axs[4], r"$T/L^{z}$", r"$T^{\tau_t}P(T;L)$", f"(e) FSS collapse: z={mt['D']:.3f}, $\\tau_t$={mt['tau_s']:.3f}")
    ax = axs[2]
    for k, (kk, row) in enumerate(zip(ms["ks"], ms["moments"])):
        c = PALETTE[k % len(PALETTE)]
        fr = loglog_fit(ms["Ls"], row)
        dots(ax, ms["Ls"], row, color=c, label_=f"$k={kk:g}$")
        fit_line(ax, fr, color=c, label_=None, lw=0.8)
    ax.set_xscale("log"); ax.set_yscale("log")
    label(ax, r"$L$", r"$\langle s^k\rangle$", "(c) moment analysis")
    ax.legend(fontsize=7)
    for ax, m, nm, th_D, th_tau, title in ((axs[3], ms, "s", BE["D_depth"], BE["tau_s"], "(d) sizes"),
                                           (axs[5], mt, "T", BE["z_depth"], BE["tau_t"], "(f) durations")):
        ax.errorbar(m["ks"], m["sigma_k"], yerr=m["sigma_k_err"], fmt="o", color=BLUE, mec=FIT_COLOR, mew=0.5)
        kk = np.linspace(0, max(m["ks"]) + 0.5, 20)
        ax.plot(kk, m["D"] * kk + m["intercept"], "--", color=FIT_COLOR,
                label=f"fit: slope {m['D']:.3f} ± {m['D_err']:.2g}, $\\tau$={m['tau_s']:.3f}")
        ax.plot(kk, th_D * (1 + kk - th_tau), ":", color=RED, label=f"theory: slope {th_D:g}, $\\tau$={th_tau:.4g}")
        label(ax, r"$k$", r"$\sigma_k$", f"{title}: $\\sigma_k = D(1+k-\\tau)$")
        ax.legend(fontsize=7)
    fig.suptitle(f"Finite-size scaling in depth (N={N} ≫ L, $\\sigma_w^2=\\sigma_c^2(N)$, engine={cfg['engine']})")
    fig.tight_layout()
    run.fig(fig, "depth_fss")
    out = dict(D=ms["D"], D_err=ms["D_err"], tau_s=ms["tau_s"], z=mt["D"], z_err=mt["D_err"], tau_t=mt["tau_s"],
               sigma_k_s=ms["sigma_k"], sigma_k_T=mt["sigma_k"])
    run.note(f"\n### Depth FSS / moment analysis (N={N}): D = {fmt(ms['D'], ms['D_err'], 3)} (theory 3/2), "
             f"τ_s = {ms['tau_s']:.3f} (4/3); z = {fmt(mt['D'], mt['D_err'], 3)} (1), τ_t = {mt['tau_s']:.3f} (3/2)")
    run.record("depth_fss", out)
    return out


# ======================================================================
# Initialisation survey
# ======================================================================
INIT_SURVEY_DEFAULTS = dict(
    activation="tanh", N=100, L=400, q0=0.01,
    schemes=["gaussian", "uniform", "xavier_normal", "xavier_uniform", "kaiming_normal", "kaiming_uniform",
             "lecun_normal", "truncated_normal", "orthogonal", "sparse"],
    extra={"sparse": {"k": 10}, "truncated_normal": {"cut": 2.0}},
    lyap_networks=120, n_perturbations=20000, perturbations_per_network=250, T_min=5, seed=0, dtype="float32",
    device="auto",
)


def exp_initializer_survey(run: Run, cfg=None):
    cfg = merge(INIT_SURVEY_DEFAULTS, cfg)
    N, L = cfg["N"], cfg["L"]
    out = {}
    fig, axs = plt.subplots(1, 3, figsize=(16, 4.6))
    n = np.unique(np.logspace(0, np.log10(L), 150).astype(int))
    axs[0].plot(n, sparre_andersen_pmf(n), "-", color=FIT_COLOR, lw=1.2, label="Sparre Andersen")
    # colour = shape family of the weight distribution, marker = member of the family
    fam = {"gaussian": BLUE, "xavier_normal": BLUE, "kaiming_normal": BLUE, "lecun_normal": BLUE,
           "uniform": ORANGE, "xavier_uniform": ORANGE, "kaiming_uniform": ORANGE, "pytorch_default": ORANGE,
           "truncated_normal": RED, "sparse": DEEP_RED, "orthogonal": DEEP_BLUE}
    markers = {}
    for sch in cfg["schemes"]:
        same = [s_ for s_ in cfg["schemes"] if fam.get(s_) == fam.get(sch)]
        markers[sch] = "osD^v"[same.index(sch) % 5]
    for k, sch in enumerate(cfg["schemes"]):
        extra = cfg["extra"].get(sch, {})
        ref = Initializer.from_sigma(sch, 1.0, 0.0, **extra)
        kap = ref.kurtosis_w(N)
        # 1) finite-N critical point from the Lyapunov exponent (tiny signal)
        scl = SimConfig(N=N, L=40, activation=cfg["activation"], init=ref, q0=1e-8 * N, engine="full",
                        dtype="float64", device="cpu", seed=cfg["seed"] + 7 * k)   # independent replicas
        lam, lam_err, sc2, sc2_err = lyapunov_exponent(scl, n_networks=cfg["lyap_networks"], B=8, L=40)
        theory = 1.0 if sch == "orthogonal" else sigma_c2_finite_N(cfg["activation"], N, kappa_w=kap)
        # 2) avalanches at the measured critical point
        sca = SimConfig(N=N, L=L, activation=cfg["activation"], init=Initializer.from_sigma(sch, sc2, 0.0, **extra),
                        q0=cfg["q0"], engine="full", perturbations_per_network=cfg["perturbations_per_network"],
                        dtype=cfg["dtype"], device=cfg["device"], seed=cfg["seed"] + 7 * k)
        av = run_avalanches(sca, n_perturbations=cfg["n_perturbations"])
        frac_valid = av.S.size / av.n_perturbations
        entry = dict(sigma_w2_native=ref.describe(), kappa_w=kap, lyapunov=lam, lyapunov_err=lam_err,
                     sigma_c2=sc2, sigma_c2_err=sc2_err, sigma_c2_theory=theory, frac_valid=frac_valid,
                     frac_censored=float(av.censored.mean()) if av.S.size else np.nan)
        if av.S.size > 500 and (~av.censored).sum() > 200:
            a = analyze(av, L, T_min=cfg["T_min"], N=N)
            entry.update(tau_t=a["tau_t"], tau_t_err=a["tau_t_err"], tau_t_SA=a["tau_t_SA"],
                         tau_s=a["tau_s"], tau_s_err=a["tau_s_err"],
                         D_over_z=a["D_over_z"], D_over_z_err=a["D_over_z_err"],
                         D_over_z_small=a.get("D_over_z_small", np.nan),
                         D_over_z_small_err=a.get("D_over_z_small_err", np.nan))
            _, T = av.uncensored()
            x, p = log_bin(T, a=1.35, discrete=True)
            dots(axs[0], x, p * T.size / av.S.size, color=fam.get(sch, BLUE), size=14, label_=sch,
                 marker=markers[sch])
        out[sch] = entry
        c = fam.get(sch, BLUE)
        axs[1].errorbar(k, sc2 - 1, yerr=sc2_err, fmt=markers[sch], color=c, mec=FIT_COLOR, mew=0.5)
        axs[1].scatter(k, theory - 1, marker="_", s=300, color=FIT_COLOR, zorder=5)
        if "tau_t" in entry:
            axs[2].errorbar(k, entry["tau_t"] - entry["tau_t_SA"], yerr=entry["tau_t_err"], fmt="o", color=BLUE,
                            mec=FIT_COLOR, mew=0.5)
            axs[2].errorbar(k, entry["frac_valid"] - valid_fraction_exact(cfg["activation"], N, sc2),
                            yerr=np.sqrt(0.25 / cfg["n_perturbations"]), fmt="s",
                            color=RED, mec=FIT_COLOR, mew=0.5)
        print(f"  {sch:17s} kappa={kap:6.2f}  sigma_c^2={sc2:.5f}±{sc2_err:.1e} (theory {theory:.5f})  "
              f"valid={frac_valid:.3f}  tau_t={entry.get('tau_t', np.nan):.3f}  D/z={entry.get('D_over_z', np.nan):.3f}")
    axs[0].set_xscale("log"); axs[0].set_yscale("log")
    label(axs[0], r"$T$", r"$P(T)$", f"(a) durations at $\\sigma_c^2(N)$, N={N}")
    axs[0].legend(fontsize=6.5, ncol=2)
    axs[1].set_xticks(range(len(cfg["schemes"])))
    axs[1].set_xticklabels(cfg["schemes"], rotation=60, ha="right", fontsize=8)
    axs[1].scatter([], [], marker="_", s=200, color=FIT_COLOR, label="theory (W4, W7)")
    axs[1].scatter([], [], color=BLUE, label="measured (Lyapunov)")
    label(axs[1], "", r"$\sigma_c^2(N)-1$", "(b) finite-N critical point")
    axs[1].legend(fontsize=8)
    axs[2].axhline(0.0, color=FIT_COLOR, ls=":", lw=1, label="Brownian-excursion prediction")
    axs[2].scatter([], [], color=BLUE, label=r"$\tau_t-\tau_t^{\rm SA}$ (exact law, same window)")
    axs[2].scatter([], [], color=RED, marker="s", label=r"$P(T\geq1)-P(\chi^2_N\geq N/\sigma_w^2)$ (exact)")
    axs[2].set_xticks(range(len(cfg["schemes"])))
    axs[2].set_xticklabels(cfg["schemes"], rotation=60, ha="right", fontsize=8)
    label(axs[2], "", r"$\Delta$exponent", "(c) deviation from the Brownian-excursion class")
    axs[2].legend(fontsize=8)
    fig.suptitle(f"Initialisation survey ($\\phi$={cfg['activation']}, N={N}, L={L})")
    fig.tight_layout()
    run.fig(fig, "initializer_survey")
    rows = ["", "### Initialisation survey", "",
            "| scheme | κ_w | σ_c²(N) measured | σ_c²(N) theory | valid frac. (exact: P(χ²_N ≥ N/σ_w²)) | τ_t | τ_t exact law, same window | D/z (all T) | D/z (T ≤ N/4) |",
            "|---|---|---|---|---|---|---|---|---|"]
    for sch, e in out.items():
        rows.append(f"| {sch} | {e['kappa_w']:.3g} | {fmt(e['sigma_c2'], e['sigma_c2_err'], 5)} | {e['sigma_c2_theory']:.5f} | "
                    f"{e['frac_valid']:.3f} ({valid_fraction_exact(cfg['activation'], N, e['sigma_c2']):.3f}) | {fmt(e.get('tau_t'), e.get('tau_t_err'), 3)} | {fmt(e.get('tau_t_SA'), None, 3)} | "
                    f"{fmt(e.get('D_over_z'), e.get('D_over_z_err'), 3)} | {fmt(e.get('D_over_z_small'), e.get('D_over_z_small_err'), 3)} |")
    run.note("\n".join(rows))
    # where does each scheme's *library default* land in the MF phase diagram?
    rows = ["", "### Library-default initialisations in the MF phase diagram (σ_b² = 0)", "",
            "| scheme (default params) | σ_w² | tanh: t | tanh: phase | tanh: ζ_c | relu: σ_w²/2 − 1 |", "|---|---|---|---|---|---|"]
    mf = MeanField("tanh")
    defaults = {}
    for sch in list(WEIGHT_SCHEMES):
        ini = Initializer(sch, dict(cfg["extra"].get(sch, {})))
        s2 = ini.sigma_w2()
        R = mf.response(np.array([s2]), 0.0)
        c1 = R["chi1"][0]
        phase = "critical" if abs(c1 - 1) < 1e-6 else ("ordered" if c1 < 1 else "chaotic")
        zc = float(R["zeta_c"][0]) if phase == "ordered" else np.inf
        defaults[sch] = dict(sigma_w2=s2, t_tanh=s2 - 1, phase_tanh=phase, zeta_c=zc)
        wp = {k: round(float(v), 4) for k, v in ini.weight_params.items()}
        rows.append(f"| {sch} {wp} | {s2:.4f} | {s2 - 1:+.3f} | {phase} | "
                    f"{zc:.3g} | {s2 / 2 - 1:+.3f} |")
    run.note("\n".join(rows))
    out["_library_defaults"] = defaults
    run.record("initializer_survey", out)
    return out


# ======================================================================
# Finite-N quasi-critical landscape: simulation vs Fokker-Planck theory vs MF
# ======================================================================
FINITE_N_DEFAULTS = dict(activation="tanh", Ns=[50, 300], sw2_range=[0.9, 1.3], n_sw2=17,
                         log10_sb2=[None, -5.0, -4.0, -3.0], B=128, L_burn=700, L_meas=700,
                         theory_Ns=[50, 300, 2000], widom_log10_h=[-7, -2.5], seed=0, device="auto")


def exp_finite_n_widom(run: Run, cfg=None):
    cfg = merge(FINITE_N_DEFAULTS, cfg)
    act = cfg["activation"]
    mf = MeanField(act)
    sw2 = np.linspace(*cfg["sw2_range"], cfg["n_sw2"])
    sw2_fine = np.linspace(*cfg["sw2_range"], 300)
    from .mean_field import _sb2_colors
    cols = _sb2_colors(len(cfg["log10_sb2"]))
    fig, axs = plt.subplots(1, len(cfg["Ns"]) + 2, figsize=(5 * (len(cfg["Ns"]) + 2), 4.3))
    out = {}
    for a_i, N in enumerate(cfg["Ns"]):
        ax = axs[a_i]
        for c, l in zip(cols, cfg["log10_sb2"]):
            sb2 = 0.0 if l is None else 10.0 ** l
            sim = []
            for s in sw2:
                sc = SimConfig(N=N, activation=act, init=Initializer.from_sigma("gaussian", s, sb2), q0=0.01 * N,
                               engine="markov", seed=cfg["seed"], device=cfg["device"])
                sim.append(stationary_signal(sc, cfg["B"], cfg["L_burn"], cfg["L_meas"])[0])
            th = [stationary_moments(s, sb2, N, act)["sqrt_qhat"] for s in sw2_fine]
            mfm = mf.response(sw2_fine, sb2)["m"]
            lab = r"$\sigma_b^2=0$" if l is None else f"$\\log_{{10}}\\sigma_b^2={l}$"
            dots(ax, sw2, sim, color=c, size=16, label_=lab)
            ax.plot(sw2_fine, th, "-", color=c, lw=1.1)
            ax.plot(sw2_fine, mfm, ":", color=c, lw=1.0)
            out[f"N{N}_sb{l}"] = dict(sim=sim)
        ax.plot([], [], "-", color=FIT_COLOR, label="Fokker-Planck (finite N)")
        ax.plot([], [], ":", color=FIT_COLOR, label="mean field")
        label(ax, r"$\sigma_w^2$", r"$\langle\sqrt{\hat q}\rangle$", f"stationary signal, N={N}")
        ax.legend(fontsize=7)
    # finite-N susceptibility and Widom line from the FP theory
    ax, ax2 = axs[-2], axs[-1]
    hs = np.logspace(*cfg["widom_log10_h"], 12)
    wcols = [RED, ORANGE, BLUE, DEEP_BLUE]
    for c, N in zip(wcols, cfg["theory_Ns"]):
        m = np.array([stationary_moments(s, 1e-4, N, act)["sqrt_qhat"] for s in sw2_fine])
        ax.plot(sw2_fine, np.gradient(m, sw2_fine), "-", color=c, lw=1.3, label=f"N={N}")
        peaks = []
        for h in hs:
            mm = np.array([stationary_moments(s, h, N, act)["sqrt_qhat"] for s in sw2_fine])
            peaks.append(sw2_fine[np.argmax(np.gradient(mm, sw2_fine))])
        dots(ax2, hs, np.array(peaks) - 1, color=c, label_=f"N={N}")
    ax.plot(sw2_fine, mf.response(sw2_fine, 1e-4)["chi_t"], ":", color=FIT_COLOR, label="mean field")
    label(ax, r"$\sigma_w^2$", r"$\chi_{\sigma_w^2}$", r"finite-N susceptibility, $\sigma_b^2=10^{-4}$")
    ax.legend(fontsize=7)
    swW, _ = mf.widom_line(hs, np.concatenate([np.linspace(0.999, 1, 3), 1 + np.logspace(-8, 0, 600)]))
    ax2.plot(hs, swW - 1, ":", color=FIT_COLOR, label="mean field")
    ax2.set_xscale("log"); ax2.set_yscale("log")
    label(ax2, r"$\sigma_b^2$", r"$\sigma_{w,W}^2-1$", "finite-N Widom-like line")
    ax2.legend(fontsize=7)
    fig.suptitle(f"Finite-width quasi-criticality ($\\phi$={act}): dots = simulation, lines = theory")
    fig.tight_layout()
    run.fig(fig, "finite_n_widom")
    run.record("finite_n_widom", out)
    run.note("\n### Finite-N landscape: see figures/finite_n_widom (simulation vs Fokker-Planck vs MF)")
    return out
