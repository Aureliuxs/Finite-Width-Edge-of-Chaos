"""
make_theory_figures.py -- every figure of the theory document "Signal Propagation, Criticality and
Avalanches in Deep Networks at Initialisation".

Run from anywhere:   python derivations/theory/make_theory_figures.py            (all figures, ~4 min)
                     python derivations/theory/make_theory_figures.py corr aval  (selected figures)

Style: lines = analytic results; circular dots = numbers computed from the exact map or from simulations.
"""
import os
import sys
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap, ListedColormap, LogNorm, TwoSlopeNorm  # noqa: E402
from scipy.integrate import quad  # noqa: E402
from scipy.special import digamma, gammaln  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = HERE                      # legacy/qcdl lives next to this script
sys.path.insert(0, ROOT)
from qcdl.activations import get_activation  # noqa: E402
from qcdl.finite_n import _fp_grid, log_growth_stats, sigma_c2_finite_N  # noqa: E402
from qcdl.flow_plots import (DECAY, GROW, SPECS, STABLE, UNSTABLE, FlowSpec, activation_figure,  # noqa: E402
                             class_shapes_figure, panel_flow)
from qcdl.meanfield import MeanField  # noqa: E402
from qcdl.plotting import (BLUE, DEEP_BLUE, DEEP_ORANGE, DEEP_RED, FIT_COLOR, INK, LIGHT_BLUE, ORANGE, RED,  # noqa: E402
                           apply_style, dots, label)

OUT = os.path.join(HERE, "figures")
os.makedirs(OUT, exist_ok=True)
apply_style(10.5)
RNG = np.random.default_rng(20260929)


def save(fig, stem):
    fig.savefig(os.path.join(OUT, stem + ".pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(OUT, stem + ".png"), dpi=140, bbox_inches="tight")
    plt.close(fig)
    print(f"saved {stem}", flush=True)


def guide(ax, x0, x1, slope, y0, text, ls="--", color=FIT_COLOR):
    """Reference power law y = y0 (x/x0)^slope."""
    x = np.array([x0, x1])
    ax.plot(x, y0 * (x / x0) ** slope, ls, color=color, lw=1.1, label=text)


def logbin_pdf(x, n_bins=30, xmin=None, xmax=None):
    x = np.asarray(x, float)
    x = x[x > 0]
    lo = xmin or x.min()
    hi = xmax or x.max()
    edges = np.logspace(np.log10(lo), np.log10(hi * 1.0001), n_bins + 1)
    h, _ = np.histogram(x, edges)
    w = np.diff(edges)
    c = np.sqrt(edges[1:] * edges[:-1])
    p = h / (w * x.size)
    ok = h > 3
    return c[ok], p[ok]


# =====================================================================================
# 1. Reading the map: cobweb and depth profiles (tanh)
# =====================================================================================
def fig_map():
    mf = MeanField("tanh")
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.4))
    q = np.linspace(0, 1.6, 600)
    V = mf.V(q)
    ax[0].plot(q, q, "--", color=FIT_COLOR, lw=1.1, label="$F(q)=q$ (diagonal)")
    cases = [(0.7, BLUE, 1.4), (1.0, INK, 1.4), (1.6, RED, 0.05)]
    for sw2, col, q0 in cases:
        ax[0].plot(q, sw2 * V, "-", color=col, lw=1.7, label=f"$F(q)$, $\\sigma_w^2={sw2:g}$")
        traj = [q0]
        for _ in range(30):
            traj.append(sw2 * float(mf.V(np.array([traj[-1]]))[0]))
        path = np.repeat(np.array(traj), 2)
        ax[0].plot(path[:-1], np.concatenate([[0.0], path[2:]]), "-", color=col, lw=0.6, alpha=0.7)
    qs = float(mf.fixed_point(1.6, 0.0))
    ax[0].scatter([qs], [qs], s=50, color=STABLE, zorder=6, label="stable fixed point $q^*$")
    ax[0].scatter([0], [0], s=50, facecolors="white", edgecolors=UNSTABLE, zorder=6, lw=1.3,
                  label="$q^*=0$ (unstable for $\\sigma_w^2=1.6$)")
    ax[0].set_xlim(0, 1.6)
    ax[0].set_ylim(0, 1.25)
    label(ax[0], "$q$", "$F(q)$", "(a) the variance map and its cobweb iteration")
    ax[0].legend(fontsize=7.5, loc="upper left")
    for sw2, col, q0 in cases:
        l = np.arange(0, 41)
        qq = [1.0]
        for _ in l[1:]:
            qq.append(sw2 * float(mf.V(np.array([qq[-1]]))[0]))
        dots(ax[1], l, qq, color=col, size=16, label_=f"$\\sigma_w^2={sw2:g}$")
    ax[1].axhline(qs, color=RED, ls=":", lw=1, label=f"$q^*={qs:.3f}$ for $\\sigma_w^2=1.6$")
    label(ax[1], "$\\ell$", "$q_\\ell$", "(b) the same iteration layer by layer ($q_0=1$)")
    ax[1].legend(fontsize=8)
    fig.tight_layout()
    save(fig, "fig_map")


# =====================================================================================
# 2. How V(q) departs from a straight line: the exponent 1 + theta
# =====================================================================================
def fig_small_signal():
    q = np.logspace(-5, 0, 300)
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.4))
    cols = {"tanh": BLUE, "erf": DEEP_BLUE, "elu": RED, "selu": DEEP_RED, "gelu": ORANGE, "hardtanh": INK}
    for name, col in cols.items():
        mf = MeanField(name)
        g = mf.act.germ
        dev = np.abs(g.V1 * q - mf.V(q)) / g.V1
        ok = dev > 1e-300
        dots(ax[0], q[ok][::10], dev[ok][::10], color=col, size=14, label_=name)
        lq = np.log(q)
        slope = np.gradient(np.log(np.maximum(dev, 1e-300)), lq)
        sel = (dev > 1e-13)
        ax[1].plot(q[sel], slope[sel], "-", color=col, lw=1.6, label=name)
    guide(ax[0], 1e-5, 1, 2.0, 2e-10, "slope 2  ($\\vartheta=1$)")
    guide(ax[0], 1e-5, 1, 1.5, 5e-8, "slope 3/2  ($\\vartheta=1/2$)", ls="-.")
    ax[0].set_xscale("log")
    ax[0].set_yscale("log")
    ax[0].set_ylim(1e-12, 3)
    label(ax[0], "$q$", "$|V_1 q-V(q)|/V_1$", "(a) size of the nonlinear correction")
    ax[0].legend(fontsize=7.5, ncol=2, loc="lower right")
    ax[1].axhline(2, color=FIT_COLOR, ls="--", lw=1)
    ax[1].axhline(1.5, color=FIT_COLOR, ls="-.", lw=1)
    ax[1].set_xscale("log")
    ax[1].set_ylim(1, 6)
    label(ax[1], "$q$", "$1+\\vartheta$", "(b) local slope of (a): the exponent $1+\\vartheta$")
    ax[1].legend(fontsize=7.5, loc="upper right")
    fig.tight_layout()
    save(fig, "fig_small_signal")


# =====================================================================================
# 3. Zero bias: flow across t and the stability window
# =====================================================================================
def fig_zero_bias():
    fig, ax = plt.subplots(1, 2, figsize=(11.5, 4.6))
    mf = MeanField("tanh")
    spec = FlowSpec([1.0], (0.4, 2.0), q_log=(1e-4, 10.0))
    panel_flow(ax[0], mf, spec, 0.0, "(a) tanh: flow of $q_0$ through depth, $\\sigma_b^2=0$")
    t = np.linspace(-0.9, 2.5, 400)
    ax[1].axhspan(-1, 1, color=DECAY, alpha=0.6, lw=0)
    ax[1].fill_between([], [], color=DECAY, label="$|F'(q^*)|<1$: stable")
    ax[1].plot(t, 1 + t, "-", color=INK, lw=1.4, label="$q^*=0$:  $F'=1+t$")
    for name, col, th in [("tanh", BLUE, 1.0), ("elu", RED, 0.5)]:
        m = MeanField(name)
        tt = np.linspace(0.01, 2.5, 60)
        sw2 = (1 + tt) / m.act.germ.V1
        r = m.response(sw2, 0.0, q_init=1.0)
        fin = np.isfinite(r["slope"]) & (r["q"] > 1e-12)
        dots(ax[1], tt[fin][::2], r["slope"][fin][::2], color=col, size=14,
             label_=f"{name}, active branch (exact map)")
        ax[1].plot(t[t > 0], 1 - th * t[t > 0], "--", color=col, lw=1.1,
                   label=f"{name}: $F'=1-\\vartheta t$ (small $t$)")
    ax[1].axvline(0, color=INK, ls=":", lw=1)
    ax[1].set_ylim(-1.3, 2.2)
    ax[1].set_xlim(-0.9, 2.5)
    label(ax[1], "$t$", "$F'(q^*)$", "(b) slope of the map at each fixed point")
    ax[1].legend(fontsize=7.2, loc="upper left")
    fig.tight_layout()
    save(fig, "fig_zero_bias")


# =====================================================================================
# 4. Non-zero bias: rounding of the transition and the Widom-like line
# =====================================================================================
def fig_bias():
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.6))
    mf = MeanField("tanh")
    spec = FlowSpec([1.0], (0.4, 2.0), q_log=(1e-4, 10.0))
    panel_flow(ax[0], mf, spec, 1e-3, "(a) tanh: flow of $q_0$, $\\sigma_b^2=10^{-3}$")
    t = np.linspace(-0.4, 0.6, 400)
    cols = [INK, DEEP_BLUE, BLUE, LIGHT_BLUE]
    for sb2, col in zip([0.0, 1e-4, 1e-3, 1e-2], cols):
        r = mf.response(1 + t, sb2, q_init=1.0)
        lab = "$\\sigma_b^2=0$" if sb2 == 0 else f"$\\sigma_b^2=10^{{{int(np.log10(sb2))}}}$"
        ax[1].plot(t, r["q"], "-", color=col, lw=1.6, label=lab)
    ax[1].set_yscale("log")
    ax[1].set_ylim(1e-4, 1)
    label(ax[1], "$t$", "$q^*$", "(b) stationary signal: bias rounds the transition")
    ax[1].legend(fontsize=8, loc="lower right")
    h = np.logspace(-7, -2, 16)
    for name, col, Delta, obs, oname in [("tanh", BLUE, 2.0, "chi_t", "\\chi_w"), ("elu", RED, 3.0, "chi_h", "\\chi_h")]:
        m = MeanField(name)
        sc = m.act.germ.sigma_w2_c
        sw_max, _ = m.widom_line(h, sw2_grid=sc * np.linspace(1.0001, 1.5, 2500), observable=obs)
        tw = sw_max / sc - 1
        ok = np.isfinite(tw)
        dots(ax[2], h[ok], tw[ok], color=col, size=18, label_=f"{name}: ridge of ${oname}$")
        k = ok.nonzero()[0][len(ok.nonzero()[0]) // 2]
        guide(ax[2], h[0], h[-1], 1 / Delta, tw[k] * (h[0] / h[k]) ** (1 / Delta),
              f"slope $1/\\Delta={1 / Delta:.3g}$", color=col)
    ax[2].set_xscale("log")
    ax[2].set_yscale("log")
    label(ax[2], "$\\sigma_b^2$", "$t_W$", "(c) Widom-like line: position of the peak")
    ax[2].legend(fontsize=8, loc="upper left")
    fig.tight_layout()
    save(fig, "fig_bias")


# =====================================================================================
# 5. Critical exponents measured on the exact map (tanh: theta = 1, ELU: theta = 1/2)
# =====================================================================================
def fig_exponents():
    fig, axs = plt.subplots(2, 3, figsize=(16, 9))
    a = axs.ravel()
    tt = np.logspace(-4, -1, 13)
    for name, col, th in [("tanh", BLUE, 1.0), ("elu", RED, 0.5)]:
        m = MeanField(name)
        g = m.act.germ
        V1, c = g.V1, g.c
        sw = lambda t: (1 + t) / V1
        # (a) beta
        qs = np.array([float(m.fixed_point(sw(t), 0.0)) for t in tt])
        dots(a[0], tt, qs, color=col, label_=f"{name} (exact map)")
        a[0].plot(tt, (tt / (sw(tt) * c)) ** (1 / th), "--", color=col, lw=1,
                  label=f"$(t/\\sigma_w^2c)^{{1/\\vartheta}}$, slope $\\beta={1 / th:g}$")
        # (b) delta
        hh = np.logspace(-9, -3, 13)
        qh = np.array([float(m.fixed_point(1 / V1, h)) for h in hh])
        dots(a[1], hh, qh, color=col, label_=f"{name}")
        a[1].plot(hh, (hh / (c / V1)) ** (1 / (1 + th)), "--", color=col, lw=1,
                  label=f"slope $1/\\delta={1 / (1 + th):.3g}$")
        # (c) gamma, both sides
        rp = m.response(sw(tt), 0.0, q_init=1.0)
        dots(a[2], tt, rp["chi_h"], color=col, label_=f"{name}, $t>0$")
        rm = m.response(sw(-tt), 0.0, q=np.zeros_like(tt))
        dots(a[2], tt, rm["chi_h"], color=col, size=22, marker="s", alpha=0.6, label_=f"{name}, $t<0$")
        a[2].plot(tt, 1 / (th * tt), "--", color=col, lw=1, label=f"$1/(\\vartheta t)$")
        # (d) nu
        dots(a[3], tt, rp["xi"], color=col, label_=f"{name}, $t>0$")
        a[3].plot(tt, 1 / (th * tt), "--", color=col, lw=1, label="$1/(\\vartheta t)$")
        # (e) critical decay
        L = 100000
        q = m.trajectory(1.0, L, 1 / V1, 0.0, use_grid=True)
        l = np.unique(np.logspace(0, np.log10(L), 40).astype(int))
        dots(a[4], l, q[l], color=col, label_=name)
        a[4].plot(l[l > 30], (th * c * l[l > 30]) ** (-1 / th), "--", color=col, lw=1,
                  label=f"$(\\vartheta c\\,\\ell/V_1)^{{-1/\\vartheta}}$, slope $-{1 / th:g}$")
        # (f) paper's chi_w
        dots(a[5], tt, rp["chi_t"], color=col, label_=f"{name}")
        ex = 1 / (2 * th) - 1
        a[5].plot(tt, rp["chi_t"][0] * (tt / tt[0]) ** ex, "--", color=col, lw=1,
                  label=f"slope $1/(2\\vartheta)-1={ex:g}$")
    a[2].plot(tt, 1 / tt, ":", color=INK, lw=1, label="$1/|t|$ ($t<0$, both)")
    titles = [("$t$", "$q^*$", "(a) order parameter: $q^*\\propto t^{\\beta}$"),
              ("$\\sigma_b^2$", "$q^*$", "(b) at $t=0$: $q^*\\propto(\\sigma_b^2)^{1/\\delta}$"),
              ("$|t|$", "$\\chi_h$", "(c) susceptibility: $\\chi_h\\propto|t|^{-\\gamma}$"),
              ("$|t|$", "$\\xi$", "(d) depth correlation length: $\\xi\\propto|t|^{-\\nu}$"),
              ("$\\ell$", "$q_\\ell$", "(e) at $t=\\sigma_b^2=0$: slow decay"),
              ("$t$", "$\\chi_w$", "(f) the response $\\chi_w=\\partial\\sqrt{q^*}/\\partial\\sigma_w^2$")]
    for ax, (xl, yl, ti) in zip(a, titles):
        ax.set_xscale("log")
        ax.set_yscale("log")
        label(ax, xl, yl, ti)
        ax.legend(fontsize=7.2)
    fig.tight_layout()
    save(fig, "fig_exponents")


# =====================================================================================
# 6. P(q) versus V'(q) and V(q)/q
# =====================================================================================
def fig_PV():
    fig, ax = plt.subplots(1, 3, figsize=(15, 4.3))
    q = np.linspace(1e-4, 3, 300)
    for a_, name in zip(ax, ["tanh", "elu", "gelu"]):
        m = MeanField(name)
        a_.plot(q, m.P(q), "-", color=RED, lw=1.8, label="$P(q)=\\mathbb{E}[\\phi'(u)^2]$  (sets $\\chi_1$)")
        a_.plot(q, m.dV(q), "-", color=BLUE, lw=1.8, label="$V'(q)$  (sets $F'$)")
        a_.plot(q, m.V(q) / q, "--", color=INK, lw=1.2, label="$V(q)/q$")
        a_.scatter([0], [m.act.germ.V1], s=45, color=ORANGE, zorder=6, clip_on=False,
                   label=f"$V_1={m.act.germ.V1:.3g}$: all three agree at $q=0$")
        a_.set_xlim(0, 3)
        a_.set_ylim(0, None)
        label(a_, "$q$", "", f"({'abc'[['tanh', 'elu', 'gelu'].index(name)]}) {name}")
        a_.legend(fontsize=7.5)
    fig.tight_layout()
    save(fig, "fig_PV")


# =====================================================================================
# 7. Edge of chaos: phase diagram and how it hugs the axis
# =====================================================================================
def fig_eoc():
    fig, ax = plt.subplots(1, 3, figsize=(16.5, 4.8))
    m = MeanField("tanh")
    sw = np.linspace(0.4, 2.5, 220)
    sb = np.logspace(-6, 0, 140)
    W, H = np.meshgrid(sw, sb)
    r = m.response(W, H, q_init=1.0)
    chi = r["chi1"]
    cm = LinearSegmentedColormap.from_list("div", [DEEP_BLUE, "#CFE0F3", "#FFFFFF", "#F8D9B0", DEEP_RED])
    pm = ax[0].pcolormesh(sw, sb, np.log(chi), cmap=cm, norm=TwoSlopeNorm(0, -1.2, 0.6), shading="nearest",
                          rasterized=True)
    cb = plt.colorbar(pm, ax=ax[0], pad=0.02)
    cb.ax.set_title("$\\ln\\chi_1$", fontsize=9, pad=6)
    cb.outline.set_visible(False)
    se, he, qe = m.edge_of_chaos(np.logspace(-6, 1.5, 600))
    ok = (he > 1e-6) & (se < 2.5)
    ax[0].plot(se[ok], he[ok], "--", color=INK, lw=1.4, label="edge of chaos $\\chi_1=1$")
    h = np.logspace(-6, -0.3, 30)
    sw_w, _ = m.widom_line(h, sw2_grid=np.linspace(1.0001, 2.5, 2500))
    okw = np.isfinite(sw_w)
    ax[0].plot(sw_w[okw], h[okw], ":", color=DEEP_ORANGE, lw=1.8, label="Widom-like line (ridge of $\\chi_w$)")
    ax[0].scatter([1.0], [1.1e-6], marker="*", s=170, color=RED, zorder=6, clip_on=False,
                  label="critical point $(1,0)$")
    ax[0].text(0.55, 1e-3, "ordered\n$\\chi_1<1$", color=DEEP_BLUE, fontsize=10)
    ax[0].text(1.9, 3e-5, "chaotic\n$\\chi_1>1$", color=DEEP_RED, fontsize=10)
    ax[0].set_yscale("log")
    label(ax[0], "$\\sigma_w^2$", "$\\sigma_b^2$", "(a) tanh: ordered and chaotic phases")
    ax[0].legend(fontsize=7.5, loc="upper left", frameon=True, framealpha=0.85)
    # (b) sigma_b^2 against t along both lines
    for name, col, th, obs in [("tanh", BLUE, 1.0, "chi_t"), ("elu", RED, 0.5, "chi_h")]:
        mm = MeanField(name)
        se, he, qe = mm.edge_of_chaos(np.logspace(-7, -0.5, 300))
        t_e = se * mm.act.germ.V1 - 1
        ok = (he > 1e-14) & (t_e > 1e-4) & (t_e < 0.5)
        dots(ax[1], t_e[ok][::12], he[ok][::12], color=col, size=16, label_=f"{name}: edge of chaos")
        D = (1 + th) / th
        k = np.argmin(np.abs(t_e[ok] - 0.01))
        ax[1].plot(t_e[ok], he[ok][k] * (t_e[ok] / t_e[ok][k]) ** (D + 1), "--", color=col, lw=1,
                   label=f"slope $\\Delta+1={D + 1:g}$")
        hh = np.logspace(-12, -1, 30)
        sc = mm.act.germ.sigma_w2_c
        sww, _ = mm.widom_line(hh, sw2_grid=sc * np.linspace(1.00001, 1.6, 4000), observable=obs)
        tw = sww / sc - 1
        okw = np.isfinite(tw) & (tw > 1e-4)
        dots(ax[1], tw[okw], hh[okw], color=col, size=22, marker="s", alpha=0.6, label_=f"{name}: Widom-like line")
        kk = okw.nonzero()[0][len(okw.nonzero()[0]) // 2]
        ax[1].plot(tw[okw], hh[kk] * (tw[okw] / tw[kk]) ** D, ":", color=col, lw=1.2, label=f"slope $\\Delta={D:g}$")
    ax[1].set_xscale("log")
    ax[1].set_yscale("log")
    label(ax[1], "$t$", "$\\sigma_b^2$", "(b) both lines leave the critical point tangentially")
    ax[1].legend(fontsize=7, loc="upper left", ncol=2)
    # (c) qP - V versus V1 q - V
    q = np.logspace(-4, 0, 200)
    for name, col, th in [("tanh", BLUE, 1.0), ("elu", RED, 0.5)]:
        mm = MeanField(name)
        V1 = mm.act.germ.V1
        dots(ax[2], q[::10], (q * mm.P(q) - mm.V(q))[::10], color=col, size=16,
             label_=f"{name}: $qP-V$  (slope $1+2\\vartheta={1 + 2 * th:g}$)")
        dots(ax[2], q[::10], (V1 * q - mm.V(q))[::10], color=col, size=22, marker="s", alpha=0.55,
             label_=f"{name}: $V_1q-V$  (slope $1+\\vartheta={1 + th:g}$)")
    ax[2].set_xscale("log")
    ax[2].set_yscale("log")
    label(ax[2], "$q$", "", "(c) why the edge of chaos hugs the axis")
    ax[2].legend(fontsize=7.2, loc="upper left")
    fig.tight_layout()
    save(fig, "fig_eoc")


# =====================================================================================
# 8. Correlation map: its fixed points, critical decay and order parameter
# =====================================================================================
def d2_next(phi, q, d2, sw2, nm=120001):
    """Exact distance map  d'^2 = sigma_w^2 E[(phi(u_a) - phi(u_b))^2]  (midpoint / difference variables)."""
    d = np.sqrt(d2)
    sm = np.sqrt(q - d2 / 4)
    mgrid = np.linspace(-12 * sm, 12 * sm, nm)
    w = np.exp(-mgrid ** 2 / (2 * sm ** 2)) / np.sqrt(2 * np.pi) / sm

    def inner(x):
        D = d * x
        return np.trapezoid((phi(mgrid + D / 2) - phi(mgrid - D / 2)) ** 2 * w, mgrid)
    val = quad(lambda x: inner(x) * 2 * np.exp(-x * x / 2) / np.sqrt(2 * np.pi), 0, 9, limit=200,
               epsabs=1e-16, epsrel=1e-11)[0]
    return sw2 * val


def eoc_point(m, sb2):
    """sigma_w^2 on the edge of chaos for a given sigma_b^2 (bisection) and its q*."""
    lo, hi = 0.2, 4.0
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        q = float(m.fixed_point(mid, sb2))
        if mid * float(m.P(np.array([q]))[0]) < 1:
            lo = mid
        else:
            hi = mid
    sw2 = 0.5 * (lo + hi)
    return sw2, float(m.fixed_point(sw2, sb2))


def fig_corr():
    import warnings
    warnings.filterwarnings("ignore")
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.7))
    m = MeanField("tanh")
    sb2 = 0.05
    c = np.linspace(-0.2, 1.0, 200)
    sw_e, _ = eoc_point(m, sb2)
    for sw2, col, lab in [(1.2, BLUE, "ordered"), (sw_e, INK, "edge of chaos"), (3.0, RED, "chaotic")]:
        q = float(m.fixed_point(sw2, sb2))
        cc = np.array([float(m.cmap(x, q, sw2, sb2)) for x in c])
        ax[0].plot(c, cc, "-", color=col, lw=1.6, label=f"$\\sigma_w^2={sw2:.3g}$ ({lab})")
        # cobweb
        x = [0.0]
        for _ in range(12):
            x.append(float(m.cmap(x[-1], q, sw2, sb2)))
        path = np.repeat(np.array(x), 2)
        ax[0].plot(path[:-1], path[1:], "-", color=col, lw=0.6, alpha=0.7)
    ax[0].plot(c, c, "--", color=FIT_COLOR, lw=1.1, label="diagonal")
    ax[0].scatter([1], [1], s=50, color=ORANGE, zorder=6, label="$C=1$ (identical inputs)")
    label(ax[0], "$C_\\ell$", "$C_{\\ell+1}$", f"(a) tanh correlation map, $\\sigma_b^2={sb2:g}$")
    ax[0].legend(fontsize=7.5, loc="upper left")
    ax[0].set_xlim(-0.2, 1.02)
    ax[0].set_ylim(-0.2, 1.05)

    # (b) critical decay on the edge of chaos, iterating the exact distance map (tabulated, log-log interpolated)
    L = 100000
    lvec = np.unique(np.logspace(0, np.log10(L), 45).astype(int))
    for name, col, sb in [("tanh", BLUE, 0.05), ("hardtanh", INK, 0.05)]:
        mm = MeanField(name)
        act = mm.act
        sw2, q = eoc_point(mm, sb)
        d2grid = np.logspace(-8, np.log10(0.5 * q), 50)
        ratio = np.array([d2_next(act.phi, q, x, sw2) / x for x in d2grid])
        ly = np.log(np.maximum(1 - ratio, 1e-300))
        eps = [0.5]                                  # 1 - c_0
        for _ in range(L):
            d2 = 2 * q * eps[-1]
            y = np.exp(np.interp(np.log(d2), np.log(d2grid), ly))
            eps.append(eps[-1] * (1 - y))
        eps = np.array(eps)
        dots(ax[1], lvec, eps[lvec], color=col, size=15, label_=f"{name} (exact map, $\\sigma_b^2={sb:g}$)")
        th = 1.0 if name == "tanh" else 0.5
        if name == "tanh":
            z = np.linspace(-12, 12, 200001)
            dd = -2 * np.tanh(np.sqrt(q) * z) / np.cosh(np.sqrt(q) * z) ** 2
            kappa = sw2 * q / 2 * np.trapezoid(dd ** 2 * np.exp(-z * z / 2) / np.sqrt(2 * np.pi), z)
            ll = lvec[lvec > 30]
            ax[1].plot(ll, 1 / (kappa * ll), "--", color=col, lw=1, label="$1/(\\kappa\\,\\ell)$, slope $-1$")
        else:
            kappa = np.sqrt(2) / (3 * np.pi) * sw2 * 2 * np.exp(-1 / (2 * q))
            ll = lvec[lvec > 30]
            ax[1].plot(ll, (kappa * ll / 2) ** -2, "--", color=col, lw=1,
                       label="$(\\kappa\\ell/2)^{-2}$, slope $-2$")
    cr = [0.0]
    for _ in range(L):
        x = cr[-1]
        cr.append((np.sqrt(1 - x * x) + (np.pi - np.arccos(x)) * x) / np.pi)
    cr = np.array(cr)
    dots(ax[1], lvec, 1 - cr[lvec], color=RED, size=15, label_="ReLU ($\\sigma_w^2=2$, $\\sigma_b^2=0$)")
    ll = lvec[lvec > 30]
    ax[1].plot(ll, 9 * np.pi ** 2 / (2 * ll ** 2), "--", color=RED, lw=1, label="$9\\pi^2/(2\\ell^2)$")
    ax[1].set_xscale("log")
    ax[1].set_yscale("log")
    label(ax[1], "$\\ell$", "$1-C_\\ell$", "(b) on the edge of chaos: power-law approach")
    ax[1].legend(fontsize=7.2, loc="lower left")

    # (c) the order parameter of the chaotic phase: stationary distance d*^2 vs chi_1 - 1
    from scipy.optimize import brentq
    for name, col, th in [("tanh", BLUE, 1.0), ("hardtanh", INK, 0.5), ("selu", RED, 0.5)]:
        mm = MeanField(name)
        act = mm.act
        sw_e, _ = eoc_point(mm, 0.05)
        X, Y = [], []
        for dt in np.logspace(-3.7, -2.3, 5):
            sw2 = sw_e * (1 + dt)
            q = float(mm.fixed_point(sw2, 0.05))
            chi = sw2 * float(mm.P(np.array([q]))[0])
            d2s = brentq(lambda x: d2_next(act.phi, q, x, sw2) - x, 1e-9, 0.3, xtol=1e-15, rtol=1e-10)
            X.append(chi - 1)
            Y.append(d2s / (2 * q))
        X, Y = np.array(X), np.array(Y)
        dots(ax[2], X, Y, color=col, size=22, label_=f"{name}")
        ax[2].plot(X, Y[2] * (X / X[2]) ** (1 / th), "--", color=col, lw=1,
                   label=f"slope $\\beta_c=1/\\vartheta_c={1 / th:g}$")
    ax[2].set_xscale("log")
    ax[2].set_yscale("log")
    label(ax[2], "$\\chi_1-1$", "$1-C^*$", "(c) chaotic phase: $1-C^*\\propto(\\chi_1-1)^{\\beta_c}$")
    ax[2].legend(fontsize=7.5, loc="upper left")
    fig.tight_layout()
    save(fig, "fig_corr")


# =====================================================================================
# 9-10. Finite width: the random walk of the log-signal, and avalanches of a real tanh network
# =====================================================================================
def markov_avalanches(name, N, sw2, n_av, L, q0=0.01, store_T=(), Lpath=0, batch=4000, seed=1):
    """
    Exact finite-width simulation (Gaussian weights, sigma_b = 0): given layer l, the next pre-activations are
    i.i.d. N(0, Q_{l+1}) with Q_{l+1} = sigma_w^2 mean_j phi(z_j)^2.  The input has ||z^0||^2 = q0.
    Avalanche: X_l = ln(qhat_l / qhat_0) >= 0 for l = 1..T;  size s = sqrt(N) sum_l (sqrt(qhat_l) - sqrt(qhat_0)).
    Returns T, s, censored flags, and the mean X-profiles for durations in store_T.
    """
    act = get_activation(name)
    rng = np.random.default_rng(seed)
    Ts, Ss, cens = [], [], []
    prof = {T: np.zeros(T) for T in store_T}
    cnt = {T: 0 for T in store_T}
    done = 0
    while done < n_av:
        B = batch
        g = rng.standard_normal((B, N))
        z = g / np.sqrt((g ** 2).sum(1, keepdims=True)) * np.sqrt(q0)
        qh0 = q0 / N
        Q = sw2 * np.mean(act.phi(z) ** 2, axis=1)
        alive = np.arange(B)
        T = np.zeros(B, int)
        S = np.zeros(B)
        path = np.zeros((B, Lpath)) if Lpath else None
        for l in range(1, L + 1):
            gg = rng.standard_normal((alive.size, N))
            zz = np.sqrt(Q)[:, None] * gg
            qh = Q * np.mean(gg ** 2, axis=1)
            up = qh >= qh0
            X = np.log(qh / qh0)
            if Lpath and l <= Lpath:
                path[alive[up], l - 1] = X[up]
            S[alive[up]] += np.sqrt(N) * (np.sqrt(qh[up]) - np.sqrt(qh0))
            T[alive[up]] = l
            Q = sw2 * np.mean(act.phi(zz[up]) ** 2, axis=1)
            alive = alive[up]
            if alive.size == 0:
                break
        c = np.zeros(B, bool)
        c[alive] = True
        valid = T >= 1
        Ts.append(T[valid])
        Ss.append(S[valid])
        cens.append(c[valid])
        for TT in store_T:
            sel = (T == TT) & ~c
            if sel.any():
                prof[TT] += path[sel, :TT].sum(0)
                cnt[TT] += sel.sum()
        done += B
    prof = {k: v / max(cnt[k], 1) for k, v in prof.items()}
    return np.concatenate(Ts), np.concatenate(Ss), np.concatenate(cens), done, prof, cnt


def sigma_c2_exact_smooth(N, a2=1.0):
    return (N / 2) * np.exp(-digamma(N / 2)) / a2


def fig_walk():
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.6))
    N = 100
    sw2 = sigma_c2_exact_smooth(N)
    L = 300
    steps = np.log(sw2 * RNG.chisquare(N, size=(400, L)) / N)
    X = np.concatenate([np.zeros((400, 1)), np.cumsum(steps, 1)], 1)
    # first excursion length of every path; show one long avalanche and two other paths
    first_neg = np.array([np.argmax(x[1:] < 0) + 1 if (x[1:] < 0).any() else L for x in X])
    k0 = int(np.argmin(np.abs(first_neg - 90)))
    others = [k for k in range(400) if k != k0][:2]
    l = np.arange(L + 1)
    for k, col, lab in [(k0, RED, "input 1"), (others[0], BLUE, "input 2"), (others[1], ORANGE, "input 3")]:
        ax[0].plot(l, X[k], "-", color=col, lw=1.1, label=lab)
    Tend = first_neg[k0]
    ax[0].fill_between(l[:Tend + 1], 0, X[k0][:Tend + 1], where=X[k0][:Tend + 1] >= 0, color=GROW, alpha=0.9,
                       label=f"avalanche of input 1: $T={Tend - 1}$")
    ax[0].axhline(0, color=INK, lw=0.8)
    label(ax[0], "$\\ell$", "$X_\\ell$", f"(a) log-signal $X_\\ell=\\ln(\\hat q_\\ell/\\hat q_0)$, $N={N}$")
    ax[0].legend(fontsize=7.5, loc="upper left")
    # (b) distribution of one step
    st = np.log(sw2 * RNG.chisquare(N, size=400000) / N)
    h, e = np.histogram(st, 80, density=True)
    cc = 0.5 * (e[1:] + e[:-1])
    dots(ax[1], cc[::2], h[::2], color=BLUE, size=14, label_="one step $\\ln A_\\ell$ (sampled)")
    mu = np.log(sw2) + digamma(N / 2) + np.log(2 / N)
    from scipy.special import polygamma
    v = float(polygamma(1, N / 2))
    xs = np.linspace(e[0], e[-1], 300)
    ax[1].plot(xs, np.exp(-(xs - mu) ** 2 / (2 * v)) / np.sqrt(2 * np.pi * v), "-", color=RED, lw=1.4,
               label=f"Gaussian, $\\mu=0$, $\\sigma_X^2={v:.4f}$")
    label(ax[1], "$\\ln A$", "density", f"(b) the random step at $\\sigma_w^2=\\sigma_c^2(N)$, $N={N}$")
    ax[1].legend(fontsize=7.5)
    # (c) finite-N critical point
    Ns = np.array([6, 10, 16, 25, 40, 64, 100, 160, 250, 400, 640, 1000])
    NN = np.logspace(np.log10(5), 3.1, 200)
    ax[2].plot(NN, sigma_c2_exact_smooth(NN) - 1, "-", color=BLUE, lw=1.6,
               label="tanh: $\\frac{N}{2}e^{-\\psi(N/2)}-1$ (exact)")
    ax[2].plot(NN, 1 / NN, "--", color=FIT_COLOR, lw=1, label="$1/N$")
    # measured on the full nonlinear tanh network: one exact Markov step from a tiny signal
    act = get_activation("tanh")
    meas = []
    for N_ in Ns:
        tot, n_s = 0.0, 0
        B = int(1e7 // N_)
        for _ in range(20):                                        # 2e8 samples of phi per width
            g = RNG.standard_normal((B, N_))
            Q0 = 1e-8
            Q1 = np.mean(act.phi(np.sqrt(Q0) * g) ** 2, axis=1)   # one exact layer, sigma_w^2 = 1
            tot += np.log(Q1 / Q0).sum()
            n_s += B
        meas.append(np.exp(-tot / n_s) - 1)                        # mu(sigma_w^2=1) = -ln sigma_c^2(N)
    dots(ax[2], Ns, meas, color=BLUE, size=22, label_="tanh network: measured")
    relu = get_activation("relu")
    rel = np.array([sigma_c2_finite_N(relu, int(n)) / 2 - 1 for n in Ns])
    dots(ax[2], Ns, rel, color=RED, size=22, marker="s", label_="ReLU: $\\sigma_c^2(N)/2-1$ (exact average)")
    ax[2].set_xscale("log")
    ax[2].set_yscale("log")
    label(ax[2], "$N$", "$\\sigma_c^2(N)/\\sigma_{w,c}^2-1$", "(c) the critical point of a finite network")
    ax[2].legend(fontsize=7.5, loc="lower left")
    fig.tight_layout()
    save(fig, "fig_walk")


def walk_avalanches(N, mu, n_av, L, q0=0.01, store_T=(), Lpath=0, chunk=100000, seed=2):
    """
    Small-signal limit of the network (exact while the signal is small): qhat_{l+1} = sigma_w^2 qhat_l chi2_N / N,
    i.e. X_l = ln(qhat_l/qhat_0) is a random walk with steps ln(sigma_w^2 chi2_N/N), sigma_w^2 = sigma_c^2(N) e^mu.
    Size as in the network: s = sqrt(N) sum_l (sqrt(qhat_l) - sqrt(qhat_0)) = sqrt(q0) sum_l (e^{X_l/2} - 1).
    """
    rng = np.random.default_rng(seed)
    lnsw = np.log(sigma_c2_exact_smooth(N)) + mu
    Ts, Ss, cens = [], [], []
    prof = {T: np.zeros(T) for T in store_T}
    cnt = {T: 0 for T in store_T}
    done = 0
    while done < n_av:
        B = chunk
        X = np.zeros(B)
        S = np.zeros(B)
        T = np.zeros(B, int)
        path = np.zeros((B, Lpath)) if Lpath else None
        alive = np.arange(B)
        for l in range(1, L + 1):
            X[alive] += lnsw + np.log(rng.chisquare(N, alive.size) / N)
            up = X[alive] >= 0
            a = alive[up]
            S[a] += np.sqrt(q0) * (np.exp(X[a] / 2) - 1)
            T[a] = l
            if Lpath and l <= Lpath:
                path[a, l - 1] = X[a]
            alive = a
            if alive.size == 0:
                break
        c = np.zeros(B, bool)
        c[alive] = True
        v = T >= 1
        Ts.append(T[v]); Ss.append(S[v]); cens.append(c[v])
        for TT in store_T:
            sel = (T == TT) & ~c
            prof[TT] += path[sel, :TT].sum(0)
            cnt[TT] += sel.sum()
        done += B
    prof = {k: v / max(cnt[k], 1) for k, v in prof.items()}
    return np.concatenate(Ts), np.concatenate(Ss), np.concatenate(cens), done, prof, cnt


def int_logbins(T, n_per, lo=1, hi=None, nb=25):
    """pmf of integer durations, per perturbation, averaged over log-spaced integer bins."""
    hi = hi or T.max()
    edges = np.unique(np.logspace(np.log10(lo), np.log10(hi + 1), nb).astype(int))
    cnt, _ = np.histogram(T, edges)
    width = np.diff(edges)
    ctr = np.sqrt(edges[1:] * (edges[:-1]))
    ok = cnt > 3
    return ctr[ok], (cnt / width / n_per)[ok]


def fig_aval():
    t0 = time.time()
    fig, axs = plt.subplots(2, 3, figsize=(16.5, 9.4))
    a = axs.ravel()
    N, L = 1000, 600
    sc = sigma_c2_exact_smooth(N)
    T, S, cens, n_in, _, _ = markov_avalanches("tanh", N, sc, 60000, L)
    print(f"  tanh avalanches: {T.size} valid of {n_in}  ({time.time() - t0:.0f}s)", flush=True)
    # (a) survival
    n = np.arange(1, L + 1)
    surv = np.array([(T >= k).sum() for k in n]) / n_in
    sel = np.unique(np.logspace(0, np.log10(L), 35).astype(int)) - 1
    dots(a[0], n[sel], surv[sel], color=BLUE, size=20, label_="tanh network, $N=1000$")
    u_n = np.exp(gammaln(2 * n + 1) - 2 * gammaln(n + 1) - n * np.log(4))
    a[0].plot(n, u_n, "-", color=RED, lw=1.5, label="$\\binom{2n}{n}4^{-n}$ (exact, no fit)")
    a[0].plot(n, 1 / np.sqrt(np.pi * n), "--", color=FIT_COLOR, lw=1, label="$1/\\sqrt{\\pi n}$")
    a[0].set_xscale("log")
    a[0].set_yscale("log")
    label(a[0], "$n$", "$P(T\\geq n)$", "(a) survival probability of an avalanche")
    a[0].legend(fontsize=7.5)
    # (b) duration distribution per perturbation, critical and off-critical
    for mu_, col, lab in [(0.0, BLUE, "$\\mu=0$ (critical)"), (-0.005, DEEP_BLUE, "$\\mu=-0.005$"),
                          (0.005, RED, "$\\mu=+0.005$")]:
        if mu_ == 0:
            TT, cc, nin = T, cens, n_in
        else:
            TT, _, cc, nin, _, _ = markov_avalanches("tanh", N, sc * np.exp(mu_), 30000, L, seed=7)
        x, p = int_logbins(TT[~cc], nin, 1, L)
        dots(a[1], x, p, color=col, size=18, label_=lab)
    pmf = u_n[:-1] - u_n[1:]
    a[1].plot(n[:-1], pmf, "-", color=INK, lw=1.1, label="$P(T=n)$ exact ($\\mu=0$)")
    guide(a[1], 3, L, -1.5, 0.28 * 3 ** -1.5, "slope $-\\tau_t=-3/2$")
    a[1].axvline((2 / N) / 0.005 ** 2, color=INK, ls=":", lw=1, label="$T_\\xi=\\sigma_X^2/\\mu^2$")
    a[1].set_xscale("log")
    a[1].set_yscale("log")
    label(a[1], "$T$", "$P(T)$", "(b) duration distribution, tanh network $N=1000$")
    a[1].legend(fontsize=7.2, loc="lower left")
    print(f"  (b) {time.time() - t0:.0f}s", flush=True)
    # (c)-(e): small-signal network at large width (no crossover)
    Nw, Lw = 100000, 3000
    store = (25, 50, 100, 200)
    Tw, Sw, cw, nw, prof, cnt = walk_avalanches(Nw, 0.0, 5000000, Lw, store_T=store, Lpath=200)
    print(f"  walk {time.time() - t0:.0f}s", flush=True)
    x, p = logbin_pdf(Sw[~cw], 30)
    dots(a[2], x, p, color=BLUE, size=18, label_="small-signal network, $N=10^5$")
    k = int(0.6 * len(x))
    guide(a[2], x[3], x[-1], -4 / 3, p[k] * (x[3] / x[k]) ** (-4 / 3), "slope $-\\tau_s=-4/3$")
    a[2].set_xscale("log")
    a[2].set_yscale("log")
    label(a[2], "$s$", "$P(s)$", "(c) size distribution")
    a[2].legend(fontsize=7.5, loc="lower left")
    # (d) size-duration
    for TT_, SS_, cc_, col, mk, lab, sXX, LL in [(Tw, Sw, cw, BLUE, "o", "small-signal network, $N=10^5$",
                                                  np.sqrt(2 / Nw), Lw),
                                                 (T, S, cens, RED, "s", "tanh network, $N=1000$", np.sqrt(2 / N), L)]:
        Tu, Su = TT_[~cc_], SS_[~cc_]
        ub = np.unique(np.logspace(0, np.log10(LL), 30).astype(int))
        mS = np.array([Su[Tu == k].mean() if (Tu == k).sum() > 5 else np.nan for k in ub])
        ok = np.isfinite(mS)
        a[3].scatter(ub[ok], mS[ok], s=20, marker=mk, color=col, edgecolors="k", linewidths=0.3, alpha=0.85,
                     label=lab + ": $\\langle s\\rangle_T$")
        tt_ = np.logspace(0, np.log10(LL), 50)
        a[3].plot(tt_, np.sqrt(0.01) / 2 * sXX * np.sqrt(np.pi / 8) * tt_ ** 1.5, "-", color=col, lw=1.2,
                  label="$\\frac{\\sqrt{q_{\\rm in}}}{2}\\,\\sigma_X\\sqrt{\\pi/8}\\;T^{3/2}$ (no fit)")
    a[3].set_xscale("log")
    a[3].set_yscale("log")
    label(a[3], "$T$", "$\\langle s\\rangle_T$", "(d) size against duration: slope $D/z=3/2$")
    a[3].legend(fontsize=7, loc="upper left")
    # (e) mean shape
    sXw = np.sqrt(2 / Nw)
    for TT_, col in zip(store, [LIGHT_BLUE, BLUE, DEEP_BLUE, INK]):
        u = np.arange(1, TT_ + 1) / (TT_ + 1)
        step = max(1, TT_ // 25)
        dots(a[4], u[::step], (prof[TT_] / (sXw * np.sqrt(TT_)))[::step], color=col, size=13,
             label_=f"$T={TT_}$ ({cnt[TT_]} avalanches)")
    uu = np.linspace(0, 1, 300)
    a[4].plot(uu, np.sqrt(8 / np.pi) * np.sqrt(uu * (1 - uu)), "-", color=RED, lw=1.5,
              label="$\\sqrt{8/\\pi}\\,\\sqrt{v(1-v)}$ (semicircle)")
    a[4].set_ylim(0, 1.3)
    label(a[4], "$v=\\ell/(T+1)$", "$\\langle X_\\ell\\rangle/(\\sigma_X\\sqrt{T})$",
          "(e) mean avalanche shape, $N=10^5$")
    a[4].legend(fontsize=7.2, loc="lower center")
    # (f) the same class for three activations
    for name, col, mk, q0_ in [("tanh", BLUE, "o", 1e-2), ("relu", RED, "s", 1e-2), ("elu", ORANGE, "D", 1e-2),
                               ("elu", DEEP_ORANGE, "^", 1e-6)]:
        s2c = sigma_c2_exact_smooth(200) if name != "relu" else sigma_c2_finite_N(get_activation("relu"), 200)
        TT, SS, cc, nin, _, _ = markov_avalanches(name, 200, s2c, 30000, 300, q0=q0_, seed=11)
        nn = np.arange(1, 301)
        sv = np.array([(TT >= k).sum() for k in nn]) / nin
        sl = np.unique(np.logspace(0, np.log10(300), 22).astype(int)) - 1
        hollow = q0_ < 1e-3
        a[5].scatter(nn[sl], sv[sl], s=60 if hollow else 20, marker=mk, facecolors="none" if hollow else col,
                     edgecolors=col if hollow else "k", linewidths=1.2 if hollow else 0.3, zorder=5 if hollow else 3,
                     label=f"{name}, $q_{{\\rm in}}=10^{{{int(np.log10(q0_))}}}$, $\\sigma_w^2={s2c:.4g}$")
    nn = np.arange(1, 301)
    a[5].plot(nn, np.exp(gammaln(2 * nn + 1) - 2 * gammaln(nn + 1) - nn * np.log(4)), "-", color=INK, lw=1.2,
              label="$\\binom{2n}{n}4^{-n}$")
    a[5].set_xscale("log")
    a[5].set_yscale("log")
    label(a[5], "$n$", "$P(T\\geq n)$", "(f) different activations, $N=200$")
    a[5].legend(fontsize=7.2, loc="lower left")
    fig.tight_layout()
    save(fig, "fig_aval")
    print(f"  ({time.time() - t0:.0f}s)")


# =====================================================================================
# 11. Fokker-Planck theory of the stationary signal at finite width
# =====================================================================================
def fp_density(sw2, sb2, N, name="tanh", n_grid=6000):
    """Stationary density in x = ln Q of the diffusion approximation (full coefficients)."""
    act = get_activation(name)
    g0 = act.germ
    st = log_growth_stats(act, N)
    s2 = st["var"]
    t_eff = np.log(sw2 * g0.V1) + (st["mean"] - np.log(g0.V1)) + 0.5 * s2
    x, Q, V, W4 = _fp_grid(act.name, tuple(sorted(act.params.items())), n_grid)
    B2 = sw2 ** 2 * np.maximum(W4 - V ** 2, 1e-300) / N
    A = sw2 * V + sb2 - Q + (t_eff - (sw2 * g0.V1 - 1.0)) * Q
    B2 *= s2 / (2.0 * (sw2 * g0.V1) ** 2 / N)
    integrand = 2 * A * Q / B2
    seg = 0.5 * (integrand[1:] + integrand[:-1]) * np.diff(x)
    F = -np.concatenate([np.cumsum(seg[::-1])[::-1], [0.0]])
    logp = F - np.log(B2) + x
    logp -= logp.max()
    p = np.exp(logp)
    p /= np.trapezoid(p, x)
    return x, Q, p, t_eff, s2


def markov_stationary(name, N, sw2, sb2, B=3000, burn=1500, meas=1500, every=10, seed=3):
    act = get_activation(name)
    rng = np.random.default_rng(seed)
    Q = np.full(B, 0.2)
    out = []
    for l in range(burn + meas):
        g = rng.standard_normal((B, N))
        Q = sw2 * np.mean(act.phi(np.sqrt(Q)[:, None] * g) ** 2, axis=1) + sb2
        Q = np.maximum(Q, 1e-300)
        if l >= burn and (l - burn) % every == 0:
            out.append(Q.copy())
    return np.concatenate(out)


def fig_fp():
    t0 = time.time()
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.7))
    N = 50
    m = MeanField("tanh")
    scN = sigma_c2_exact_smooth(N)
    cols = [DEEP_BLUE, BLUE, ORANGE, RED]
    for sw2, col in zip([1.03, 1.06, 1.10, 1.16], cols):
        Qs = markov_stationary("tanh", N, sw2, 0.0, B=2000, burn=1500, meas=1000)
        lx = np.log(Qs[Qs > 1e-12])
        h, e = np.histogram(lx, 45, density=True)
        cc = 0.5 * (e[1:] + e[:-1])
        dots(ax[0], np.exp(cc), h, color=col, size=14, label_=f"$\\sigma_w^2={sw2:g}$ (simulation)")
        x, Q, p, _, _ = fp_density(sw2, 0.0, N)
        ax[0].plot(Q, p, "-", color=col, lw=1.3)
    ax[0].plot([], [], "-", color=INK, lw=1.3, label="Fokker-Planck prediction")
    ax[0].set_xscale("log")
    ax[0].set_xlim(1e-4, 3)
    label(ax[0], "$Q$", "density of $\\ln Q$", f"(a) tanh, $N={N}$, $\\sigma_b^2=0$: stationary law")
    ax[0].legend(fontsize=7.2, loc="upper left")
    print(f"  fp (a) {time.time() - t0:.0f}s", flush=True)
    # (b) mean Q vs sigma_w^2 at sigma_b = 0
    sws = np.linspace(0.96, 1.3, 300)
    ax[1].plot(sws, [float(m.fixed_point(s, 0.0)) for s in sws], "--", color=FIT_COLOR, lw=1.2,
               label="mean field $q^*$ ($N=\\infty$)")
    fpm = []
    for s in sws:
        if s <= scN * 1.0005:
            fpm.append(0.0)
            continue
        x, Q, p, _, _ = fp_density(s, 0.0, N)
        fpm.append(np.trapezoid(p * Q, x))
    ax[1].plot(sws, fpm, "-", color=BLUE, lw=1.6, label="Fokker-Planck $\\langle Q\\rangle$")
    stg = get_activation("tanh").germ
    mu = np.log(sws / scN)
    ax[1].plot(sws, np.where(mu > 0, mu / (sws * stg.c), 0.0), ":", color=RED, lw=1.4,
               label="$\\mu/(\\sigma_w^2 c)$ (small-signal law)")
    for s in [1.02, 1.04, 1.08, 1.12, 1.16, 1.22, 1.3]:
        Qs = markov_stationary("tanh", N, s, 0.0, B=1500, burn=1500, meas=600, every=20, seed=5)
        dots(ax[1], [s], [Qs.mean()], color=BLUE, size=26)
    ax[1].scatter([], [], s=26, color=BLUE, label="simulation")
    ax[1].axvline(1.0, color=INK, ls=":", lw=1, label="$\\sigma_{w,c}^2=1$")
    ax[1].axvline(scN, color=RED, ls="-.", lw=1, label=f"$\\sigma_c^2(N)={scN:.4f}$")
    ax[1].set_xlim(0.96, 1.3)
    ax[1].set_ylim(0, None)
    label(ax[1], "$\\sigma_w^2$", "$\\langle Q\\rangle$", "(b) the transition survives, shifted to $\\sigma_c^2(N)$")
    ax[1].legend(fontsize=7.2, loc="upper left")
    print(f"  fp (b) {time.time() - t0:.0f}s", flush=True)
    # (c) with bias: <sqrt Q> vs sigma_w^2
    sb2 = 1e-3
    sws = np.linspace(0.8, 1.4, 200)
    ax[2].plot(sws, np.sqrt([float(m.fixed_point(s, sb2)) for s in sws]), "--", color=FIT_COLOR, lw=1.2,
               label="mean field $\\sqrt{q^*}$")
    fps = []
    for s in sws:
        x, Q, p, _, _ = fp_density(s, sb2, N)
        fps.append(np.trapezoid(p * np.sqrt(Q), x))
    ax[2].plot(sws, fps, "-", color=BLUE, lw=1.6, label="Fokker-Planck $\\langle\\sqrt{Q}\\rangle$")
    for s in [0.85, 0.95, 1.0, 1.05, 1.1, 1.2, 1.3, 1.4]:
        Qs = markov_stationary("tanh", N, s, sb2, B=1500, burn=1500, meas=600, every=20, seed=9)
        dots(ax[2], [s], [np.sqrt(Qs).mean()], color=BLUE, size=26)
    ax[2].scatter([], [], s=26, color=BLUE, label="simulation")
    label(ax[2], "$\\sigma_w^2$", "$\\langle\\sqrt{Q}\\rangle$", f"(c) with bias, $\\sigma_b^2=10^{{-3}}$, $N={N}$")
    ax[2].legend(fontsize=7.5, loc="upper left")
    fig.tight_layout()
    save(fig, "fig_fp")
    print(f"  ({time.time() - t0:.0f}s)")


def fig_classes():
    save(class_shapes_figure(), "fig_shapes")
    for name in SPECS:
        save(activation_figure(name), f"flow_{name}")


ALL = dict(map=fig_map, small=fig_small_signal, zero=fig_zero_bias, bias=fig_bias, exps=fig_exponents,
           pv=fig_PV, eoc=fig_eoc, corr=fig_corr, walk=fig_walk, aval=fig_aval, fp=fig_fp, classes=fig_classes)

if __name__ == "__main__":
    which = sys.argv[1:] or list(ALL)
    for w in which:
        t = time.time()
        ALL[w]()
        print(f"[{w}] {time.time() - t:.1f}s", flush=True)
