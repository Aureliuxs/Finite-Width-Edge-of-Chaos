"""
mean_field.py -- mean-field experiments.

mf_exponents      : all MF critical exponents of chosen activations, measured from log-log fits
                    and compared with the Landau-germ predictions (paper eqs. 3-5, 9 + extensions)
mf_landscape      : paper Fig. 3(a,b): sqrt(q*) and chi_{sigma_w^2} vs sigma_w^2 for several sigma_b^2
phase_diagram     : paper Fig. 5 + heat map of the quasi-critical ridge in (sigma_w^2, sigma_b^2),
                    optionally in the *native* coordinates of any initializer
activation_survey : universality classes of 11 activations (table + figure)
"""
from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm

from ..activations import STANDARD_ACTIVATIONS, get_activation
from ..criticality import MFWindows, measure_mf_exponents, widom_scaling_collapse
from ..finite_n import sigma_c2_finite_N
from ..initializers import Initializer
from ..meanfield import MeanField, detect_germ
from ..plotting import (BLUE, CMAP_COOL, CMAP_WARM, DEEP_BLUE, DEEP_RED, FIT_COLOR, ORANGE, PALETTE, RED,
                        dots, fit_line, heatmap, label, loglog_panel)
from .common import Run, fmt, merge

# ======================================================================
# 1. MF exponents
# ======================================================================
MF_EXPONENTS_DEFAULTS = dict(activations=["tanh", "elu"], windows={})


def exp_mf_exponents(run: Run, cfg=None):
    cfg = merge(MF_EXPONENTS_DEFAULTS, cfg)
    w = MFWindows(**cfg["windows"])
    out = {}
    for name in cfg["activations"]:
        mf = MeanField(name)
        r = measure_mf_exponents(mf, w)
        d, f, pred = r["data"], r["fits"], r["predicted"]
        fig, axs = plt.subplots(3, 3, figsize=(13.5, 11.5))
        axs = axs.ravel()
        t, h = d["t"], d["h"]

        def panel(ax, x, y, key, xl, yl, title, color, sign=1):
            dots(ax, x, y, color=color, label_="MF theory")
            fr = f[key]
            p = r["predicted"].get(key) if key in r["predicted"] else None
            lab = f"fit: {sign * fr['slope']:.4f}" + (f" (theory {p:.4g})" if isinstance(p, float) else "")
            fit_line(ax, fr, label_=lab)
            ax.set_xscale("log"); ax.set_yscale("log")
            label(ax, xl, yl, title)
            ax.legend(loc="best")

        panel(axs[0], t, d["above"]["q"], "beta", r"$t$", r"$q^*$", r"order parameter, $h=0$: $\beta$", BLUE)
        panel(axs[1], h, d["crit"]["q"], "one_over_delta", r"$h=\sigma_b^2$", r"$q^*$",
              r"critical isotherm $t=0$: $1/\delta$", RED)
        ax = axs[2]
        dots(ax, t, d["above"]["chi_h"], color=BLUE, label_=r"$t>0$")
        dots(ax, t, d["below"]["chi_h"], color=ORANGE, label_=r"$t<0$")
        fit_line(ax, f["gamma"], label_=f"$\\gamma$ = {f['gamma']['exponent']:.4f}")
        fit_line(ax, f["gamma_prime"], color=DEEP_RED, label_=f"$\\gamma'$ = {f['gamma_prime']['exponent']:.4f}")
        ax.set_xscale("log"); ax.set_yscale("log")
        label(ax, r"$|t|$", r"$\chi_h = \partial q^*/\partial h$", "susceptibility: $\\gamma$, $\\gamma'$")
        ax.legend()
        ax = axs[3]
        dots(ax, t, d["above"]["xi"], color=BLUE, label_=r"$t>0$")
        dots(ax, t, d["below"]["xi"], color=ORANGE, label_=r"$t<0$")
        fit_line(ax, f["nu_par"], label_=f"$\\nu_\\parallel$ = {f['nu_par']['exponent']:.4f}")
        ax.set_xscale("log"); ax.set_yscale("log")
        label(ax, r"$|t|$", r"$\xi$", r"depth correlation length: $\nu_\parallel$")
        ax.legend()
        panel(axs[4], t, d["above"]["chi_t"], "chi_sigma_w_exponent", r"$t$", r"$\chi_{\sigma_w^2}$",
              r"paper's $\sigma_w$-susceptibility", DEEP_BLUE, -1)
        if "decay_l" in d:
            ax = axs[5]
            l, q = d["decay_l"], d["decay_q"]
            sel = np.unique(np.logspace(0, np.log10(l.size - 1), 60).astype(int))
            dots(ax, l[sel], q[sel], color=RED, label_="MF map, $t=h=0$")
            fr = f["beta_over_nu_par"]
            fit_line(ax, fr, label_=f"slope {fr['slope']:.4f} (theory {-pred.get('beta_over_nu_par', np.nan):.4g})")
            ax.set_xscale("log"); ax.set_yscale("log")
            label(ax, r"$\ell$", r"$q_\ell$", r"critical decay: $\beta/\nu_\parallel$")
            ax.legend()
        ax = axs[6]
        ok = np.isfinite(d["widom_t"])
        if ok.any():
            dots(ax, d["widom_h"][ok], d["widom_t"][ok], color=BLUE, label_=r"ridge of $\chi_{\sigma_w^2}$")
            fit_line(ax, f["widom_t_vs_h"], label_=f"slope {f['widom_t_vs_h']['slope']:.4f}")
        else:
            ax.text(0.03, 0.03, r"no interior maximum of $\chi_{\sigma_w^2}$ (it does not diverge)",
                    transform=ax.transAxes, fontsize=8)
        ok2 = np.isfinite(d["widom_h_t"]) & (d["widom_h_t"] > 0)
        if ok2.any():
            dots(ax, d["widom_h"][ok2], d["widom_h_t"][ok2], color=ORANGE, label_=r"ridge of $\chi_h$")
        dots(ax, np.maximum(d["eoc_h"], 1e-300), d["eoc_t"], color=RED, label_="edge of chaos", size=8)
        ax.set_xscale("log"); ax.set_yscale("log")
        ax.set_xlim(d["widom_h"].min() / 3, d["widom_h"].max() * 3)
        label(ax, r"$h$", r"$t$", "Widom-like line vs edge of chaos")
        ax.legend(fontsize=8)
        ax = axs[7]
        if np.isfinite(d["widom_chi"]).any():
            dots(ax, d["widom_h"], d["widom_chi"], color=BLUE, label_=r"$\max_t\,\chi_{\sigma_w^2}$")
            fit_line(ax, f["widom_chi_max_vs_h"], label_=f"slope {f['widom_chi_max_vs_h']['slope']:.4f}")
        dots(ax, d["widom_h"], d["widom_h_chi"], color=ORANGE, label_=r"$\max_t\,\chi_h$")
        fit_line(ax, f["widom_h_chi_max_vs_h"], color=DEEP_RED,
                 label_=f"slope {f['widom_h_chi_max_vs_h']['slope']:.4f}")
        ax.set_xscale("log"); ax.set_yscale("log")
        label(ax, r"$h$", r"$\chi_{\max}$", "ridge height along the Widom-like line")
        ax.legend(fontsize=8)
        ax = axs[8]
        if "beta" in pred:
            col = widom_scaling_collapse(mf, pred["beta"], pred["Delta"])
            for k, (tt, x, y) in enumerate(col):
                c = BLUE if tt > 0 else RED
                ax.scatter(x, y, s=8, color=c, alpha=0.6, label=("$t>0$" if k == 0 else ("$t<0$" if k == len(col) // 2 else None)))
            ax.set_xscale("log"); ax.set_yscale("log")
            label(ax, r"$h/|t|^{\Delta}$", r"$q^*/|t|^{\beta}$", r"Widom scaling collapse $F_\pm$")
            ax.legend()
        fig.suptitle(f"Mean-field criticality: $\\phi$ = {name}  ({r['klass']})", y=1.0)
        fig.tight_layout()
        run.fig(fig, f"mf_exponents_{name}")
        rows = ["", f"### MF exponents: {name}  ({r['klass']})", "", "| exponent | measured | theory |", "|---|---|---|"]
        for nm, m, e, p in r["table"]:
            rows.append(f"| {nm} | {fmt(m, e)} | {fmt(p) if isinstance(p, float) else '–'} |")
        run.note("\n".join(rows))
        out[name] = {nm: dict(measured=m, err=e, theory=p) for nm, m, e, p in r["table"]}
    run.record("mf_exponents", out)
    return out


# ======================================================================
# 2. MF landscape (paper Fig. 3 a-b), with an interactive version
# ======================================================================
MF_LANDSCAPE_DEFAULTS = dict(
    activation="tanh",
    sw2_range=[0.9, 1.44], n_sw2=400,
    log10_sb2=[None, -8.0, -6.8, -5.6, -4.4, -4.0, -3.2, -2.8, -2.2],   # None = sigma_b^2 = 0 (paper)
)


def _sb2_colors(n):
    from matplotlib.colors import LinearSegmentedColormap
    cm = LinearSegmentedColormap.from_list("br", [DEEP_BLUE, BLUE, "#9CC3E6", "#F6C28B", ORANGE, RED, DEEP_RED])
    return [cm(x) for x in np.linspace(0, 1, n)]


def exp_mf_landscape(run: Run, cfg=None):
    cfg = merge(MF_LANDSCAPE_DEFAULTS, cfg)
    mf = MeanField(cfg["activation"])
    sw2 = np.linspace(*cfg["sw2_range"], cfg["n_sw2"])
    fig, axs = plt.subplots(1, 3, figsize=(14, 4.1))
    cols = _sb2_colors(len(cfg["log10_sb2"]))
    out = {}
    for c, lg in zip(cols, cfg["log10_sb2"]):
        sb2 = 0.0 if lg is None else 10.0 ** lg
        R = mf.response(sw2, sb2)
        lab = r"$\sigma_b^2=0$" if lg is None else f"$\\log_{{10}}\\sigma_b^2={lg}$"
        axs[0].scatter(sw2, R["m"], s=4, color=c, label=lab)
        axs[1].scatter(sw2, R["chi_t"], s=4, color=c, label=lab)
        axs[2].scatter(sw2, R["chi_h"], s=4, color=c, label=lab)
        j = int(np.nanargmax(R["chi_t"]))
        out[str(lg)] = dict(sw2_peak=float(sw2[j]), chi_peak=float(R["chi_t"][j]))
    label(axs[0], r"$\sigma_w^2$", r"$\sqrt{q^*}$", "(a) steady-state signal strength")
    label(axs[1], r"$\sigma_w^2$", r"$\chi_{\sigma_w^2}$", r"(b) $\sigma_w$-susceptibility")
    axs[1].set_ylim(0, 5)
    label(axs[2], r"$\sigma_w^2$", r"$\chi_h$", r"(c) susceptibility $\partial q^*/\partial h$")
    axs[2].set_yscale("log")
    for ax in axs:
        ax.legend(fontsize=6.5, markerscale=3)
    fig.suptitle(f"Mean-field landscape ($\\phi$ = {cfg['activation']}) -- paper Fig. 3(a,b)")
    fig.tight_layout()
    run.fig(fig, f"mf_landscape_{cfg['activation']}")
    run.record("mf_landscape", out)
    return out


def interactive_landscape(activation="tanh", sw2_range=(0.9, 1.44)):
    """Slider over log10 sigma_b^2 (notebook)."""
    from ..plotting import interactive
    mf = MeanField(activation)
    sw2 = np.linspace(*sw2_range, 300)

    def draw(log10_sb2=-5.0, fig=None):
        fig = fig or plt.figure(figsize=(10, 3.8))
        a1, a2 = fig.add_subplot(1, 2, 1), fig.add_subplot(1, 2, 2)
        R = mf.response(sw2, 10 ** log10_sb2)
        R0 = mf.response(sw2, 0.0)
        dots(a1, sw2, R0["m"], color=BLUE, size=6, label_=r"$\sigma_b^2=0$")
        dots(a1, sw2, R["m"], color=RED, size=6, label_=f"$\\sigma_b^2=10^{{{log10_sb2:.2f}}}$")
        dots(a2, sw2, R0["chi_t"], color=BLUE, size=6, label_=r"$\sigma_b^2=0$")
        dots(a2, sw2, R["chi_t"], color=RED, size=6, label_=f"$\\sigma_b^2=10^{{{log10_sb2:.2f}}}$")
        a2.set_ylim(0, 6)
        label(a1, r"$\sigma_w^2$", r"$\sqrt{q^*}$", "signal strength")
        label(a2, r"$\sigma_w^2$", r"$\chi_{\sigma_w^2}$", "susceptibility")
        a1.legend(); a2.legend()
        fig.tight_layout()
        return fig
    return interactive(draw, {"log10_sb2": (-9.0, -1.5, 0.1, -5.0)})


# ======================================================================
# 3. Phase diagram / quasi-critical ridge heat map (paper Fig. 5)
# ======================================================================
PHASE_DEFAULTS = dict(
    activation="tanh",
    sw2_range=[0.97, 1.4], n_sw2=260,
    log10_sb2_range=[-8.0, -2.0], n_sb2=90,
    widom_dots=16,
    native_init=None,          # e.g. "uniform": axes relabelled in that scheme's native parameters
)


def exp_phase_diagram(run: Run, cfg=None):
    cfg = merge(PHASE_DEFAULTS, cfg)
    mf = MeanField(cfg["activation"])
    swc = mf.act.germ.sigma_w2_c
    sw2 = swc * np.linspace(*cfg["sw2_range"], cfg["n_sw2"])
    sb2 = np.logspace(*cfg["log10_sb2_range"], cfg["n_sb2"])
    W, H = np.meshgrid(sw2, sb2)
    R = mf.response(W, H)
    chi_t, chi1 = R["chi_t"], R["chi1"]

    fig, axs = plt.subplots(1, 3, figsize=(16, 4.6))
    # (a) paper's Fig. 5: ordered / chaotic phases, edge of chaos, Widom-like line
    ax = axs[0]
    ordered = (chi1 < 1).astype(float)
    ax.pcolormesh(sw2, sb2, ordered, cmap=plt.matplotlib.colors.ListedColormap(["#2D3E7A", "#BFD0E6"]),
                  shading="nearest", rasterized=True)
    se, he, _ = mf.edge_of_chaos(np.logspace(-10, 1, 900))
    m = (he >= sb2.min()) & (he <= sb2.max()) & (se <= sw2.max())
    ax.plot(se[m], he[m], "--", color="k", lw=1.2, label="edge of chaos")
    hw = np.logspace(cfg["log10_sb2_range"][0], cfg["log10_sb2_range"][1] - 0.2, cfg["widom_dots"])
    swW, chiW = mf.widom_line(hw, swc * np.concatenate([np.linspace(0.999, 1.0, 5), 1 + np.logspace(-8, 0, 900)]))
    ok = np.isfinite(swW)
    sizes = 140 * (chiW[ok] / np.nanmax(chiW)) ** 1.0 + 4
    ax.scatter(swW[ok], hw[ok], s=sizes, facecolors="white", edgecolors="k", linewidths=0.6, zorder=5,
               label="Widom-like line")
    ax.set_yscale("log"); ax.set_xlim(sw2.min(), sw2.max())
    label(ax, r"$\sigma_w^2$", r"$\sigma_b^2$", "(a) phases, edge of chaos, Widom-like line")
    ax.legend(loc="lower right", fontsize=8, frameon=True)
    # (b) heat map of the paper's susceptibility (the quasi-critical ridge)
    ax = axs[1]
    Z = np.where(np.isfinite(chi_t) & (chi_t > 0), chi_t, np.nan)
    heatmap(ax, sw2, sb2, Z, cmap=CMAP_WARM, norm=LogNorm(vmin=np.nanpercentile(Z, 2), vmax=np.nanmax(Z)),
            cbar_label=r"$\chi_{\sigma_w^2}$")
    ax.scatter(swW[ok], hw[ok], s=10, color=DEEP_BLUE, label="Widom-like line", zorder=5)
    ax.plot(se[m], he[m], "--", color="k", lw=1.0, label="edge of chaos")
    label(ax, r"$\sigma_w^2$", r"$\sigma_b^2$", r"(b) quasi-critical ridge $\chi_{\sigma_w^2}$")
    ax.legend(loc="lower right", fontsize=8)
    # (c) cross-input correlation depth zeta_c (ordered phase), diverging on the edge of chaos
    ax = axs[2]
    zc = np.where(np.isfinite(R["zeta_c"]), R["zeta_c"], np.nan)
    heatmap(ax, sw2, sb2, zc, cmap=CMAP_COOL, norm=LogNorm(vmin=1, vmax=np.nanpercentile(zc, 99.5)),
            cbar_label=r"$\zeta_c$")
    ax.plot(se[m], he[m], "--", color="k", lw=1.0, label="edge of chaos")
    label(ax, r"$\sigma_w^2$", r"$\sigma_b^2$", r"(c) correlation depth $\zeta_c$ (ordered phase)")
    ax.legend(loc="lower right", fontsize=8)
    ni = cfg.get("native_init")
    if ni:
        _native_axes(axs[1], ni)
    fig.suptitle(f"Phase diagram, $\\phi$ = {cfg['activation']} (paper Fig. 5)")
    fig.tight_layout()
    run.fig(fig, f"phase_diagram_{cfg['activation']}")
    out = dict(widom_sb2=hw, widom_sw2=swW, widom_chi=chiW)
    run.record("phase_diagram", out)
    return out


def _native_axes(ax, scheme: str):
    """Secondary axes in the native parameters of an initializer (e.g. uniform bound a)."""
    ref = Initializer.from_sigma(scheme, 1.0, 1e-4)
    wkey = [k for k in ref.weight_params if k in ("sigma_w", "a", "gain")]
    if not wkey:
        return
    k = wkey[0]
    f = lambda s2: np.array([Initializer.from_sigma(scheme, max(v, 1e-12)).weight_params[k] for v in np.atleast_1d(s2)])
    g = lambda p: np.array([Initializer(scheme, {k: v}).sigma_w2() for v in np.atleast_1d(p)])
    sec = ax.secondary_xaxis("top", functions=(f, g))
    sec.set_xlabel(f"{scheme}: {k}", fontsize=9)


# ======================================================================
# 4. Activation survey (universality classes)
# ======================================================================
SURVEY_DEFAULTS = dict(activations=STANDARD_ACTIVATIONS, N_finite=[100], windows={})


def exp_activation_survey(run: Run, cfg=None):
    cfg = merge(SURVEY_DEFAULTS, cfg)
    w = MFWindows(**cfg["windows"])
    rows, out = [], {}
    names = cfg["activations"]
    nc = 4
    nr = int(np.ceil(len(names) / nc))
    fig, axs = plt.subplots(nr, nc, figsize=(4.0 * nc, 3.3 * nr))
    axs = np.atleast_1d(axs).ravel()
    for i, name in enumerate(names):
        mf = MeanField(name)
        g = mf.act.germ
        det = detect_germ(mf)
        entry = dict(klass=g.klass, V0=g.V0, V1=g.V1, theta=g.theta, c=g.c, detected=det,
                     sigma_w2_c=(g.sigma_w2_c if g.has_critical_point else None))
        if g.has_critical_point:
            for N in cfg["N_finite"]:
                entry[f"sigma_c2_N{N}"] = sigma_c2_finite_N(name, N)
        meas = {}
        if g.has_critical_point and np.isfinite(g.theta) and g.c > 0:
            r = measure_mf_exponents(mf, w)
            meas = {nm: (m, e, p) for nm, m, e, p in r["table"]}
        entry["measured"] = meas
        out[name] = entry
        # --- panel: q*(sigma_w^2); h = 0 from a small and a large input (reveals bistability/hysteresis
        #     of subcritical classes) and h = 1e-4 (rounding by the field)
        ax = axs[i]
        swc = g.sigma_w2_c
        sw2 = swc * np.linspace(0.3, 1.8, 400)
        for c, hh, q0, lab in ((BLUE, 0.0, 1e-2, "$h=0$, $q_0=10^{-2}$"), (ORANGE, 0.0, 4.0, "$h=0$, $q_0=4$"),
                               (RED, 1e-4, 1e-2, "$h=10^{-4}$, $q_0=10^{-2}$")):
            q = mf.fixed_point(sw2, hh, q_init=q0)
            qq = np.where(np.isfinite(q), q, np.nan)
            ax.scatter(sw2, np.sqrt(qq), s=4, color=c, label=lab)
            if np.isinf(q).any():
                k = np.argmax(np.isinf(q))
                ax.axvline(sw2[k], color=c, lw=0.8, ls=":")
        ax.set_ylim(bottom=0)
        label(ax, r"$\sigma_w^2$", r"$\sqrt{q^*}$", f"{name}")
        ax.text(0.02, 0.97, g.klass.split(":")[0], transform=ax.transAxes, fontsize=7.5, va="top")
        ax.legend(fontsize=7, loc="center left", markerscale=2)
        # --- summary row
        def mm(key):
            v = meas.get(key)
            return fmt(v[0], v[1], 3) if v else "–"
        rows.append(f"| {name} | {g.klass} | {g.V0:.4g} | {g.V1:.4g} | "
                    f"{'–' if not g.has_critical_point else f'{swc:.4g}'} | "
                    f"{g.theta if np.isfinite(g.theta) else '∞'} | {g.c:.4g} | {det.get('theta', np.nan):.3f} | "
                    f"{mm('beta')} | {mm('delta')} | {mm('gamma')} | {mm('nu_par')} | {mm('chi_sigma_w_exponent')} | "
                    f"{mm('eoc_h_vs_t')} |")
    for j in range(len(names), axs.size):
        axs[j].axis("off")
    fig.suptitle(r"Activation survey: $\sqrt{q^*}$ vs $\sigma_w^2$ (dotted: run-away $q^*\to\infty$ from that input)")
    fig.tight_layout()
    run.fig(fig, "activation_survey")
    hdr = ["", "### Activation survey (MF universality classes; order parameter q*, t = σ_w²V₁ − 1, h = σ_b²)", "",
           "| φ | class | V₀ | V₁ | σ²_w,c | ϑ | c | ϑ (detected) | β | δ | γ | ν∥ | χ_σw exp. | EOC h∝t^x |",
           "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    run.note("\n".join(hdr + rows))
    run.record("activation_survey", out)
    return out
