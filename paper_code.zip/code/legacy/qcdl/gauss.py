"""
gauss.py
========

High-accuracy Gaussian expectations  E_z[ f(sqrt(q) z) ],  z ~ N(0,1),
vectorised over arrays of variances q.

Why not plain Gauss-Hermite?  Several activations (ReLU, ELU, SELU, hard-tanh) are not
smooth.  Gauss-Hermite then converges only algebraically, which is not good enough for
extracting critical exponents from q* ~ t^beta over many decades (we need V(q)/q to
~1e-12 relative accuracy).  Instead we use *composite Gauss-Legendre* quadrature on
[-Z, Z] (Z = 12 standard deviations; the neglected Gaussian mass is < 1e-32) with panel
breakpoints placed exactly at the kinks  z_k = x_k / sqrt(q)  of the activation.
On every panel the integrand is analytic, so convergence is spectral.
"""
from __future__ import annotations

import numpy as np

Z_MAX = 12.0
_GL_CACHE: dict = {}


def _gl(n: int):
    if n not in _GL_CACHE:
        _GL_CACHE[n] = np.polynomial.legendre.leggauss(n)
    return _GL_CACHE[n]


def gauss_expect(f, q, kinks=(), n: int = 96, z_max: float = Z_MAX, n_panels_base: int = 4):
    """
    E_z[f(sqrt(q) z)] for an array of q >= 0.

    Parameters
    ----------
    f       : vectorised callable of x (NumPy)
    q       : scalar or array of variances
    kinks   : x-locations where f is non-smooth (panel breakpoints)
    n       : Gauss-Legendre nodes per panel
    n_panels_base : number of equal panels [-Z, Z] is split into *before* inserting kinks
    """
    q_in = np.asarray(q, dtype=float)
    q = np.atleast_1d(q_in).ravel()
    xi, wi = _gl(n)
    base = np.linspace(-z_max, z_max, n_panels_base + 1)
    sq = np.sqrt(q)
    # breakpoints in z-space: base grid + kinks/sqrt(q) (clipped into [-Z, Z])
    bps = [np.broadcast_to(b, q.shape) for b in base]
    for xk in kinks:
        zk = xk / np.maximum(sq, 1e-300)
        bps.append(np.clip(zk, -z_max, z_max))
    B = np.sort(np.stack(bps, axis=-1), axis=-1)              # (nq, nb)
    a, b = B[..., :-1], B[..., 1:]                            # panel ends (nq, np)
    mid, half = 0.5 * (a + b), 0.5 * (b - a)
    z = mid[..., None] + half[..., None] * xi                 # (nq, np, n)
    w = half[..., None] * wi * np.exp(-0.5 * z ** 2) / np.sqrt(2.0 * np.pi)
    vals = f(sq[:, None, None] * z)
    return np.sum(w * vals, axis=(-2, -1)).reshape(q_in.shape)


def gauss_expect2(f, g, q, c, kinks=(), n: int = 64, z_max: float = 10.0):
    """
    E[f(u1) g(u2)] with (u1, u2) jointly Gaussian, Var = q, correlation c (scalar q, c).

    u1 = sqrt(q) z1,  u2 = sqrt(q) (c z1 + sqrt(1-c^2) z2).  The outer z1 integral uses
    kink-aware composite Gauss-Legendre; the inner z2 integral puts a breakpoint at every
    z2 where u2 hits a kink (this depends on z1 and is handled row by row).
    """
    xi, wi = _gl(n)
    sq = np.sqrt(q)
    s = np.sqrt(max(1.0 - c * c, 0.0))
    # outer grid in z1
    base = list(np.linspace(-z_max, z_max, 5))
    for xk in kinks:
        base.append(np.clip(xk / sq, -z_max, z_max))
    base = np.sort(np.array(base))
    a, b = base[:-1], base[1:]
    z1 = ((a + b)[:, None] / 2 + (b - a)[:, None] / 2 * xi).ravel()
    w1 = ((b - a)[:, None] / 2 * wi).ravel() * np.exp(-0.5 * z1 ** 2) / np.sqrt(2 * np.pi)
    if s < 1e-12:  # perfectly correlated
        return np.sum(w1 * f(sq * z1) * g(sq * c * z1))
    # inner grid in z2 for each z1 (rows)
    inner = [np.full_like(z1, v) for v in np.linspace(-z_max, z_max, 5)]
    for xk in kinks:
        inner.append(np.clip((xk / sq - c * z1) / s, -z_max, z_max))
    Bi = np.sort(np.stack(inner, axis=-1), axis=-1)
    ai, bi = Bi[:, :-1], Bi[:, 1:]
    z2 = (ai + bi)[..., None] / 2 + (bi - ai)[..., None] / 2 * xi          # (n1, np, n)
    w2 = (bi - ai)[..., None] / 2 * wi * np.exp(-0.5 * z2 ** 2) / np.sqrt(2 * np.pi)
    u2 = sq * (c * z1[:, None, None] + s * z2)
    inner_int = np.sum(w2 * g(u2), axis=(-2, -1))
    return np.sum(w1 * f(sq * z1) * inner_int)
